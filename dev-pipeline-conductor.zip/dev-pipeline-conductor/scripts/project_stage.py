#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""判定研发项目当前阶段，并可一键补齐标准目录骨架。

用法（全部相对路径，便于随 skill 打包转移）：
    python scripts/project_stage.py                  # 判定当前目录
    python scripts/project_stage.py <项目根>
    python scripts/project_stage.py <项目根> --init   # 缺什么补什么，已存在不动

判定只看"特征交付物是否存在"，不看目录名字；输出阶段、证据与建议下一步。
"""
import argparse
import io
import os
import sys

STAGES = [
    ("S0", "立项", "需要用户提供需求说明"),
    ("S1", "需求报告 -> req-analysis-report", "缺需求分析报告"),
    ("S2", "方案设计 -> detailed-design-report", "缺详细设计/方案报告"),
    ("S3", "代码开发(含功能测试) -> fullstack-dev-contract", "缺可运行工程"),
    ("S4", "测试大纲与执行 -> test-outline-report", "缺测试大纲或执行记录"),
    ("S5", "创新报告(一稿) -> tech-summary-report", "缺技术总结/创新点报告"),
    ("S6", "演示视频与图片 -> demo-narration-design", "缺成片或配图"),
    ("S7", "汇报PPT/含效果图报告 -> slide-deck-design", "缺PPT或含效果图报告"),
]

DOC_PATTERNS = {
    "S1": [("需求分析",), ("需求报告",), ("需求说明",)],
    "S2": [("详细设计",), ("方案设计",), ("设计方案",), ("技术方案",)],
    "S4": [("测试大纲",), ("测试方案",)],
    "S5": [("创新",), ("技术总结",), ("技术报告",)],
    "S7": [("汇报",), ("PPT",), ("效果图",)],
}
CODE_HINTS = ("requirements.txt", "manage.py", "main.py", "app.py", "package.json",
              "pyproject.toml", "index.html")


SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", "env",
             "site-packages", "Lib", "lib64", "roaming", "dist", "build",
             ".cache", ".idea", ".vscode", ".pytest_cache", "obj", "bin"}


def _files(root, limit=2000, max_depth=3):
    """只看浅层：深挖会掉进虚拟环境/依赖目录，把第三方自带文档误判成交付物。"""
    out = []
    base = root.rstrip(os.sep).count(os.sep)
    for dirpath, dirnames, filenames in os.walk(root):
        depth = dirpath.count(os.sep) - base
        dirnames[:] = [d for d in dirnames
                       if d not in SKIP_DIRS and not d.startswith(".")]
        if depth >= max_depth:
            dirnames[:] = []
            continue
        for name in filenames:
            out.append(os.path.join(dirpath, name))
            if len(out) >= limit:
                return out
    return out


def detect(root):
    files = _files(root)
    rel = [os.path.relpath(p, root).replace("\\", "/") for p in files]
    lower = [r.lower() for r in rel]

    def has_doc(stage):
        for group in DOC_PATTERNS.get(stage, []):
            for name, lname in zip(rel, lower):
                if not lname.endswith((".md", ".docx", ".pdf")):
                    continue
                if all(token.lower() in lname for token in group):
                    return name
        return None

    evidence = {}
    for stage in ("S1", "S2", "S4", "S5", "S7"):
        hit = has_doc(stage)
        if hit:
            evidence[stage] = hit
    code = [r for r in rel if os.path.basename(r) in CODE_HINTS
            or r.lower().endswith("requirements.txt")]
    if code:
        evidence["S3"] = code[0]
    videos = [r for r in rel if r.lower().endswith((".mp4", ".webm"))]
    images = [r for r in rel if "/images/" in r.lower()
              or "配图" in r or "diagram" in r.lower()]
    if videos or images:
        evidence["S6"] = (videos + images)[0]
    docx = [r for r in rel if r.lower().endswith((".pptx", ".docx"))]
    if docx and "S7" not in evidence:
        evidence["S7"] = docx[0]

    done = [s[0] for s in STAGES if s[0] in evidence]
    current = STAGES[len(done)][0] if len(done) < len(STAGES) else "DONE"
    return evidence, current


def init_layout(root):
    made = []
    for rel in ("docs", "demos/video", "demos/images", "demos/data",
                "work/runs", "work/scripts", "work/tmp", "deliver"):
        path = os.path.join(root, rel)
        if not os.path.isdir(path):
            os.makedirs(path)
            made.append(rel)
    index = os.path.join(root, "PROJECT_INDEX.md")
    if not os.path.isfile(index):
        with io.open(index, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("# 项目索引\n\n## 当前状态\n- 阶段：S0 立项\n"
                     "- 判定依据：目录骨架已建立\n- 下一步：补充需求说明\n\n"
                     "## 交付物清单\n| 阶段 | 交付物 | 路径 | 状态 | 备注 |\n"
                     "|---|---|---|---|---|\n\n## 待办与待拍板\n- [ ] \n\n"
                     "## 可清理项\n| 路径 | 大小 | 用途 | 是否已确认 |\n"
                     "|---|---|---|---|\n\n## 重建办法（清理前必须写）\n\n"
                     "## 清理记录\n")
        made.append("PROJECT_INDEX.md")
    return made


def main():
    ap = argparse.ArgumentParser(description="研发阶段判定")
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--init", action="store_true",
                    help="补齐 docs/demos/work/deliver 与 PROJECT_INDEX.md")
    args = ap.parse_args()
    root = os.path.abspath(args.root)
    if not os.path.isdir(root):
        print("目录不存在：%s" % root)
        return 2
    if args.init:
        made = init_layout(root)
        print("补齐：%s" % ("、".join(made) if made else "无需补齐"))
    evidence, current = detect(root)
    print("项目根：%s" % root)
    for code, label, _ in STAGES:
        hit = evidence.get(code)
        mark = "OK " if hit else "-- "
        print("  %s%-3s %-46s %s" % (mark, code, label, hit or "（未见特征产物）"))
    label = dict((c, l) for c, l, _ in STAGES).get(current, "全部阶段已产出")
    nxt = next((n for c, _l, n in STAGES if c == current), "交付与归档")
    print("\n当前阶段：%s %s" % (current, label))
    print("建议下一步：%s" % nxt)
    if current == "S6":
        print("开拍前先确认：演示对象、用例清单、期望结论、是否允许改演示侧数据。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
