# -*- coding: utf-8 -*-
"""阶段后检验门禁：conductor 自己核对"阶段交付物到底完不完整"。

用法：
    python scripts/deliverable_gate.py <项目根>                  # 该有的阶段全查
    python scripts/deliverable_gate.py <项目根> --stage S6        # 只查某一阶段
    python scripts/deliverable_gate.py <项目根> --markdown        # 另打印可粘进索引的结果块

只读脚本：不改动任何文件。有 FAIL 返回 1，全部具备返回 0。

判定口径是"内容特征"，不是"文件在不在"、更不是"讲稿/大纲里写没写"：
文件生成了但要素缺，一律判未完成；专项 skill 自己的验收器过了，也不免除本门禁。
"""
import argparse
import io
import json
import os
import re
import sys
import zipfile

# 控制台/管道一律按 UTF-8 输出，避免中文清单在 GBK 终端里变成乱码
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, 'reconfigure'):
        try:
            _stream.reconfigure(encoding='utf-8', errors='replace')
        except (ValueError, OSError):
            pass

STAGES = ('S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7')

# 成片必备画面要素：关键词命中即算具备（镜头标题里出现即算画面里有）
VIDEO_ELEMENTS = (
    ('片头/封面', ('片头', '封面')),
    ('总体架构', ('架构',)),
    ('业务痛点', ('痛点',)),
    ('创新点', ('创新',)),
    ('效益总结', ('效益', '收益')),
)
PPT_ELEMENTS = (
    ('封面', ('封面', '标题页')),
    ('总体架构', ('架构',)),
    ('创新点', ('创新',)),
    ('性能/指标', ('性能', '指标', '精度', '耗时')),
    ('效益/收尾', ('效益', '收益', '总结', '谢谢', '致谢')),
)
MIN_IMAGE_COUNT = 3
MIN_PPT_PAGES = 12

# 文档类阶段的检查口径：文件正则 + 必备要素（每组给可接受关键词）+ 规模下限
DOC_RULES = {
    'S1': dict(
        label='需求分析报告',
        pattern=r'需求分析报告|需求报告|需求说明',
        elements=(('需求条目/编号', ('需求编号', '需求ID', 'REQ-', '需求清单', '需求表', '需求项')),
                  ('用例/场景', ('用例', '场景')),
                  ('数据元素/字段', ('数据元素', '数据项', '字段'))),
        min_headings=4, min_table_rows=6),
    'S2': dict(
        label='详细设计报告',
        pattern=r'详细设计|方案设计|设计方案|设计说明|概要设计|设计报告|接口与页面规格',
        elements=(('总体架构', ('架构', '总体结构', '分层')),
                  ('模块/接口', ('模块', '接口')),
                  ('技术路线', ('技术路线', '技术方案', '技术选型', '实现方案')),
                  ('需求追溯/编号', ('追溯', '需求编号', 'REQ-', '对应需求'))),
        min_headings=5, min_table_rows=2),
    'S4': dict(
        label='测试大纲与执行记录',
        pattern=r'测试大纲|测试方案|测试用例',
        elements=(('用例编号', ('用例编号', '用例ID', 'TC-', '编号')),
                  ('正例+负例/边界', ('正常', '异常', '负例', '边界', '错误')),
                  ('通过准则', ('通过准则', '判定准则', '预期结果', '合格判据')),
                  ('执行记录/结果', ('执行记录', '执行结果', '测试结果', '实测', '测试记录'))),
        min_headings=4, min_table_rows=4),
    'S5': dict(
        label='技术总结与创新点报告',
        pattern=r'技术总结|创新点|技术报告|技术方案总结',
        elements=(('问题/痛点', ('痛点', '瓶颈', '现状', '问题')),
                  ('方法/机制', ('方法', '机制', '算法', '方案')),
                  ('效果/指标', ('效果', '指标', '提升', '降低', '%')),
                  ('创新点', ('创新', '突破'))),
        min_headings=4, min_table_rows=1),
}


def newest(root, pattern):
    """Return the newest file matching a regex under root (None if none)."""
    hits = []
    for base, _dirs, files in os.walk(root):
        for name in files:
            if re.search(pattern, name, re.I):
                path = os.path.join(base, name)
                hits.append((os.path.getmtime(path), path))
    return max(hits)[1] if hits else None


def find_docs(root, pattern):
    """All text-ish documents under docs/ whose filename matches pattern, newest first."""
    docs = os.path.join(root, 'docs')
    base = docs if os.path.isdir(docs) else root
    hits = []
    regex = re.compile(r'(?:%s).*\.(?:md|markdown|txt)$' % pattern, re.I)
    for walk_base, _dirs, files in os.walk(base):
        for name in files:
            if regex.search(name):
                path = os.path.join(walk_base, name)
                hits.append((os.path.getmtime(path), path))
    return [path for _mtime, path in sorted(hits, reverse=True)]


def find_doc(root, pattern):
    """Newest text-ish document under docs/ whose filename matches pattern."""
    hits = find_docs(root, pattern)
    return hits[0] if hits else None


def read_text(path):
    """Read a text file tolerantly (BOM / 编码差异都不该让门禁崩掉）。"""
    for enc in ('utf-8-sig', 'utf-8', 'gbk'):
        try:
            with io.open(path, encoding=enc) as handle:
                return handle.read()
        except (UnicodeDecodeError, LookupError):
            continue
    with io.open(path, encoding='utf-8', errors='replace') as handle:
        return handle.read()


def count_headings(text):
    """Number of markdown headings (any level)."""
    return len(re.findall(r'(?m)^#{1,6}\s+\S', text))


def count_table_rows(text):
    """Number of markdown table body rows (分隔行不算)."""
    rows = [ln for ln in text.splitlines()
            if ln.strip().startswith('|')
            and not re.match(r'^\s*\|[\s:|-]+\|\s*$', ln)]
    return len(rows)


def check_doc_stage(root, stage):
    """S1/S2/S4/S5: 报告是否存在、章节与必备要素是否到位、表是否成形。

    同一阶段可能由多份文档共同承担（正文 + 规格 + 接口说明），因此
    要素按全部命中文档的合并正文核对，规模取下限最大者。
    """
    rule = DOC_RULES[stage]
    rows = []
    paths = find_docs(root, rule['pattern'])
    rows.append(('%s文件' % rule['label'], bool(paths),
                 ('%d 份：%s' % (len(paths), '；'.join(paths[:3]))) if paths
                 else 'docs/ 下未找到，阶段未产出'))
    if not paths:
        return rows
    texts = [read_text(path) for path in paths]
    headings = max(count_headings(t) for t in texts)
    rows.append(('章节结构', headings >= rule['min_headings'],
                 '主文档 %d 个标题（要求 ≥%d）' % (headings, rule['min_headings'])))
    if rule['min_table_rows']:
        table_rows = max(count_table_rows(t) for t in texts)
        rows.append(('表格规模', table_rows >= rule['min_table_rows'],
                     '主文档 %d 行表格（要求 ≥%d；纯散文不算结构化交付）'
                     % (table_rows, rule['min_table_rows'])))
    merged = '\n'.join(texts)
    for label, keys in rule['elements']:
        hit = [k for k in keys if k in merged]
        rows.append((label, bool(hit),
                     ('命中 %s' % hit[0]) if hit else '正文里找不到该要素'))
    return rows


def check_code_stage(root):
    """S3: 平台工程——入口、依赖清单、界面资源、功能测试证据。"""
    rows = []
    entry = newest(root, r'^(?:main|app|run|manage|platManage|start)[\w-]*\.(?:py|js|ts)$') \
        or newest(root, r'^(?:package|pyproject)\.json$')
    rows.append(('工程入口', bool(entry), entry or '未找到入口脚本（main/app/manage…）'))
    deps = newest(root, r'(?:requirements[\w.-]*\.txt|pyproject\.toml|package\.json|environment\.ya?ml)$')
    rows.append(('依赖清单', bool(deps), deps or '未找到依赖清单，换机跑不起来'))
    ui = None
    for base in ('templates', 'static', 'web', 'ui'):
        cand = os.path.join(root, base)
        if os.path.isdir(cand):
            ui = cand
            break
    rows.append(('界面/模板资源', bool(ui), ui or '未找到 templates/static 等界面资源'))
    tests_dir = os.path.join(root, 'tests')
    evidence = newest(tests_dir, r'\.py$') if os.path.isdir(tests_dir) else None
    evidence = evidence or find_doc(root, r'测试大纲|测试方案|测试用例')
    rows.append(('功能测试证据', bool(evidence),
                 evidence or '既无 tests/ 也无测试文档，"能启动"代替不了"功能跑通"'))
    return rows


def newest_video(root):
    """Newest rendered video under demos/ (mp4/webm)."""
    demos = os.path.join(root, 'demos')
    return newest(demos if os.path.isdir(demos) else root, r'\.(mp4|webm)$')


def newest_manifest(root):
    """Newest pipeline manifest (shot list + film flags) if the pipeline left one."""
    for base in ('work', 'record', 'demos'):
        path = os.path.join(root, base)
        if os.path.isdir(path):
            found = newest(path, r'^manifest\.json$')
            if found:
                return found
    return None


def check_video(root):
    """S6: 要素在成片画面里、字幕非空、配图够数、镜头清单可证。"""
    rows = []
    video = newest_video(root)
    rows.append(('成片文件', bool(video), video or '未找到 demos/ 下的 mp4/webm'))
    titles = ''
    manifest = newest_manifest(root)
    if manifest:
        with io.open(manifest, encoding='utf-8') as handle:
            data = json.load(handle)
        shots = data.get('shots') or []
        titles = ' '.join(str(shot.get('title') or '') for shot in shots)
        ok_shots = bool(shots) and all(shot.get('status') == 'OK' for shot in shots)
        rows.append(('镜头完整性', ok_shots,
                     '%d 镜，NG %s' % (len(shots),
                                       [s.get('code') for s in shots
                                        if s.get('status') != 'OK'] or '无')))
        caps = os.path.join(os.path.dirname(manifest), 'captions.json')
        count = 0
        if os.path.isfile(caps):
            with io.open(caps, encoding='utf-8') as handle:
                count = len(json.load(handle))
        rows.append(('字幕轨', count > 0, 'captions.json %d 条' % count))
        if not titles:
            rows.append(('镜头标题', False, '清单里没有镜头标题，无法核对要素'))
    else:
        rows.append(('镜头清单', False,
                     '未找到 manifest.json：无法证明画面要素，按缺项处理'))
    for label, keys in VIDEO_ELEMENTS:
        hit = any(key in titles for key in keys)
        rows.append((label, hit, '命中' if hit else '成片缺少该要素（讲稿里写了不算）'))
    images = os.path.join(root, 'demos', 'images')
    count = len([n for n in os.listdir(images)
                 if n.lower().endswith(('.png', '.jpg', '.jpeg', '.svg'))
                 ]) if os.path.isdir(images) else 0
    rows.append(('配套配图', count >= MIN_IMAGE_COUNT,
                 'demos/images 共 %d 张（要求 ≥%d）' % (count, MIN_IMAGE_COUNT)))
    return rows


def pptx_slide_texts(path):
    """Slide texts of a pptx read straight from the zip (no python-pptx)."""
    texts = []
    with zipfile.ZipFile(path) as zf:
        names = [n for n in zf.namelist()
                 if re.match(r'ppt/slides/slide\d+\.xml$', n)]
        for name in sorted(names, key=lambda n: int(re.findall(r'\d+', n)[0])):
            xml = zf.read(name).decode('utf-8', 'replace')
            chunk = ' '.join(re.findall(r'<a:t>(.*?)</a:t>', xml, re.S))
            texts.append(chunk)
    return texts


def check_ppt(root):
    """S7: 汇报物存在、页数够、封面在首页、必备页都在。"""
    rows = []
    deliver = os.path.join(root, 'deliver')
    deck = newest(deliver, r'\.pptx$') if os.path.isdir(deliver) else None
    rows.append(('汇报文件', bool(deck), deck or '未找到 deliver/ 下的 pptx'))
    texts = pptx_slide_texts(deck) if deck else []
    all_text = ' '.join(texts)
    rows.append(('页数', len(texts) >= MIN_PPT_PAGES,
                 '共 %d 页（少于 %d 页按偷工减料处理）' % (len(texts), MIN_PPT_PAGES)))
    first = texts[0] if texts else ''
    rows.append(('首页即封面', bool(first.strip()), (first[:40] or '首页无文字')))
    for label, keys in PPT_ELEMENTS:
        hit = any(key in all_text for key in keys)
        rows.append((label, hit, '命中' if hit else '整套 PPT 缺少该要素页'))
    return rows


def check_index(root):
    """索引登记：门禁结论要落到 PROJECT_INDEX.md，否则下一轮无从复核。"""
    rows = []
    index = os.path.join(root, 'PROJECT_INDEX.md')
    rows.append(('项目索引', os.path.isfile(index),
                 index or '未找到 PROJECT_INDEX.md，阶段结论无处登记'))
    if os.path.isfile(index):
        text = read_text(index)
        rows.append(('门禁登记', '门禁' in text,
                     '索引里已登记门禁结论' if '门禁' in text
                     else '索引里没有门禁结论字段，无法证明做过后检验'))
    return rows


def check_stage(root, stage):
    """Dispatch one stage to its checker; unknown stage returns empty rows."""
    if stage in DOC_RULES:
        return check_doc_stage(root, stage)
    if stage == 'S3':
        return check_code_stage(root)
    if stage == 'S6':
        return check_video(root)
    if stage == 'S7':
        return check_ppt(root)
    return []


def report(title, rows):
    """Print one checklist and return the number of failures."""
    print('\n== %s ==' % title)
    bad = 0
    for label, ok, detail in rows:
        print('%-6s %-14s %s' % ('PASS' if ok else 'FAIL', label, detail))
        bad += 0 if ok else 1
    return bad


def print_markdown(summary):
    """Print index-ready rows: | 阶段 | 门禁 | 缺项 |."""
    print('\n可粘进 PROJECT_INDEX.md 交付物清单的行：\n')
    print('| 阶段 | 要素门禁 | 缺项 |')
    print('|---|---|---|')
    for stage, fails, total in summary:
        verdict = 'PASS（%d 项全过）' % total if not fails \
            else 'FAIL（缺 %d 项）' % len(fails)
        print('| %s | %s | %s |' % (stage, verdict, '；'.join(fails) or '无'))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('project_root', nargs='?', default='.')
    parser.add_argument('--stage', choices=list(STAGES) + ['all'], default='all')
    parser.add_argument('--markdown', action='store_true',
                        help='另打印可直接粘进 PROJECT_INDEX.md 的结果块')
    args = parser.parse_args()
    root = os.path.abspath(args.project_root)
    if not os.path.isdir(root):
        print('项目根不存在：%s' % root)
        return 2

    stages = STAGES if args.stage == 'all' else (args.stage,)
    bad = 0
    summary = []
    for stage in stages:
        rows = check_stage(root, stage)
        if not rows:
            continue
        failures = [label for label, ok, _ in rows if not ok]
        bad += report('%s 阶段后检验' % stage, rows)
        summary.append((stage, failures, len(rows)))
    bad += report('索引与登记', check_index(root))

    print('\n门禁结论：%s' % ('全部要素具备' if bad == 0
                              else '%d 项缺失，阶段未完成，不得进入下一阶段' % bad))
    if args.markdown:
        print_markdown(summary)
    return 0 if bad == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
