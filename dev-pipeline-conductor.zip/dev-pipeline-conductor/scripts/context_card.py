#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""打印"对齐卡"：L0 总目标 / L1 阶段 / L2 能力 / L3 任务 / 约束 / 关键路径。

用法（相对路径，随 skill 打包可迁移）：
    python scripts/context_card.py <项目根>            # 读 CONTEXT.md 打对齐卡
    python scripts/context_card.py <项目根> --init     # 没有就按模板建一份

设计目的：复杂平台开发时防止"钻局部忘了总目标"——每次开工先看这张卡，
并核对关键路径登记表里的路径是否真的存在（缺失项会列出来）。
"""
import argparse
import io
import os
import sys

TPL = """# 项目上下文（每步都以此为准）

## L0 总目标（一句话，不变）
（这套软件最终交付什么、给谁用、验收看什么）

## L1 环节（随阶段推进）
1. 需求报告 —— 状态：未开始；交付物：docs/需求分析报告.md
2. 方案设计 —— 状态：未开始；交付物：docs/详细设计报告.md
3. 平台开发 —— 状态：未开始；交付物：platform/
4. 测试 —— 状态：未开始；交付物：docs/测试大纲.md
5. 创新报告 —— 状态：未开始；交付物：docs/技术总结与创新点.md
6. 演示视频 —— 状态：未开始；交付物：demos/video/
7. 汇报物 —— 状态：未开始；交付物：deliver/

## L2 本环节要达成的能力
- （模块）：（可观测、可验收的达成标准）

## L3 当前任务（最多 3 条）
- [ ] （任务） → 服务于 L2：（哪一项）；影响路径：（相对路径）

## 约束
- 硬：（不得外链依赖 / 数据必须真实上传 / 演示侧可改、被测语义不得擅改）
- 偏好：（术语口径、命名、目录、风格）

## 关键路径登记
| 类别 | 路径 | 说明 |
|---|---|---|
| 平台入口 | platform/ | 启动命令与端口 |
| 数据 | demos/data/ | 结构与期望结论 |
| 文档 | docs/ | 上游依据 |
| 交付物 | demos/video/、deliver/ | 已验收/待验收 |

## 未决事项（等用户拍板）
- [ ] （口径/范围/优先级） —— 影响：（哪些任务先挂起）
"""

SECTIONS = ("L0 总目标", "L1 环节", "L2 本环节要达成的能力", "L3 当前任务",
            "约束", "关键路径登记", "未决事项")


def _read(path):
    with io.open(path, encoding="utf-8") as fh:
        return fh.read()


def _section(text, title):
    head = "## " + title
    start = text.find(head)
    if start < 0:
        return ""
    rest = text[start + len(head):]
    end = rest.find("\n## ")
    return (rest if end < 0 else rest[:end]).strip()


def _paths(text):
    out = []
    for line in _section(text, "关键路径登记").splitlines():
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if (len(cells) >= 2 and cells[1] and not cells[1].startswith("-")
                and cells[0] not in ("类别", "类型", "阶段")
                and cells[1] not in ("路径", "Path")):
            for item in cells[1].split("、"):
                item = item.strip()
                if item:
                    out.append(item)
    return out


def main():
    ap = argparse.ArgumentParser(description="打印项目对齐卡")
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--init", action="store_true", help="缺失时创建 CONTEXT.md")
    args = ap.parse_args()
    root = os.path.abspath(args.root)
    path = os.path.join(root, "CONTEXT.md")
    if not os.path.isfile(path):
        if not args.init:
            print("未找到 %s；加 --init 可按模板创建。" % "CONTEXT.md")
            return 1
        with io.open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(TPL)
        print("已创建 CONTEXT.md（请先填 L0 总目标与约束，再开工）")
    text = _read(path)
    print("=" * 68)
    for title in SECTIONS:
        body = _section(text, title)
        print("【%s】" % title)
        print(body if body else "（空——请补齐）")
        print("-" * 68)
    missing = [p for p in _paths(text)
               if not os.path.exists(os.path.join(root, p))]
    print("关键路径登记 %d 条" % len(_paths(text)))
    if missing:
        print("尚未落盘的登记路径（注意：可能是还没做，也可能是路径写错）")
        for p in missing:
            print("  - %s" % p)
    else:
        print("关键路径登记与磁盘一致。")
    todo = [l for l in _section(text, "L3 当前任务").splitlines()
            if l.strip().startswith("- [ ]")]
    print("L3 未完成任务 %d 条；未决事项 %d 条"
          % (len(todo), len([l for l in _section(text, "未决事项").splitlines()
                             if l.strip().startswith("- [ ]")])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
