#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""审查"本会话自己起的进程"，避免平台/浏览器/编码器空转占资源。

设计前提：**只允许处理本会话自己启动的进程**，绝不触碰会话外的其他进程。
因此这里不做"按进程名批量杀"，只按**命令行里显式携带的标记**匹配；
默认仅列出（只读），要真结束必须同时给 --match 与 --kill。

用法：
    python scripts/self_processes.py                        # 列出常驻类进程
    python scripts/self_processes.py --match <平台名>        # 只看命中标记的
    python scripts/self_processes.py --match <平台名> --kill # 仅结束这些

标记用"项目/平台唯一名"（平台目录名、自己起的脚本名）；不足 4 个字符拒绝执行。
"""
import argparse
import sys

KEEP_NAMES = ("python", "pythonw", "chrome", "msedge", "chromium", "ffmpeg",
              "ffprobe", "node", "java")


def _psutil():
    try:
        import psutil
    except Exception:
        return None
    return psutil


def main():
    ap = argparse.ArgumentParser(description="本会话进程自查")
    ap.add_argument("--match", default="", help="命令行中必须包含的标记")
    ap.add_argument("--kill", action="store_true", help="真正结束命中的进程")
    ap.add_argument("--min-mb", type=float, default=0.0,
                    help="只列内存大于该值的进程（MB）")
    args = ap.parse_args()
    if args.kill and len(args.match.strip()) < 4:
        print("拒绝执行：--kill 必须配合长度>=4 的 --match 标记，以免误伤会话外进程。")
        return 2
    psutil = _psutil()
    if psutil is None:
        print("未安装 psutil，无法自动自查。请人工核对命令行后再处理；"
              "注意：仍只允许处理本会话自己启动的进程。")
        return 1
    me = psutil.Process()
    rows, hits = [], []
    for proc in psutil.process_iter(["pid", "name", "cmdline", "memory_info"]):
        try:
            name = (proc.info["name"] or "").lower()
            if name.replace(".exe", "") not in KEEP_NAMES:
                continue
            if proc.pid == me.pid:
                continue
            cmd = " ".join(proc.info["cmdline"] or [])
            mb = (proc.info["memory_info"].rss / 1048576.0
                  if proc.info["memory_info"] else 0.0)
            if mb < args.min_mb:
                continue
            rows.append((proc.pid, proc.info["name"], round(mb, 1), cmd[:110]))
            if args.match and args.match.lower() in cmd.lower():
                hits.append(proc)
        except Exception:
            continue
    rows.sort(key=lambda r: -r[2])
    print("%-7s %-14s %8s  %s" % ("PID", "进程", "内存MB", "命令行（截断）"))
    for pid, nam, mb, cmd in rows[:25]:
        mark = " *" if args.match and args.match.lower() in cmd.lower() else "  "
        print("%-7s %-14s %8.1f%s%s" % (pid, nam, mb, mark, cmd))
    print("\n常驻类进程 %d 个；命中标记「%s」的 %d 个"
          % (len(rows), args.match or "-", len(hits)))
    if not args.match:
        print("下一步：从命令行里认出属于本会话的（平台名/自起脚本名），"
              "再用 --match <标记> 精确处理。")
        return 0
    if not args.kill:
        print("当前为只读模式；确认无误后加 --kill 才会结束这些进程。")
        return 0
    killed = 0
    for proc in hits:
        try:
            proc.terminate()
            killed += 1
        except Exception as exc:
            print("结束失败 %s：%s" % (proc.pid, exc))
    print("已结束 %d 个命中标记「%s」的进程（仅限本次自查命中的对象）"
          % (killed, args.match))
    return 0


if __name__ == "__main__":
    sys.exit(main())
