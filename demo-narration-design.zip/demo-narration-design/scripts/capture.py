# -*- coding: utf-8 -*-
"""高画质取帧：绕开 Playwright 自带的 recordVideo。

Playwright 的 recordVideo 出的是约 650 kbps 的 VP8，1920x1080 下细节全糊，
后段再高码率转码也救不回来。这里改用 CDP 的 Page.startScreencast 直接取
无损 PNG 帧，按时间戳展开成固定帧率，再用 H.264 高码率编码。
"""
import base64
import subprocess
import time

import cv2
import numpy as np


class ScreenCast(object):
    """CDP 无损取帧 + 固定帧率展开 + 高码率编码。"""

    def __init__(self, page, dest, ffmpeg, encoder="h264_mf", fps=25.0,
                 bitrate="24M"):
        self.page = page
        self.dest = dest
        self.fps = float(fps)
        self.frames = 0
        self.dups = 0
        self._ffmpeg = ffmpeg
        self._encoder = encoder
        self._bitrate = bitrate
        self._proc = None
        self._prev = None
        self._prev_ts = None
        self._first_ts = None
        self._first_wall = None
        self._size = None
        self._stopped = False
        self.cdp = page.context.new_cdp_session(page)
        self.cdp.on("Page.screencastFrame", self._on_frame)
        vp = page.viewport_size or {"width": 1920, "height": 1080}
        self.cdp.send("Page.startScreencast", {
            "format": "png", "quality": 100,
            "maxWidth": int(vp["width"]), "maxHeight": int(vp["height"]),
            "everyNthFrame": 1})

    def _on_frame(self, params):
        """事件回调里不能抛异常，否则会打断 Playwright 的事件泵。"""
        try:
            raw = base64.b64decode(params["data"])
            img = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
            ts = float(params["metadata"]["timestamp"])
            if img is not None:
                if self._first_ts is None:
                    self._first_ts, self._first_wall = ts, time.time()
                if self._prev is not None and self._prev_ts is not None:
                    gap = max(0.0, ts - self._prev_ts)
                    for _ in range(int(round(gap * self.fps))):
                        self._emit(self._prev)
                        self.dups += 1
                self._prev, self._prev_ts = img, ts
                self._emit(img)
        finally:
            try:
                self.cdp.send("Page.screencastFrameAck",
                              {"sessionId": params["sessionId"]})
            except Exception:
                pass

    def _emit(self, img):
        if self._proc is None:
            h, w = img.shape[:2]
            self._size = (w, h)
            self._proc = subprocess.Popen([
                self._ffmpeg, "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
                "-s", "%dx%d" % self._size, "-r", str(self.fps), "-i", "-",
                "-c:v", self._encoder, "-b:v", self._bitrate,
                "-pix_fmt", "yuv420p", "-loglevel", "error", self.dest],
                stdin=subprocess.PIPE)
        self._proc.stdin.write(img.tobytes())
        self.frames += 1

    def stop(self, tail=0.6):
        """收尾：补足"最后一帧之后"的整段静帧再关流。

        CDP 只在画面变化时给帧，静态页面（标题卡、等待中的看板）可能几秒
        都没有新帧。必须在收尾时按墙钟时间把尾部补齐，否则整镜会缩成 1 秒。
        """
        if self._stopped:
            return self.frames
        self._stopped = True
        try:
            self.cdp.send("Page.stopScreencast")
        except Exception:
            pass
        if self._prev is not None:
            wall = time.time() - (self._first_wall or time.time())
            media = (self._prev_ts or 0.0) - (self._first_ts or 0.0)
            hold = max(0.0, wall - media) + tail
            for _ in range(int(round(hold * self.fps))):
                self._emit(self._prev)
                self.dups += 1
        if self._proc is not None:
            self._proc.stdin.close()
            self._proc.wait(timeout=900)
        return self.frames
