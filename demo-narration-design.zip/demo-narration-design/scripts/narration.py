# -*- coding: utf-8 -*-
"""配音与字幕：从演示剧本抽讲解词，合成语音、生成逐句字幕。

本机没有 drawtext/subtitles 滤镜（ffmpeg 构建禁用了 libfreetype/libass），
所以字幕不用 ffmpeg 滤镜，改为用 PIL + 黑体把整句预渲染成透明贴图，
再逐帧 alpha 合成；语音用 Windows SAPI 离线合成，不依赖外网。
"""
import base64
import hashlib
import os
import re
import subprocess
import wave

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
# 便携：字体按「随附 → 系统」顺序找，换机器/换项目都不用改路径。
# 想让字体随 ZIP 一起走，就把字体放到 scripts/assets/font.ttf（可选）。
# 系统字体优先微软雅黑：比黑体细一档、横竖笔画更匀，压到视频上不糊。
FONT = os.path.join(os.path.dirname(_HERE), "static", "font", "simhei.ttf")
CAPTION_FONTS = (os.path.join(_HERE, "assets", "font.ttf"),
                 r"C:\Windows\Fonts\msyh.ttc",
                 r"C:\Windows\Fonts\msyhl.ttc",
                 FONT,
                 r"C:\Windows\Fonts\simhei.ttf")
DEFAULT_VOICE = "Microsoft Huihui Desktop"

# 讲解词要穿过 Python -> PowerShell 这道边界。走 stdin 时 PowerShell 会按本地
# 代码页（中文机是 cp936）解码，UTF-8 字节会被解成"看着像中文"的乱码字，
# TTS 念出来就是一串胡话。所以这里不赌某个写法：逐个 transport 试，先用
# 字符数 + SHA256 校验 PowerShell 真正收到的文本，一致才用它合成。
TRANSPORTS = ("base64-env", "file-utf8", "stdin-gbk", "stdin-utf8")
_CHOSEN = []

# 取文本的几句 PowerShell 片段，按 transport 拼在脚本前面
_DECODE = {
    "base64-env": ("$txt = [Text.Encoding]::UTF8.GetString("
                   "[Convert]::FromBase64String($env:NARR_B64))\n"),
    "file-utf8": ("$txt = [System.IO.File]::ReadAllText($env:NARR_TXT, "
                  "[Text.Encoding]::UTF8)\n"),
    "stdin-gbk": ("$txt = [Console]::In.ReadToEnd()\n"),
    "stdin-utf8": ("[Console]::InputEncoding = [Text.Encoding]::UTF8\n"
                   "$txt = [Console]::In.ReadToEnd()\n"),
}

_PS_HEAD = ("Add-Type -AssemblyName System.Speech\n"
            "Add-Type -AssemblyName System.Security\n")
_PS_TAIL = """
Write-Output ('NARR_CHARS=' + $txt.Length)
$sha = [Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($txt))
Write-Output ('NARR_SHA=' + [BitConverter]::ToString($sha).Replace('-','').ToLower())
"""
_PS_SPEAK = """
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.SelectVoice($env:NARR_VOICE)
$s.Rate = [int]$env:NARR_RATE
$s.Volume = 100
$s.SetOutputToWaveFile($env:NARR_OUT)
$s.Speak($txt)
$s.Dispose()
"""


def _ps_script(transport, speak):
    return _PS_HEAD + _DECODE[transport] + _PS_TAIL + (_PS_SPEAK if speak else "")


def _sha256(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _run_ps(text, transport, speak, wav_path, voice, rate):
    env = dict(os.environ, NARR_VOICE=voice, NARR_RATE=str(int(rate)),
               NARR_OUT=wav_path or "",
               NARR_TXT=(wav_path or "") + ".txt",
               NARR_B64=base64.b64encode(text.encode("utf-8")).decode("ascii"),
               PYTHONIOENCODING="utf-8")
    if transport.startswith("file-"):
        with open(env["NARR_TXT"], "w", encoding="utf-8", newline="") as f:
            f.write(text)
    stdin = None
    if transport == "stdin-gbk":
        stdin = text.encode("gbk", "replace")
    elif transport == "stdin-utf8":
        stdin = text.encode("utf-8")
    proc = subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-Command",
         _ps_script(transport, speak)],
        input=stdin, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
    out = proc.stdout.decode("utf-8", "replace")
    chars, sha = None, None
    for line in out.splitlines():
        if line.startswith("NARR_CHARS="):
            chars = int(line.split("=", 1)[1].strip())
        elif line.startswith("NARR_SHA="):
            sha = line.split("=", 1)[1].strip()
    return proc.returncode, chars, sha, out


# --------------------------------------------------------------------------
# 剧本解析：讲解词以剧本为唯一来源，避免脚本和剧本两处口径打架
# --------------------------------------------------------------------------
def load_script(path):
    """把剧本解析成 {S1: {"title":…, "narration":…}}。"""
    with open(path, encoding="utf-8") as f:
        text = f.read()
    out = {}
    # 兼容两种写法：`### S1 标题` 与 `### 镜头 S1 标题`
    parts = re.split(r"^###\s+(?:镜头\s*)?S(\d+[A-Z]?)\s+(.*)$", text, flags=re.M)
    # parts = [前言, "1", "开场（…）", 正文, "2", "…", 正文, ...]
    for i in range(1, len(parts), 3):
        code = "S" + parts[i]
        title = parts[i + 1].strip()
        body = parts[i + 2]
        # 兼容 `讲解词：…` 与 `- 讲解词：…`（列表项写法）
        m = re.search(r"^\s*-?\s*讲解词\s*[:：](.*?)(?:\n\s*\n|\Z)",
                      body, flags=re.M | re.S)
        if not m:
            continue
        # 剧本里的"兜底 / 画面 / 操作步骤 / 预期画面"是给人看的提醒，不是台词：
        # 段落间漏了空行时也会被吞进来，所以按字段标签硬切一刀。
        raw = re.split(
            r"\n\s*-?\s*(?:兜底|画面|操作|操作步骤|预期画面|四问定位|备注|说明|"
            r"真值来源|证据来源|来源|录制|剪辑)\s*[:：]", m.group(1))[0]
        out[code] = {"title": title, "narration": normalize(raw)}
    return out


_CJK = "\u4e00-\u9fff\u3000-\u303f\uff00-\uffef"


def normalize(text):
    """把剧本里因换行/排版产生的空白收干净。

    剧本为了可读会硬换行，拼回来时若直接补空格，就会在中文句子中间塞进空格：
    字幕里会显示成断开的字，TTS 也会照读成停顿。这里只保留中英文之间的
    必要空格，中文与中文之间的空白一律删掉。
    """
    text = re.sub(r"\s+", " ", text).strip()
    prev = None
    while prev != text:
        prev = text
        text = re.sub(r"(?<=[%s])\s+(?=[%s])" % (_CJK, _CJK), "", text)
    return text


def split_sentences(text, limit=25):
    """切字幕：每条不超过 limit 字，且**不带句号**（句号只用于断句，不进字幕）。

    语义优先：先按句末标点断句，句内只允许在标点处断开
    （逗号/顿号/分号/冒号，标点跟随前一条），保证短语不会被切成两条字幕。
    只有当某一段**整段都没有标点**时才退化为按长度断，并尽量落在
    数字/括号这类软边界上。末端的句号一律去掉。
    """
    text = normalize(text)
    out = []
    for seg in re.split(r"(?<=[。！？；])", text):
        out.extend(_split_by_punctuation(seg.strip(), limit))
    # 去句号后还可能变空：25 字边界正好落在句号前时，会切出一个只含"。"的片段。
    # 空字幕会直接让 render_caption 的 max() 抛异常，必须在返回前清掉。
    cleaned = [c.strip().rstrip(u"。").strip() for c in out]
    return [c for c in cleaned if c]


_HARD_BREAK = u"，、；：,;"
_SOFT_TAIL = u"）)》】」”’"


def _soft_cut(window):
    """整段无标点时的兜底断点：右括号之后 > 数字/文字交界。

    连词（和/与/及/或/并）**不做**断点：切开并列短语同样属于"短语被切成两条"。
    遇到这种文案应当改稿（补标点或缩句），而不是靠切分补救。
    """
    for i in range(len(window), 0, -1):
        if window[i - 1] in _SOFT_TAIL:
            return i
    for i in range(len(window), 0, -1):
        if i >= len(window):
            continue
        left, right = window[i - 1], window[i]
        if left.isdigit() != right.isdigit():
            return i
    return len(window)


def _split_by_punctuation(seg, limit):
    """句内切分：只在小句边界断，小句整体不拆；超长小句才按软边界降级。"""
    if not seg:
        return []
    if len(seg) <= limit:
        return [seg]
    pieces, rest = [], seg
    while len(rest) > limit:
        window = rest[:limit]
        cut = max(window.rfind(ch) for ch in _HARD_BREAK)
        if cut > 0:
            pieces.append(rest[:cut + 1])       # 标点跟随前一条，不留给下一条
            rest = rest[cut + 1:]
        else:
            cut = _soft_cut(window)             # 整段无标点，只能按软边界断
            if cut >= len(window):
                import sys as _sys
                _sys.stderr.write(
                    "[字幕告警] 该小句超过 %d 字且无标点，已按长度断，建议改稿：%r\n"
                    % (limit, rest[:limit + 12]))
            pieces.append(rest[:cut])
            rest = rest[cut:]
        rest = rest.lstrip()
    if rest:
        pieces.append(rest)
    return [p for p in pieces if p]


# 只给剪辑师看的字段名：一旦带着冒号出现在"要画到画面上的文字"里，就是泄漏
_NOTE_LABEL = re.compile(
    u"(?:兜底|画面|操作|操作步骤|预期画面|四问定位|备注|说明|真值来源|证据来源|"
    u"来源|录制|剪辑|拍摄|机位)\\s*[:：]")

# 制作侧自述：画面文字若以"演示/录制/剪辑"为主语，就是把内部草稿讲给观众听。
# 注意只拦这些自指标志词，不拦"手动执行脚本"这类描述平台前身的正当表述。
_DEMO_TALK = re.compile(
    u"本视频|本演示|演示视频|本片|该视频|该演示|镜头|剪辑|补拍|画外音|配音|字幕|"
    u"素材|草稿|分镜|录屏|拍摄|演示稿")


def assert_no_note(text, where=""):
    """硬门禁：画面上（字幕/标签）不得出现"字段名：…"这类剪辑说明。

    台词里出现"操作人员"不算——只有"字段名紧跟冒号"才算泄漏。
    另外拦截"制作侧自述"：画面文字的主语必须是平台/业务/数据/结论，
    不能是演示、录制、剪辑本身。
    """
    m = _NOTE_LABEL.search(text or "")
    if m:
        raise ValueError(
            "画面上出现剪辑说明字段「%s」（%s）：%r —— 检查剧本段落空行与字段标签切分"
            % (m.group(0), where, (text or "")[:60]))
    d = _DEMO_TALK.search(text or "")
    if d:
        raise ValueError(
            "画面上出现制作侧自述「%s」（%s）：%r —— 画面文字只能描述平台本身，"
            "不得描述演示/录制/剪辑" % (d.group(0), where, (text or "")[:60]))
    return text


def split_narration(text):
    """配音分段：按句末标点整句合成，保证朗读节奏自然。

    与 split_sentences 的区别：字幕要短（≤25 字）所以会切细，配音若也切细
    就会因为句间停顿把整镜撑长；所以配音按整句、字幕在句内再切。
    """
    text = normalize(text)
    return [c.strip() for c in re.split(r"(?<=[。！？；])", text) if c.strip()]


# --------------------------------------------------------------------------
# 语音合成
# --------------------------------------------------------------------------
def synthesize(text, wav_path, voice=DEFAULT_VOICE, rate=0):
    """用 Windows SAPI 合成中文语音，返回时长（秒）。

    逐个 transport 试，用字符数 + SHA256 校验 PowerShell 真正收到的文本；
    一致才用它合成，否则自动换下一种，并记住可用的那种。全部不一致就报错，
    绝不静默念出乱码。
    """
    want_len, want_sha = len(text), _sha256(text)
    order = _CHOSEN + [t for t in TRANSPORTS if t not in _CHOSEN]
    tried = []
    for transport in order:
        try:
            rc, chars, sha, out = _run_ps(text, transport, False, wav_path,
                                          voice, rate)
        except Exception as exc:
            tried.append("%s(调用失败:%s)" % (transport, exc))
            continue
        if rc != 0:
            tried.append("%s(退出码 %s)" % (transport, rc))
            continue
        if chars == want_len and sha == want_sha:
            if transport not in _CHOSEN:
                _CHOSEN.insert(0, transport)
            rc2, _c, _s, out2 = _run_ps(text, transport, True, wav_path,
                                        voice, rate)
            if rc2 != 0 or not os.path.isfile(wav_path):
                raise RuntimeError("语音合成失败：%s" % out2[:300])
            return wav_duration(wav_path)
        tried.append("%s(%s 字/%s)" % (transport, chars,
                                       "sha 不符" if chars == want_len else "长度不符"))
    raise RuntimeError(
        "讲解词传递全部 transport 均校验失败，拒绝合成乱码音频。"
        "期望 %d 字 sha=%s…；实测：%s"
        % (want_len, want_sha[:12], "；".join(tried)))


def wav_duration(path):
    with wave.open(path, "rb") as w:
        return w.getnframes() / float(w.getframerate())


def read_wav(path):
    """读成单声道 float32，返回 (samples, rate)。"""
    with wave.open(path, "rb") as w:
        rate = w.getframerate()
        ch = w.getnchannels()
        width = w.getsampwidth()
        raw = w.readframes(w.getnframes())
    dtype = {1: np.uint8, 2: np.int16, 4: np.int32}[width]
    data = np.frombuffer(raw, dtype=dtype).astype(np.float32)
    if width == 2:
        data /= 32768.0
    elif width == 4:
        data /= 2147483648.0
    elif width == 1:
        data = (data - 128.0) / 128.0
    if ch > 1:
        data = data.reshape(-1, ch).mean(axis=1)
    return data, rate


def write_wav(path, samples, rate):
    clipped = np.clip(samples, -1.0, 1.0)
    pcm = (clipped * 32767.0).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())
    return path


def fit_length(samples, rate, target_seconds):
    """把一段语音拉伸/压缩到目标时长（轻微变速，用线性重采样）。"""
    want = int(target_seconds * rate)
    if want <= 0 or samples.size == 0:
        return np.zeros(max(want, 0), np.float32)
    if samples.size == want:
        return samples
    idx = np.linspace(0, samples.size - 1, want)
    return np.interp(idx, np.arange(samples.size), samples).astype(np.float32)


# --------------------------------------------------------------------------
# 字幕：整句预渲染成 RGBA 贴图，逐帧 alpha 合成
# --------------------------------------------------------------------------
def caption_font_path():
    for p in CAPTION_FONTS:
        if os.path.isfile(p):
            return p
    return FONT


def render_caption(text, font_path=None, size=44, max_chars=26,
                   max_width=1520, pad_x=30, pad_y=16):
    """把一句话渲染成 RGBA 字幕贴图。

    样式：微软雅黑 + 黑色描边（保证压在亮画面上也读得清）
        + 半透明灰底圆角块 + 居中；每行限 26 字，最多两行。
    """
    from PIL import Image, ImageDraw, ImageFont
    font_path = font_path or caption_font_path()
    font = ImageFont.truetype(font_path, size)
    probe = Image.new("RGBA", (10, 10))
    draw = ImageDraw.Draw(probe)

    lines, cur = [], ""
    for ch in text:
        if len(cur) >= max_chars or draw.textlength(cur + ch, font=font) > max_width:
            lines.append(cur)
            cur = ch
        else:
            cur += ch
    if cur:
        lines.append(cur)

    stroke = max(2, int(size * 0.07))
    line_h = int(size * 1.42)
    text_w = max(draw.textlength(ln, font=font) for ln in lines)
    w = int(text_w) + pad_x * 2 + stroke * 2
    h = line_h * len(lines) + pad_y * 2

    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # 半透明灰底：中性灰、四角圆润，边缘留 1px 浅色描边让底板有边界
    draw.rounded_rectangle([0, 0, w - 1, h - 1], radius=14,
                           fill=(58, 62, 68, 168),
                           outline=(200, 208, 216, 46), width=1)
    for i, ln in enumerate(lines):
        x = (w - draw.textlength(ln, font=font)) / 2
        y = pad_y + i * line_h
        draw.text((x, y), ln, font=font, fill=(255, 255, 255, 255),
                  stroke_width=stroke, stroke_fill=(0, 0, 0, 220))
    return np.array(img)


def paste_rgba(frame_bgr, rgba, cx, bottom_margin=64):
    """把 RGBA 贴图居中贴在 BGR 帧的底部。"""
    h, w = rgba.shape[:2]
    fh, fw = frame_bgr.shape[:2]
    if h > fh or w > fw:
        return frame_bgr
    x = max(0, int(cx - w / 2))
    y = max(0, fh - bottom_margin - h)
    roi = frame_bgr[y:y + h, x:x + w].astype(np.float32)
    a = (rgba[:, :, 3:4].astype(np.float32)) / 255.0
    rgb = rgba[:, :, 2::-1].astype(np.float32)          # RGBA -> BGR
    frame_bgr[y:y + h, x:x + w] = (rgb * a + roi * (1 - a)).astype(np.uint8)
    return frame_bgr


def paste_at(frame_bgr, rgba, x, y):
    """把 RGBA 贴图贴到指定左上角。"""
    h, w = rgba.shape[:2]
    fh, fw = frame_bgr.shape[:2]
    if y + h > fh or x + w > fw:
        return frame_bgr
    roi = frame_bgr[y:y + h, x:x + w].astype(np.float32)
    a = rgba[:, :, 3:4].astype(np.float32) / 255.0
    rgb = rgba[:, :, 2::-1].astype(np.float32)
    frame_bgr[y:y + h, x:x + w] = (rgb * a + roi * (1 - a)).astype(np.uint8)
    return frame_bgr


def render_chapters(width, labels, active, height=46, font_path=None, size=20):
    """片内时间轴：每个镜头一个长方形，当前镜蓝底白字，其余白底黑字。"""
    from PIL import Image, ImageDraw, ImageFont
    font_path = font_path or caption_font_path()
    font = ImageFont.truetype(font_path, size)
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    n = max(1, len(labels))
    gap = 8
    seg = (width - gap * (n - 1)) / float(n)
    for i, lab in enumerate(labels):
        assert_no_note(lab, "时间轴分段名")
        x0 = int(round(i * (seg + gap)))
        x1 = int(round(x0 + seg))
        on = (i == active)
        d.rounded_rectangle(
            [x0, 0, x1 - 1, height - 1], radius=9,
            fill=(29, 78, 216, 238) if on else (255, 255, 255, 216),
            outline=(29, 78, 216, 210) if on else (150, 162, 176, 180), width=1)
        tw = d.textlength(lab, font=font)
        d.text((x0 + (seg - tw) / 2.0, (height - size) / 2.0 - 2), lab,
               font=font,
               fill=(255, 255, 255, 255) if on else (26, 32, 44, 255))
    return np.array(img)


def annotate_frame(frame_bgr, box, label, font_path=None, size=34,
                   dim=0.62, tint=(34, 211, 238)):
    """定格标注：整帧压暗 + 亮色方框 + 标签牌，用于暂停画面讲解。"""
    from PIL import Image, ImageDraw, ImageFont
    font_path = font_path or caption_font_path()
    img = Image.fromarray(frame_bgr[:, :, ::-1]).convert("RGB")
    img = Image.fromarray((np.asarray(img).astype(np.float32) * dim)
                          .astype(np.uint8)).convert("RGB")
    draw = ImageDraw.Draw(img)
    x, y, w, h = box
    stroke = max(3, int(size * 0.12))
    draw.rectangle([x, y, x + w, y + h], outline=tuple(tint), width=stroke)

    font = ImageFont.truetype(font_path, size)
    probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    tw = probe.textlength(label, font=font)
    pad_x, pad_y = 16, 10
    bw, bh = int(tw) + pad_x * 2, size + pad_y * 2
    bx = min(max(x, 8), img.width - bw - 8)
    by = y - bh - 10 if y - bh - 10 > 8 else y + h + 10
    by = min(by, img.height - bh - 8)
    draw.rounded_rectangle([bx, by, bx + bw, by + bh], radius=10,
                           fill=tuple(tint))
    draw.text((bx + pad_x, by + pad_y - 2), label, font=font,
              fill=(8, 14, 22))
    return np.asarray(img)[:, :, ::-1].copy()


def build_caption_track(chunks, start, end):
    """把若干句按字数比例铺满 [start, end]，返回 [(t0, t1, 贴图)]。"""
    total = sum(len(c) for c in chunks) or 1
    span = max(end - start, 0.1)
    track, t = [], start
    for i, c in enumerate(chunks):
        share = span * len(c) / total
        t1 = end if i == len(chunks) - 1 else t + share
        track.append((t, t1, render_caption(c)))
        t = t1
    return track


def synth_sentences(chunks, wav_path, voice=DEFAULT_VOICE, rate=0, gap=0.25):
    """逐句合成再拼接，返回 (总时长, [(t0, t1, 句子)])。

    字幕窗口直接来自每句音频的真实时长——音字由构造保证对齐；
    之前按字数比例把字幕铺在镜头上，和 TTS 的实际节奏对不上，就会漂移。
    """
    parts, spans, t = [], [], 0.0
    for i, s in enumerate(chunks):
        p = "%s.p%d.wav" % (wav_path, i)
        d = synthesize(s, p, voice, rate)
        data, sr = read_wav(p)
        parts.append((data, sr))
        spans.append((round(t, 3), round(t + d, 3), s))
        t += d + gap
    if not parts:
        return 0.0, []
    rate0 = parts[0][1]
    total = max(0.0, t - gap)
    buf = np.zeros(int(total * rate0) + rate0, np.float32)
    for (data, sr), (t0, _t1, _s) in zip(parts, spans):
        if sr != rate0:
            data = fit_length(data, sr, data.size / float(sr))
        i0 = int(t0 * rate0)
        buf[i0:i0 + data.size] += data
    write_wav(wav_path, buf, rate0)
    return total, spans


def caption_track_from_spans(spans, offset, gap=0.14, min_show=0.9, log=None):
    """把逐句音频时间窗平移到成片时间轴，渲染成字幕贴图。

    每句音频内再按"≤25 字、不带句号"切成多条字幕，条内按字数分配显示时间
    （句级边界仍严格对齐音频，误差只落在句内）。
    出现/消失机制：相邻两条之间强制留 gap 秒空档（唱完就撤，不留残影），
    后一条的显示窗不得越过前一条起点；每条的显示时间不小于 min_show。
    """
    raw = []
    n = len(spans)
    for i, (t0, t1, text) in enumerate(spans):
        a0, b0 = offset + t0, offset + t1
        nxt = offset + spans[i + 1][0] if i + 1 < n else None
        if nxt is not None:
            b0 = min(b0, nxt - gap)
        subs = split_sentences(text)
        total = sum(len(s) for s in subs) or 1
        t = a0
        for j, s in enumerate(subs):
            share = (b0 - a0) * len(s) / total
            raw.append((t, b0 if j == len(subs) - 1 else t + share, s))
            t += share
    out = []
    for i, (a, b, s) in enumerate(raw):
        nxt = raw[i + 1][0] if i + 1 < len(raw) else None
        if nxt is not None:
            b = min(b, nxt - gap)
        if b - a < min_show:
            b = a + min_show
            if nxt is not None:
                b = min(b, nxt - gap)
        if b > a:
            assert_no_note(s, "字幕")
            out.append((a, b, render_caption(s)))
            if log is not None:
                log.append({"t0": round(a, 2), "t1": round(b, 2), "text": s})
    return out
