# 镜头数据化：换平台只改 shots.json

镜头层是唯一与具体平台强相关的部分。**把它写成数据**，移植时就不必改 Python——
`director.py` 负责"摄像机"（取帧、配音、字幕、拼接、叠层、校验），`shot_runner.py` 负责
把 JSON 里的动作翻译成页面操作，两者都不含业务选择器。

## 用法

```bat
python -B scripts\director.py --shots-file scripts\shots.example.json --narrate
```

## 动作表（step 的类型）

| 动作 | 参数 | 作用 |
|---|---|---|
| `goto` | 路径（相对 base） | 打开页面 |
| `wait` | 秒 | 停留，让画面铺开 |
| `title_card` | line1/line2/foot | 直接渲染标题卡（片头用，不依赖平台） |
| `expect_text` | 文案 或 {text, timeout} | 等某段文字出现（同时也是断言） |
| `expect_selector` | css / what / timeout | 等某个元素出现；耗时的操作（训练等）要给足 timeout |
| `click` | role+name 或 selector | 点击按钮/元素 |
| `fill` | selector / text | 往输入框里填文本（如新建产品名） |
| `scroll` | "bottom" / "top" / {selector} | 滚动页面：结果区常在折叠下方，动作之后要滚到展示区再取证 |
| `select` | nth / option / exact / type | 选下拉框：先点 el-select →（remote 时输关键字）→ 点浮层选项 → **Esc 关浮层** → **校验值已写入**。`exact` 默认 true；整组选项标签形如「【全组】Y1（50）」，用 `exact:false`；`filterable remote` 必须先给 `type` 关键字。**多选下拉不校验就会出现"点了但没生效、门禁静默不过"**（实测踩过） |
| ↑ 幂等要求 | — | **multiple 下拉点已选项 = 取消选择**，而平台往往持久化映射；重跑同一镜前必须先判"是否已选中"，否则第二次跑会把上一次的选择取消掉（实测踩过） |

### 已知坑：`multiple + collapse-tags` 的幂等判断不可靠

用 `inner_text()` 判断"是否已选中"在 `collapse-tags` 下会失效——折叠后只显示前 1 个标签（其余变成
`+N`），于是"已有其它项"会被误判、点击又落到已选项上，标签数反而从 1 变 0（实测报
`选前 1 / 选后 0`）。两条可行的修法：

1. 读真实值而不是文本：`page.evaluate` 取该组件绑定的数组，或用 `.el-select__tags .el-tag`
   的 `title`/`data-*` 属性逐个比对；
2. **更省事也更稳**：录前把平台状态归零（删产品 / 清库），让每次录制都从"未选"开始，
   幂等问题就不存在。演示本来就该从干净状态开始，这也符合"可复现"的要求。
| `click_row_action` | row_text / button | **表格固定列专用**：先按数据行序号，再点同序号的按钮 |
| `upload` | click / selector / file | 接管原生文件框并把文件塞进去 |
| `mark` | selector 或 click + label + hold | 定格画框标注；可先点再标 |
| `still` | 标签 | 存一张静帧供质检 |
| `assert_text_count` | selector / expect | 断言某处数字 |
| `wait_external` | kind / value | 等外部时序推进（如外部程序报的秒数） |
| `wait_until_event` | keyword / mark_label / hold / timeout | 等某类事件出现并顺手加框标注 |
| `call` | 自定义钩子名 | 逃生口：真正特殊的动作才写 Python |

## 移植清单（对方只需做这些）

1. 复制 `shots.example.json` 为自己的 `shots.json`；
2. 把 `base` 与所有 `<...>` 占位符换成自己的地址、路径、按钮文案、选择器、文件路径；
3. 跑 `python scripts\doctor.py` 备齐环境；
4. 先只留一个镜头跑通（`--shots S2`），确认"打开页面 → 断言元素 → 存静帧"这条最小链路；
5. 再逐镜补齐动作，最后跑全片。

**不需要**改 `capture.py / narration.py / film.py / doctor.py`；`director.py` 只在
项目根目录约定不同时改一次（或用环境变量 `DEMO_PROJECT_ROOT`）。

## 为什么要这样设计

之前镜头动作是写成 Python 函数的，等于每个新平台都要重写一遍录屏脚本——这是把适配成本
错误地转嫁给了使用者。数据化之后，平台差异全部收在 `shots.json` 的字符串里，动作语义由
`shot_runner.py` 统一实现（按钮点击、固定列行号对齐、原生文件框接管这些坑都只解一次）。
