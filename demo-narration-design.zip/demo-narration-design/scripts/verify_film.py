# -*- coding: utf-8 -*-
"""成片验收器：按《成片要素与数据形态》的清单核对已出片的 run 目录。

用法：
    python scripts/verify_film.py <run目录>

核对项：素材完整性 / 字幕合规（≤25 字、无句号、无剪辑说明、空档≤3s）/
时间轴与封面 / 技术条覆盖 / 音视频编码。任一项不过，退出码非 0。
"""
import io
import json
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import narration as N  # noqa: E402

OK, BAD, WARN = "PASS", "FAIL", "WARN"
CHAPTERS_REQUIRED = ("封面", "架构", "痛点", "创新")


def check(cond, tag, msg, level=BAD):
    return (OK if cond else level, tag, msg)


def streams(path):
    # 用与录制同一套查找逻辑（本地 tools/ → PATH → 系统安装目录）
    try:
        import director
        exe = director.find_h264_ffmpeg()[0] or "ffmpeg"
    except Exception:
        exe = "ffmpeg"
    try:
        return subprocess.run([exe, "-hide_banner", "-i", path, "-f", "null",
                               os.devnull], stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT,
                              timeout=180).stdout.decode("utf-8", "replace")
    except Exception:
        pass
    return ""


def main(run):
    res = []
    man = os.path.join(run, "manifest.json")
    if not os.path.isfile(man):
        print("找不到清单：%s" % man)
        return 2
    m = json.load(io.open(man, encoding="utf-8"))
    shots = [s for s in m.get("shots", []) if s.get("status") == "OK"]
    ng = [s["code"] for s in m.get("shots", []) if s.get("status") != "OK"]
    film = m.get("film", {})
    fp = os.path.join(run, film.get("path", ""))

    res.append(check(not ng, "镜头完整性", "NG 镜头：%s" % (ng or "无")))
    titles = " ".join(s.get("title", "") for s in shots)
    for kw in CHAPTERS_REQUIRED:
        res.append(check(kw in titles, "成片要素", "缺少「%s」类镜头" % kw))

    caps = []
    cp = os.path.join(run, "captions.json")
    if os.path.isfile(cp):
        caps = json.load(io.open(cp, encoding="utf-8"))
    res.append(check(bool(caps), "字幕轨", "captions.json %d 条" % len(caps)))
    if caps:
        longest = max(len(c["text"]) for c in caps)
        res.append(check(longest <= 25, "字幕长度", "最长 %d 字" % longest))
        dots = [c["text"] for c in caps if "。" in c["text"]]
        res.append(check(not dots, "字幕无句号", "含句号 %d 条" % len(dots)))
        leak = []
        for c in caps:
            try:
                N.assert_no_note(c["text"], "字幕")
            except Exception:
                leak.append(c["text"][:20])
        res.append(check(not leak, "无剪辑说明", "泄漏 %s" % (leak or "无")))
        gaps, prev = 0.0, 0.0
        for c in caps:
            gaps = max(gaps, c["t0"] - prev)
            prev = c["t1"]
        res.append(check(gaps <= 3.0, "字幕空档", "最长无字幕 %.1fs" % gaps))
        ov = sum(1 for a, b in zip(caps, caps[1:]) if b["t0"] < a["t1"] - 0.01)
        res.append(check(ov == 0, "字幕不重叠", "重叠 %d 处" % ov))

    if fp and os.path.isfile(fp):
        info = streams(fp)
        res.append(check("h264" in info, "编码 H.264",
                         "视频流 %s" % ("h264" if "h264" in info else "非 H.264")))
        res.append(check("Audio:" in info, "含音轨",
                         "音频 %s" % ("有" if "Audio:" in info else "无")))
    else:
        res.append(check(False, "成片文件", "未找到 %s" % fp))

    spec = None
    for cand in ("shots.json", "mechtest_shots.json"):
        p = os.path.join(run, cand)
        if os.path.isfile(p):
            spec = json.load(io.open(p, encoding="utf-8"))
            break
    if spec and spec.get("rail"):
        res.append(check(True, "技术条声明", "%d 个状态图"
                         % len(spec["rail"].get("images") or [])))
    if spec and spec.get("chapters"):
        res.append(check(True, "时间轴声明", "%d 个阶段"
                         % len(spec["chapters"])))

    # 逐镜台账：标题里有"封面/架构/创新"不等于那段画面真的到位。
    # 一次性核对三件事：时长账一致、定格标注落在画面窗口内、代表帧非空。
    try:
        import audit_timeline
        rows, problems, _audio, _film = audit_timeline.audit(run)
        res.append(check(not problems, "逐镜台账",
                         "；".join(problems) if problems else
                         "%d 镜，画面 %.1fs，代表帧非空" % (
                             len(rows), rows[-1]["end"] if rows else 0)))
    except Exception as exc:  # noqa: BLE001
        res.append(check(False, "逐镜台账", "审计失败：%s" % exc))

    bad = 0
    print("%-6s %-12s %s" % ("结果", "检查项", "说明"))
    for st, tag, msg in res:
        if st == BAD:
            bad += 1
        print("%-6s %-12s %s" % (st, tag, msg))
    print("\n合计：%d 项检查，%d 项未通过" % (len(res), bad))
    return 1 if bad else 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
