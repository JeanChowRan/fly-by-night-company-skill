# -*- coding: utf-8 -*-
"""效果演示视频录制器：Playwright 无头驱动 + 内建录制。

定位：这是"摄像机"，既不属于软件平台，也不属于数据源端。
  - 不修改软件平台与数据源端任何代码；
  - 默认 headless：不弹任何可见窗口，后台完成点击、上传与录制；
  - 按《演示剧本》逐镜录制，每镜一个独立视频文件；
  - 每镜带断言：画面一旦出现错误提示（例如 LLM 生成失败），该镜立即标记 NG，
    不产出可用素材，避免把出错画面拼进成片。

Run:
  python -B record\\director.py --list
  python -B record\\director.py --shots S1,S2,S3,S5
  python -B record\\director.py --shots all --mp4
  python -B record\\director.py --shots S3 --headed     # 调试：显示窗口
"""
import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import traceback
import urllib.request
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import narration  # noqa: E402  （配音与字幕，见 record/narration.py）
import capture    # noqa: E402  （CDP 无损取帧，见 record/capture.py）
import shot_runner  # noqa: E402 （镜头数据化：换平台只改 shots.json）

# 便携：默认假设脚本放在 <项目>/record/ 下；换项目时用环境变量
# DEMO_PROJECT_ROOT 或命令行 --project 指过去，不必改代码。
ROOT = (os.environ.get("DEMO_PROJECT_ROOT")
        or os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
APP = (os.environ.get("DEMO_PLATFORM_ENTRY")
       or os.path.join(ROOT, "<PLATFORM_ENTRY>.py"))
SENDER_APP = (os.environ.get("DEMO_SENDER_ENTRY")
              or os.path.join(ROOT, "demo", "<SENDER_ENTRY>.py"))
SCRIPT = (os.environ.get("DEMO_SCRIPT_MD")
          or os.path.join(ROOT, "demo", "<SCRIPT_MD>"))
SUPPORT = os.path.join(ROOT, "support")
SAMPLE_ZIP = os.path.join(SUPPORT, "<CONFIG_ZIP>")
SAMPLE_DOC = os.path.join(SUPPORT, "<PROTOCOL_DOC>")

PORT = int(os.environ.get("DEMO_PLATFORM_PORT", "8500"))
BASE = "http://127.0.0.1:%d" % PORT
READY_PATH = os.environ.get("DEMO_READY_PATH", "/stream/meta")
SENDER_PORT = 8770
SENDER_BASE = "http://127.0.0.1:%d" % SENDER_PORT
VIEW_W, VIEW_H = 1920, 1080
DEFAULT_FPS = 25.0

# 合成层规格：由 --shots-file 里的 rail / chapters 段声明；为空则用内置默认
RAIL_SPEC = None
CHAPTER_SPEC = None

# 数据源端固定时序（demo/<SENDER_ENTRY>.py::_fault_schedule，按 RUN 后秒计）。
# 这不是可调参数：_fault_schedule 与 demo_mixed_sender 的 normal_sec/fault_sec
# 都写死为 30/30，镜头窗口必须对齐它，否则拍出来的是错相位。
#
# 为什么是 30/20 而不是更短：实测时序引擎冷启动建基线约需 20s，图像通道处理
# 有积压：故障起点到报出事件要等 15-22s（监视页每 2s 拉一次视频快照还会再抢帧
# 推后约 6s）。原先 8s 正常 + 8s 故障时，两个引擎在故障相位内全程
# normal/learning，事件在故障结束 8.5s 后才出现。现在正常段 30s（够引擎建基线）、
# 故障段 30s（留足积压消化时间）、发送帧率 2Hz，事件才落回故障相位之内。
SIM_FAULT1 = (30.0, 45.0)   # <FAULT_A> <FAULT_A> + 功率跌落 <FAULT_A2>
SIM_FAULT2 = (45.0, 60.0)   # <FAULT_B> <FAULT_B> + 温度上升 <FAULT_B2>
SIM_RECOVER = (60.0, 100.0)  # 恢复正常
S8_WINDOW = (28.0, 55.0)
S9_WINDOW = (43.0, 70.0)
S10_WINDOW = (56.0, 86.0)

# 无头下必须关掉节流，否则 requestAnimationFrame 被降频，ECharts 不重绘。
CHROME_ARGS = [
    "--disable-renderer-backgrounding",
    "--disable-backgrounding-occluded-windows",
    "--disable-features=CalculateNativeWinOcclusion",
    "--force-device-scale-factor=1",
    "--mute-audio",
    "--no-first-run",
    "--no-default-browser-check",
]

TITLE_CARD_HTML = """<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>效果演示</title><style>
html,body{margin:0;height:100%;background:
  radial-gradient(1200px 700px at 30% 18%,#0b2a4a 0%,#04101f 55%,#020a1e 100%);
  color:#e6f4ff;font-family:"Microsoft YaHei","SimHei",sans-serif;
  display:flex;align-items:center;justify-content:center;}
.wrap{text-align:center;}
h1{margin:0;font-size:64px;font-weight:700;letter-spacing:2px;line-height:1.4;
  background:linear-gradient(90deg,#67e8f9,#38bdf8 45%,#a5b4fc);
  -webkit-background-clip:text;background-clip:text;color:transparent;}
.rule{margin:30px auto 0;width:360px;height:2px;
  background:linear-gradient(90deg,transparent,#22d3ee,transparent);}
.case{margin-top:30px;font-size:30px;color:#9fd8ff;letter-spacing:6px;}
.foot{margin-top:26px;font-size:18px;color:#5f88ad;letter-spacing:3px;}
</style></head><body><div class="wrap">
<h1>基于多传感器混合数据流的<br>自适应集成接入与深度软测量</h1>
<div class="rule"></div>
<div class="case">应用案例：<OBJECT></div>
<div class="foot">软件监视平台 · 效果演示</div>
</div></body></html>"""


class ShotError(RuntimeError):
    """镜头断言失败：该镜标记 NG，不进成片。"""


class Recorder(object):
    """单镜的日志、断言、静帧与时长补足。"""

    def __init__(self, out_dir, code, title, target_s, ctx):
        self.out_dir = out_dir
        self.code = code
        self.title = title
        self.target_s = float(target_s)
        self.ctx = ctx
        self.stills = []
        self.notes = []
        self.annos = []          # [(镜内时刻, 定格秒数, (x,y,w,h), 标签)]
        self.t_page = None       # 本镜页面创建时刻，用于算镜内时间
        self.t0 = time.time()

    def mark(self, page, selector, label, hold=3.5):
        """定格画框标注：圈出页面上真实的某个元素，并暂停画面讲解。

        坐标直接取元素 bounding box，不靠人工估；时刻取"页面创建到现在"，
        与分镜视频的时间轴对齐。
        """
        if self.t_page is None:
            raise ShotError("页面尚未创建，无法标注")
        narration.assert_no_note(label, "框标注标签")
        box = page.locator(selector).first.bounding_box()
        if not box or box["width"] < 4 or box["height"] < 4:
            raise ShotError("标注目标不可见：%s" % selector)
        pad = 10
        rect = (int(box["x"]) - pad, int(box["y"]) - pad,
                int(box["width"]) + pad * 2, int(box["height"]) + pad * 2)
        t = round(time.time() - self.t_page, 2)
        self.annos.append((t, float(hold), rect, label))
        self.log("定格标注 @%.1fs：%s" % (t, label))
        return rect

    def log(self, msg):
        print("[%s] %s" % (self.code, msg), flush=True)

    def note(self, msg):
        self.notes.append(msg)
        self.log(msg)

    # ---------- 画面取证 ----------
    def still(self, page, tag):
        d = os.path.join(self.out_dir, "stills")
        os.makedirs(d, exist_ok=True)
        path = os.path.join(d, "%s_%s.png" % (self.code, tag))
        page.screenshot(path=path)
        self.stills.append(os.path.basename(path))
        return path

    # ---------- 断言 ----------
    def ensure_imported(self):
        """S4/S5 依赖 S3 的导入结果；单独跑本镜时自动补齐前置数据（不进画面）。"""
        try:
            r = self.ctx.request.get(BASE + "/stream/schemes", timeout=15000)
            if r.ok and r.json():
                return False
            with open(SAMPLE_ZIP, "rb") as f:
                buf = f.read()
            self.ctx.request.post(BASE + "/stream/config/import", multipart={
                "file": {"name": "<CONFIG_ZIP>",
                         "mimeType": "application/zip", "buffer": buf}},
                timeout=60000)
            self.log("已自动补齐前置演示配置（该镜单独运行时使用）")
            return True
        except Exception as exc:
            raise ShotError("前置配置导入失败：%s" % exc)

    def ensure_ready(self):
        """监视端镜头的前置：配置已导入，且已批量上线。"""
        self.ensure_imported()
        r = self.ctx.request.post(BASE + "/stream/deploy",
                                  data={"sid": "all"}, timeout=60000)
        if not r.ok:
            raise ShotError("批量上线失败：HTTP %s" % r.status)
        return True

    def expect_visible(self, locator, what, timeout_ms=30000):
        try:
            locator.first.wait_for(state="visible", timeout=timeout_ms)
        except Exception:
            raise ShotError("未等到画面元素：%s" % what)
        return locator.first

    @staticmethod
    def _visible_text(locator):
        try:
            if locator.count() and locator.first.is_visible():
                return locator.first.inner_text().strip()
        except Exception:
            return None
        return None

    def expect_toast(self, page, text, timeout_ms=30000):
        """等成功提示；期间若冒出任何错误提示，立即判该镜 NG。"""
        ok = page.locator(".el-message", has_text=text)
        err = page.locator(".el-message--error")
        deadline = time.time() + timeout_ms / 1000.0
        while time.time() < deadline:
            bad = self._visible_text(err)
            if bad:
                raise ShotError("画面出现错误提示：%s" % bad)
            if self._visible_text(ok):
                return True
            page.wait_for_timeout(150)
        raise ShotError("等待提示超时：%s" % text)

    # ---------- 节奏 ----------
    def hold(self, seconds):
        time.sleep(seconds)

    def pad(self, page, elapsed_ms=None):
        """把本镜时长补足到剧本给定的秒数。"""
        used = time.time() - self.t0
        rest = self.target_s - used
        if rest > 0.3:
            self.log("补足画面 %.1fs（本镜目标 %.0fs）" % (rest, self.target_s))
            page.wait_for_timeout(int(rest * 1000))
        else:
            self.note("本镜实际用时 %.1fs，已超目标 %.0fs（动作偏慢，成片需剪）"
                      % (used, self.target_s))


def scheme_panel(page):
    """方案表格所在面板（区别于下方的视频流通道面板）。"""
    return page.locator(".panel").filter(has_text="方案总数").first


def click_row_action(page, name, button, timeout_ms=30000):
    """点击某方案行的操作按钮。

    Element UI 把 fixed 列放在独立的 .el-table__fixed-right 里单独渲染：
    按钮并不在包含方案名的那个 <tr> 内，因此只能按"数据行序号"对齐到按钮序号。
    """
    deadline = time.time() + timeout_ms / 1000.0
    panel = scheme_panel(page)
    while time.time() < deadline:
        rows = panel.locator(".el-table__body-wrapper tbody tr")
        idx = None
        for i in range(rows.count()):
            try:
                if name in rows.nth(i).inner_text():
                    idx = i
                    break
            except Exception:
                pass
        if idx is not None:
            panel.get_by_role("button", name=button).nth(idx).click()
            return idx
        page.wait_for_timeout(200)
    raise ShotError("方案表中未找到 %s 行，无法点击【%s】" % (name, button))


# --------------------------------------------------------------------------
# 数据源端（虚拟试验台面板）与两端状态查询
# --------------------------------------------------------------------------
def rig_plug(page, key):
    """插/拔一根电缆：先点电缆，再点同 key 的前面板接口（再点一次即拔出）。"""
    page.locator('.cable[data-key="%s"]' % key).click()
    page.wait_for_timeout(600)
    page.locator('.port[data-key="%s"]' % key).click()
    page.wait_for_timeout(600)


def rig_prepare(page):
    for key in ("cam", "bat", "thm"):
        rig_plug(page, key)
    page.click("#pwrBtn")
    page.wait_for_timeout(1200)


def rig_wait_standby(page, timeout_ms=25000):
    """等面板回到待接线状态。上一镜的发数必须先停掉，否则接线动作会被面板忽略。"""
    try:
        page.wait_for_function(
            "() => (document.getElementById('hintText').textContent || '')"
            ".indexOf('接入三根信号电缆') >= 0", timeout=timeout_ms)
    except Exception:
        raise ShotError("数据源端未回到待接线状态（上一轮发数可能仍在运行）")


def sim_start(ctx):
    ctx.request.post(SENDER_BASE + "/sim/action", data={"action": "start"}, timeout=30000)


def sim_stop(ctx):
    try:
        ctx.request.post(SENDER_BASE + "/sim/action", data={"action": "stop"}, timeout=30000)
    except Exception:
        pass


def sim_status(ctx):
    return ctx.request.get(SENDER_BASE + "/sim/status", timeout=15000).json()


def sw_events(ctx):
    d = ctx.request.get(BASE + "/stream/events", timeout=15000).json()
    return (d.get("events") if isinstance(d, dict) else d) or []


def wait_sim_t(ctx, target, timeout_s=90):
    """等数据源端仿真时间推进到 target 秒（镜头与故障相位对锁的唯一依据）。"""
    end = time.time() + timeout_s
    last = -1.0
    while time.time() < end:
        try:
            last = float(sim_status(ctx).get("t") or 0.0)
            if last >= target:
                return last
        except Exception:
            pass
        time.sleep(0.4)
    raise ShotError("等待数据源端 t>=%.1fs 超时（当前 %.1fs）" % (target, last))


# --------------------------------------------------------------------------
# 镜头实现（与演示剧本 S1-S11 一一对应）
# --------------------------------------------------------------------------
def shot_s1(page, rec):
    """S1 开场：标题卡。"""
    page.set_content(TITLE_CARD_HTML, wait_until="load")
    rec.still(page, "标题卡")


def shot_s2(page, rec):
    """S2 平台空白启动：方案 0、视频通道 0。"""
    page.goto(BASE + "/stream/config", wait_until="domcontentloaded")
    rec.expect_visible(page.get_by_text("方案总数:"), "配置页统计栏")
    rec.still(page, "空白启动")
    txt = page.locator(".toolbar").first.inner_text()
    if "方案总数: 0" not in txt.replace("\n", " "):
        raise ShotError("空白启动未成立，统计栏为：%s" % txt.replace("\n", " "))
    rec.note("已确认空白状态：%s" % " ".join(txt.split()))


def shot_s3(page, rec):
    """S3 上传配置 ZIP 并批量上线。"""
    page.goto(BASE + "/stream/config", wait_until="domcontentloaded")
    rec.hold(2)

    # 1) 下载配置样例
    dl_dir = os.path.join(rec.out_dir, "downloads")
    os.makedirs(dl_dir, exist_ok=True)
    rec.mark(page, '.topbar button:has-text("下载配置样例")',
             "配置交付：一份 ZIP 承载协议 / 端口 / 通道 / 引擎参数", 4.0)
    with page.expect_download(timeout=30000) as dl:
        page.get_by_role("button", name="下载配置样例").click()
    dl.value.save_as(os.path.join(dl_dir, "软件配置导入样例.zip"))
    rec.log("已下载配置样例")
    page.wait_for_timeout(1200)

    # 2) 上传配置文件：接管原生文件选择框（这一步是 PyQt+element.click() 做不到的）
    rec.mark(page, '.topbar button:has-text("上传配置文件")',
             "标准化接入：上传配置文件（.csv / .zip）", 4.0)
    with page.expect_file_chooser(timeout=30000) as fc:
        page.get_by_role("button", name="上传配置文件").click()
    fc.value.set_files(SAMPLE_ZIP)
    rec.expect_toast(page, "配置导入完成")
    rec.expect_visible(page.locator('tr:has-text("<SCHEME_A>")'), "<SCHEME_A> 方案行")
    rec.expect_visible(page.locator('tr:has-text("<CHANNEL_CAM>")'), "<SUBJECT>视频通道行")
    rec.mark(page, "tr:has-text('<CHANNEL_CAM>')",
             "异构接入：时序两路 + 图像一路，同一份配置建档", 4.0)
    rec.still(page, "方案与视频通道")

    # 3) 批量上线
    page.get_by_role("button", name="批量上线").click()
    rec.expect_toast(page, "批量上线完成")
    page.wait_for_timeout(1500)
    rec.still(page, "批量上线后")
    rec.note("已导入 2 条时序方案 + 1 路图像通道，并批量上线")


def shot_s4(page, rec):
    """S4 LLM 依据原件生成规范协议。"""
    rec.ensure_imported()
    page.goto(BASE + "/stream/config", wait_until="domcontentloaded")
    rec.expect_visible(page.locator('tr:has-text("<SCHEME_A>")'), "<SCHEME_A> 行")
    click_row_action(page, "<SCHEME_A>", "配置/查看")

    dlg = page.locator(".el-dialog").filter(has_text="编辑方案").first
    rec.expect_visible(dlg, "方案编辑弹窗")

    # 原件已入库：该 textarea 由 v-if="dlg.docText" 控制，可见即证明 doc_text 已落库
    doc = dlg.get_by_placeholder("原件抽取文本（可编辑修正后交给 LLM）")
    rec.expect_visible(doc, "原件抽取文本（doc_text 已入库）", timeout_ms=15000)
    rec.mark(page, "textarea[placeholder^='原件抽取文本']",
             "原始协议原件已入库（自然语言，解析器不能直接执行）", 4.0)
    rec.still(page, "原件已入库")

    # LLM 生成：失败（无 Key / 无网络 / 超时）一律判 NG，不冒充成功
    tpl = dlg.get_by_placeholder("由 LLM 依据 ProtocolTemplateGenerator.md 生成，也可手工粘贴")
    rec.mark(page, '.el-dialog button:has-text("LLM 依据原件生成规范协议")',
             "把自然语言原件转成可执行的中间产物", 4.0)
    dlg.get_by_role("button", name="LLM 依据原件生成规范协议").click()
    rec.expect_toast(page, "规范协议已生成并通过本地编译校验", timeout_ms=180000)
    value = (tpl.input_value() or "").strip()
    if not value:
        raise ShotError("提示成功但规范协议模板为空")
    rec.note("已生成规范协议：%s" % value)
    page.wait_for_timeout(1200)
    rec.mark(page, "textarea[placeholder^='由 LLM 依据']",
             "生成结果 %s" % value, 4.5)
    rec.still(page, "规范协议已生成")


def shot_s5(page, rec):
    """S5 离线校验、保存、上线。"""
    rec.ensure_imported()
    page.goto(BASE + "/stream/config", wait_until="domcontentloaded")
    rec.expect_visible(page.locator('tr:has-text("<SCHEME_A>")'), "<SCHEME_A> 行")
    click_row_action(page, "<SCHEME_A>", "配置/查看")

    dlg = page.locator(".el-dialog").filter(has_text="编辑方案").first
    rec.expect_visible(dlg, "方案编辑弹窗")

    # 1) 离线校验模板
    dlg.get_by_role("button", name="离线校验模板").click()
    rec.expect_visible(page.get_by_text("模板可编译"), "离线校验结果", timeout_ms=20000)
    rec.log("离线校验通过")
    page.wait_for_timeout(1500)
    rec.still(page, "离线校验")

    # 2) 保存配置
    dlg.get_by_role("button", name="保存配置").click()
    rec.expect_toast(page, "方案配置已持久化")
    page.wait_for_timeout(1000)

    # 3) 批量上线
    page.get_by_role("button", name="批量上线").click()
    rec.expect_toast(page, "批量上线完成")
    page.wait_for_timeout(1500)
    rec.still(page, "上线完成")
    rec.note("生成—校验—保存—上线闭环完成")


def shot_s6(page, rec):
    """S6 启动数据源端：面板待机，等待接线。"""
    page.goto(SENDER_BASE + "/", wait_until="domcontentloaded")
    hint = rec.expect_visible(page.locator("#hintText"), "数据源端操作提示")
    if "接入三根信号电缆" not in hint.inner_text():
        raise ShotError("数据源端未处于待接线状态")
    rec.expect_visible(page.locator("#cableHint"), "电缆状态行")
    rec.still(page, "数据源端待机")
    rec.note("数据源端待机：%s" % " ".join(
        page.locator("#cableHint").inner_text().split()))


def shot_s7(page, rec):
    """S7 接线、上电、RUN；覆盖 RUN 后一个完整故障周期。"""
    sim_stop(rec.ctx)
    page.goto(SENDER_BASE + "/", wait_until="domcontentloaded")
    rec.expect_visible(page.locator("#hintText"), "数据源端操作提示")
    rig_wait_standby(page)
    rec.still(page, "接线前")

    rig_prepare(page)
    rec.expect_visible(page.get_by_text("可执行"), "RUN 可执行提示")
    rec.still(page, "接线与上电完成")

    page.click("#runBtn")
    rec.expect_visible(page.get_by_text("正在发送"), "发数进行中提示", timeout_ms=20000)
    rec.still(page, "发数进行中")
    rec.note("已接线、上电并按下 RUN，数据源端开始发送")


def _fault_shot(page, rec, window, tag, keyword):
    """故障/恢复镜头：按数据源端真实仿真时间锁定窗口，并断言软件确实报出了事件。

    数据源端在开拍前已由 _fault_pre 起跑，所以本页从"窗口前几秒"才开始录，
    不必把正常段整段录进来。
    """
    page.goto(BASE + "/stream/dash", wait_until="domcontentloaded")
    rec.expect_visible(page.locator(".banner"), "监视端横幅")
    page.wait_for_timeout(2500)
    wait_sim_t(rec.ctx, window[0], timeout_s=120)
    rec.still(page, tag + "_窗口开始")
    # 事件一出现就定格画框讲证据；随后继续放到窗口结束
    marked, deadline = False, time.time() + 180
    while time.time() < deadline:
        if not marked:
            evs = sw_events(rec.ctx)
            if any(keyword in ((e.get("symbol") or "") + (e.get("title") or ""))
                   for e in evs):
                rec.mark(page, ".fault-card",
                         "跨源证据汇聚：两路证据进同一事件流", 4.5)
                marked = True
        if float(sim_status(rec.ctx).get("t") or 0) >= window[1]:
            break
        page.wait_for_timeout(1000)
    page.wait_for_timeout(1500)
    rec.still(page, tag + "_窗口结束")

    ov = rec.ctx.request.get(BASE + "/stream/overview", timeout=15000).json()
    evs = sw_events(rec.ctx)
    hit = [e for e in evs
           if keyword in ((e.get("symbol") or "") + (e.get("title") or ""))]
    if not hit:
        raise ShotError(
            "数据源端 %s 窗口内软件未报出相关事件（事件数 %d，overall_score %s）。"
            "实测平台检测滞后于故障相位，需调整数据源端时序或镜头时间轴。"
            % (window, len(evs), ov.get("overall_score")))
    rec.note("窗口 %s 命中事件 %s" % (window, hit[0].get("symbol", "")[:40]))


def fault_pre(window, lead=6.0):
    """开拍前的预处理：起跑数据源端，等到窗口前 lead 秒再开始录。"""
    def pre(rec):
        rec.ensure_ready()
        sim_stop(rec.ctx)
        sim_start(rec.ctx)
        wait_sim_t(rec.ctx, max(window[0] - lead, 0.0), timeout_s=180)
    return pre


def shot_s8(page, rec):
    """S8 故障一：<SUBJECT><FAULT_A> + 功率跌落。"""
    _fault_shot(page, rec, S8_WINDOW, "故障一", "图像")


def shot_s9(page, rec):
    """S9 故障二：<SUBJECT>形变 + 温度上升。"""
    _fault_shot(page, rec, S9_WINDOW, "故障二", "图像")


def shot_s10(page, rec):
    """S10 恢复与闭环：事件闭合，打开【⏱ 预测详情】。"""
    page.goto(BASE + "/stream/dash", wait_until="domcontentloaded")
    rec.expect_visible(page.locator(".banner"), "监视端横幅")
    page.wait_for_timeout(2500)
    wait_sim_t(rec.ctx, SIM_RECOVER[0], timeout_s=120)
    rec.still(page, "恢复段")

    # 图像通道的积压要等它把故障帧消化完事件才闭合，这里轮询等它出现
    deadline = time.time() + 90
    closed = []
    while time.time() < deadline:
        closed = [e for e in sw_events(rec.ctx) if e.get("end_ts")]
        if closed:
            break
        page.wait_for_timeout(1000)
    if not closed:
        raise ShotError("等到 t=%.0fs 仍没有已闭合事件，无法演示『已恢复 · 结束于 …』"
                        % float(sim_status(rec.ctx).get("t") or 0))
    rec.mark(page, ".fault-card", "事件闭合：已恢复 · 结束于 …", 4.0)
    rec.still(page, "事件已恢复")
    page.locator(".ai-btn", has_text="预测详情").first.click()
    rec.expect_visible(page.locator("#predChart"), "预测详情图", timeout_ms=20000)
    page.wait_for_timeout(1500)
    rec.mark(page, "#predChart", "预测详情：演化曲线与趋势外推", 4.5)
    rec.still(page, "预测详情")
    # 放到窗口结束，保证画面长度足够容纳旁白（旁白绝不加速）
    wait_sim_t(rec.ctx, S10_WINDOW[1], timeout_s=120)
    sim_stop(rec.ctx)
    rec.note("事件已闭合，并已打开预测详情")


def shot_s11(page, rec):
    """S11 收尾：数据源端已停，软件侧保留历史事件并可继续做 AI 溯源。

    收尾画面交回软件平台——把"联调用的测试数据源端"当结尾不合适。
    停数据源端的动作在开拍前静默完成，不进画面。
    """
    rec.ensure_ready()
    sim_stop(rec.ctx)
    page.goto(BASE + "/stream/dash", wait_until="domcontentloaded")
    rec.expect_visible(page.locator(".banner"), "监视端横幅")

    deadline, evs = time.time() + 60, []
    while time.time() < deadline:
        evs = sw_events(rec.ctx)
        if any(e.get("end_ts") for e in evs):
            break
        page.wait_for_timeout(1000)
    if not any(e.get("end_ts") for e in evs):
        raise ShotError("软件侧没有已恢复的历史事件，收尾镜头拍不了")
    page.wait_for_timeout(1500)
    rec.still(page, "历史事件保留")
    rec.mark(page, ".fault-card",
             "数据源端已停，软件侧仍保留历史事件与证据链", 4.5)

    page.locator(".ai-btn").first.click()
    rec.expect_visible(page.locator(".fi-ai"), "AI 溯源结果", timeout_ms=150000)
    page.wait_for_timeout(1500)
    rec.mark(page, ".fi-ai", "AI 溯源：故障描述 / 成因 / 处置建议", 5.0)
    rec.still(page, "AI 溯源")
    rec.note("数据源端已停，软件侧保留 %d 条历史事件并完成 AI 溯源" % len(evs))


SHOTS = [
    {"code": "S1", "title": "片头标题卡", "target": 20, "fn": shot_s1},
    {"code": "S2", "title": "平台空白启动", "target": 20, "fn": shot_s2},
    {"code": "S3", "title": "配置导入与上线", "target": 40, "fn": shot_s3},
    {"code": "S4", "title": "模型生成规范协议", "target": 30, "fn": shot_s4},
    {"code": "S5", "title": "校验保存上线", "target": 20, "fn": shot_s5},
    {"code": "S6", "title": "启动数据源端", "target": 20, "fn": shot_s6},
    {"code": "S7", "title": "接线运行", "target": 30, "fn": shot_s7},
    # 故障三镜的时长由数据源端真实相位决定，不能按剧本秒数硬凑
    {"code": "S8", "title": "异常一·<FAULT_A>+功率跌落", "target": 27,
     "fn": shot_s8, "pad": False, "pre": fault_pre(S8_WINDOW)},
    {"code": "S9", "title": "异常场景二", "target": 27,
     "fn": shot_s9, "pad": False, "pre": fault_pre(S9_WINDOW)},
    {"code": "S10", "title": "恢复与闭环", "target": 30,
     "fn": shot_s10, "pad": False, "pre": fault_pre(S10_WINDOW)},
    {"code": "S11", "title": "收尾留存", "target": 26, "fn": shot_s11},
]


# --------------------------------------------------------------------------
# 运行环境
# --------------------------------------------------------------------------
def port_in_use(port, host="127.0.0.1"):
    s = socket.socket()
    s.settimeout(0.5)
    try:
        s.connect((host, port))
        return True
    except Exception:
        return False
    finally:
        s.close()


def wait_http(url, timeout=60):
    end = time.time() + timeout
    while time.time() < end:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.4)
    return False


def start_platform(log_path, fresh):
    """独立启动软件平台（交付物本体），录制器只做旁观与操作。"""
    cmd = [sys.executable, "-B", APP]
    if fresh:
        cmd.append("--fresh")
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    logf = open(log_path, "w", encoding="utf-8", errors="replace")
    proc = subprocess.Popen(cmd, cwd=ROOT, stdout=logf,
                            stderr=subprocess.STDOUT, env=env)
    proc._logf = logf
    return proc


def start_sender(log_path):
    """独立启动虚拟数据源端（demo 独立平台），与软件平台互不调用。"""
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    logf = open(log_path, "w", encoding="utf-8", errors="replace")
    proc = subprocess.Popen([sys.executable, "-B", SENDER_APP],
                            cwd=os.path.dirname(SENDER_APP), stdout=logf,
                            stderr=subprocess.STDOUT, env=env)
    proc._logf = logf
    return proc


def stop_platform(proc):
    try:
        proc.terminate()
        proc.wait(timeout=10)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    try:
        proc._logf.close()
    except Exception:
        pass


def save_video(video, dest):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    if hasattr(video, "save_as"):
        video.save_as(dest)
        return dest
    shutil.move(video.path(), dest)
    return dest


def find_h264_ffmpeg():
    """找一个带 H.264 编码器的 ffmpeg，返回 (路径, 编码器名) 或 (None, None)。

    opencv-python 这个 wheel 编不了 H.264（缺 openh264，mp4v 又没人认），
    但机器上装了完整的 FFmpeg 7.1.2（联想随机软件自带），带 h264_mf
    ——Media Foundation 的系统编码器。这条链路才出得了标准 mp4。
    """
    cands = []
    forced_exe = os.environ.get("DEMO_FFMPEG_EXE")
    if forced_exe:
        cands.append(forced_exe)
    which = shutil.which("ffmpeg")
    if which:
        cands.append(which)
    base = os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                        "Lenovo", "LegionZone")
    if os.path.isdir(base):
        for ver in sorted(os.listdir(base), reverse=True):
            p = os.path.join(base, ver, "SEGamingAI", "services", "editor",
                             "ffmpeg.exe")
            if os.path.isfile(p):
                cands.append(p)
    for exe in cands:
        try:
            out = subprocess.run([exe, "-hide_banner", "-encoders"],
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 timeout=30).stdout.decode("utf-8", "replace")
        except Exception:
            continue
        # 默认优先 h264_mf，但长片下 Media Foundation 会中途退出（BrokenPipe）；
        # 用 DEMO_FFMPEG_ENCODER=h264_nvenc 等可以强制换编码器。
        forced_enc = os.environ.get("DEMO_FFMPEG_ENCODER")
        order = ([forced_enc] if forced_enc else []) + [
            "h264_mf", "h264_nvenc", "h264_qsv", "h264_amf", "libx264"]
        for enc in order:
            if enc in out:
                return exe, enc
    return None, None


def stitch(clips, dest, fps=DEFAULT_FPS, ffmpeg=None, encoder="h264_mf",
           captions=None, audio=None, annos=None, chapters=None, trims=None,
           rail=None):
    """把分镜按剧本顺序拼成一条成片，丢掉每段开头的无头空白帧。

    ffmpeg 可用时出标准 H.264 mp4（播放器、浏览器、PPT 都认）；
    否则退回 opencv 的 VP8 webm（浏览器能播，但慢且兼容性差）。

    captions: [(t0, t1, RGBA 贴图)]，按成片全局时间轴铺字幕；
    audio:    旁白 wav，作为第二路输入直接混进 mp4（aac）；
    annos:    {分镜序号: [(镜内时刻, 定格秒数, (x,y,w,h), 标签)]}。
              到点后冻住当前帧、压暗并画框，讲解词继续念。
    """
    import cv2
    proc, writer, total, size, skipped = None, None, 0, None, 0
    # 长片保护：受管机器上硬件编码器撑不住一次跑完（ffmpeg 会静默退出），
    # 用 DEMO_STITCH_CHUNK_SEC 打开"分段编码 + 无损拼接"，每段单独起进程。
    chunk_frames = int(float(os.environ.get("DEMO_STITCH_CHUNK_SEC", "0"))
                       * float(fps))
    parts, chunk_idx, chunk_written = [], 0, 0
    caps = sorted(captions or [], key=lambda c: c[0])
    cap_idx = 0
    chapter_imgs = []
    rail_imgs = []
    stage_now = None

    def start_pipeline(w, h):
        nonlocal proc, writer, size
        size = (w, h)
        if ffmpeg:
            cmd = [ffmpeg, "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
                   "-s", "%dx%d" % size, "-r", str(fps), "-i", "-"]
            if audio and not chunk_frames:
                cmd += ["-i", audio]
            cmd += ["-c:v", encoder, "-b:v", "6M", "-pix_fmt", "yuv420p"]
            if audio and not chunk_frames:
                cmd += ["-c:a", "aac", "-b:a", "128k", "-shortest"]
            cmd += ["-loglevel", "error",
                    part_path(chunk_idx) if chunk_frames else dest]
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        else:
            writer = cv2.VideoWriter(dest, cv2.VideoWriter_fourcc(*"VP80"),
                                     float(fps), size)
            if not writer.isOpened():
                raise RuntimeError("没有可用的视频编码器")

    def part_path(index):
        stem = os.path.splitext(os.path.basename(dest))[0]
        return os.path.join(os.path.dirname(dest),
                            "_part_%s_%03d.mp4" % (stem, index))

    def close_part():
        nonlocal proc, chunk_idx, chunk_written
        if proc is None:
            return
        proc.stdin.close()
        rc = proc.wait(timeout=1800)
        if rc != 0:
            raise RuntimeError("ffmpeg 退出码 %s（分段 %d）" % (rc, chunk_idx))
        parts.append(part_path(chunk_idx))
        print("  分段 %d 完成（%d 帧）" % (chunk_idx, chunk_written), flush=True)
        proc = None
        chunk_idx += 1
        chunk_written = 0

    def emit(frame):
        nonlocal total, cap_idx, chunk_written
        if size is None:
            start_pipeline(frame.shape[1], frame.shape[0])
            if chapters:
                chapter_imgs.extend(
                    narration.render_chapters(size[0], [c[0] for c in chapters], i)
                    for i in range(len(chapters)))
            if rail and not rail_imgs:
                import numpy as np
                for p in rail["pngs"]:
                    im = cv2.imdecode(np.fromfile(p, dtype=np.uint8),
                                      cv2.IMREAD_COLOR)
                    if im is None:
                        continue
                    # 渲染出的 PNG 可能带页面空白（纯白行/列），先按墨迹裁掉，
                    # 否则缩放后会变成贴在流条下方的白条。
                    gray = im.mean(axis=2)
                    rows = np.where(gray.min(axis=1) < 235)[0]
                    cols = np.where(gray.min(axis=0) < 235)[0]
                    if len(rows) and len(cols):
                        im = im[rows[0]:rows[-1] + 1, cols[0]:cols[-1] + 1]
                    h = max(1, int(im.shape[0] * 340.0 / im.shape[1]))
                    rail_imgs.append(cv2.resize(im, (340, h)))
        if rail and stage_now is not None and rail_imgs:
            import numpy as np
            small = cv2.resize(frame, (1540, 866))
            canvas = np.full((1080, 1920, 3), 12, np.uint8)
            canvas[107:973, 0:1540] = small
            im = rail_imgs[stage_now % len(rail_imgs)]
            y = (1080 - im.shape[0]) // 2
            canvas[y:y + im.shape[0], 1560:1900] = im
            frame = canvas
        if caps:
            now = total / float(fps)
            while cap_idx < len(caps) and now > caps[cap_idx][1]:
                cap_idx += 1
            if cap_idx < len(caps):
                t0, t1, img = caps[cap_idx]
                if t0 <= now <= t1:
                    if rail and stage_now is not None:
                        # 右侧有纵向流条时，字幕只在左侧区域内居中，不与流条压边
                        if img.shape[1] > 1300:
                            k = 1300.0 / img.shape[1]
                            img = cv2.resize(
                                img, (1300, max(1, int(img.shape[0] * k))),
                                interpolation=cv2.INTER_AREA)
                        narration.paste_rgba(frame, img, 770)
                    else:
                        narration.paste_rgba(frame, img, size[0] / 2.0)
        if chapter_imgs:
            now = total / float(fps)
            idx = len(chapters) - 1
            for i, ch in enumerate(chapters):
                if ch[1] <= now < ch[2]:
                    idx = i
                    break
            # 封面段不显示时间轴
            if len(chapters[idx]) < 4 or chapters[idx][3]:
                strip = chapter_imgs[idx]
                narration.paste_at(frame, strip,
                                   (size[0] - strip.shape[1]) // 2,
                                   size[1] - strip.shape[0])
        if ffmpeg:
            if proc is None and chunk_frames:
                # 上一段已收尾，本段另起一个编码进程
                start_pipeline(size[0], size[1])
            proc.stdin.write(frame.tobytes())
            chunk_written += 1
            if chunk_frames and chunk_written >= chunk_frames:
                close_part()
        else:
            writer.write(frame)
        total += 1

    try:
        for clip_i, path in enumerate(clips):
            stage_now = (rail or {}).get("map", {}).get(clip_i)
            pending = sorted((annos or {}).get(clip_i) or [],
                             key=lambda a: a[0])
            local_frames = 0
            active = []
            cap = cv2.VideoCapture(path)
            if not cap.isOpened():
                raise RuntimeError("无法打开分镜：%s" % path)
            first, lead = True, 0
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                if (first and lead < int(float(fps) * 2)
                        and float(frame.std()) < 2.0):
                    lead += 1
                    skipped += 1
                    continue
                first = False
                if size is not None and (frame.shape[1], frame.shape[0]) != size:
                    raise RuntimeError("分镜尺寸不一致，无法拼接：%s" % path)
                local_t = local_frames / float(fps)
                cut = (trims or {}).get(clip_i)
                if cut is not None and local_t >= cut:
                    break
                while pending and local_t >= pending[0][0]:
                    item = pending.pop(0)
                    _t, hold, box, label = item[:4]
                    if len(item) > 4 and not item[4]:
                        # 静态图段：只叠方框说明，不冻结画面
                        active.append((local_t + hold, box, label))
                    else:
                        frozen = narration.annotate_frame(frame, box, label)
                        for _ in range(max(1, int(round(hold * float(fps))))):
                            emit(frozen)
                if active:
                    active = [a for a in active if a[0] > local_t]
                    for a in active:
                        frame = narration.annotate_frame(
                            frame, a[1], a[2], dim=1.0)
                emit(frame)
                local_frames += 1
            cap.release()
        if chunk_frames:
            close_part()
            if parts:
                listfile = os.path.join(os.path.dirname(dest), "_parts.txt")
                with open(listfile, "w", encoding="utf-8") as f:
                    for p in parts:
                        # concat 列表里的相对路径会按"列表文件所在目录"解析，
                        # 必须写绝对路径，否则会拼成 doubled path 打不开。
                        f.write("file '%s'\n"
                                % os.path.abspath(p).replace("\\", "/"))
                joined = os.path.join(os.path.dirname(dest), "_joined.mp4")
                print("  拼接 %d 个分段 → 成片" % len(parts), flush=True)
                subprocess.run([ffmpeg, "-y", "-f", "concat", "-safe", "0",
                                "-i", listfile, "-c", "copy", joined,
                                "-loglevel", "error"], check=True)
                if audio:
                    cmd = [ffmpeg, "-y", "-i", joined, "-i", audio,
                           "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
                           "-shortest", dest, "-loglevel", "error"]
                else:
                    cmd = [ffmpeg, "-y", "-i", joined, "-c", "copy", dest,
                           "-loglevel", "error"]
                subprocess.run(cmd, check=True)
                for p in parts + [joined, listfile]:
                    try:
                        os.remove(p)
                    except OSError:
                        pass
        elif proc is not None:
            proc.stdin.close()
            rc = proc.wait(timeout=1800)
            if rc != 0:
                raise RuntimeError("ffmpeg 退出码 %s" % rc)
    finally:
        if writer is not None:
            writer.release()
    return total, size, skipped


def assemble_narration(entries, out_wav, with_subtitle=True, extra=None):
    """把各镜旁白按成片时间轴拼成一条音轨，并生成对应字幕轨。

    entries: [(code, 分镜视频路径, 旁白 wav, 逐句音频时间窗)]，顺序即成片顺序。
             时间窗来自逐句合成，字幕直接用它平移，音字由构造对齐。
    extra:   {code: 该镜因定格标注额外增加的秒数}

    配音**不做任何变速**。旁白比画面长就报错：要么精简讲解词，要么把镜头
    （或定格时间）加长——顺序必须是先定画面时长、再改讲解词，不能反过来
    先把配音压快。
    """
    import cv2
    import numpy as np
    rate, segs, caps, t = None, [], [], 0.0
    over = []
    ends = {}
    cap_log = []
    for code, clip, wav, spans in entries:
        cap = cv2.VideoCapture(clip)
        clip_fps = cap.get(cv2.CAP_PROP_FPS) or DEFAULT_FPS
        dur = cap.get(cv2.CAP_PROP_FRAME_COUNT) / float(clip_fps)
        cap.release()
        dur += float((extra or {}).get(code, 0.0))
        samples, sr = narration.read_wav(wav)
        rate = rate or sr
        if sr != rate:
            samples = narration.fit_length(samples, sr, samples.size / float(sr))
        need = samples.size / float(rate)
        # 与成片拼接用同一套收尾规则：画面被收到"旁白 + 0.4s"，
        # 字幕/配音的时间轴必须同步收，否则会被排到画面后面（实测差 50 秒）。
        # 注意 dur 已经含定格时长（上面 += extra），这里**不能**再加一次 hold：
        # 拼接侧 build_film 的判据是 d - (end+tail) > 0.4 → d = end+tail，
        # 两处差一个 hold 就会让音轨整体后移，每镜累计成字幕大空档。
        if dur - (need + 0.4) > 0.4:
            dur = need + 0.4
        if need > dur + 0.05:
            over.append((code, need, dur))
        segs.append((t, samples))
        if with_subtitle:
            caps += narration.caption_track_from_spans(spans, t, log=cap_log)
        ends[code] = round(need, 3)   # 旁白在本镜内念完的秒数（镜内相对时间）
        t += dur
    if over:
        raise RuntimeError(
            "以下镜头旁白比画面长，拒绝压缩配音，请先精简讲解词或延长镜头：\n"
            + "\n".join("  %s 旁白 %.1fs > 画面 %.1fs（超 %.1fs）"
                        % (c, n, d, n - d) for c, n, d in over))
    buf = np.zeros(int(t * rate) + rate, np.float32)
    for off, s in segs:
        i = int(off * rate)
        buf[i:i + s.size] += s
    narration.write_wav(out_wav, buf, rate)
    if cap_log:
        import json as _json
        with open(os.path.join(os.path.dirname(out_wav), "captions.json"),
                  "w", encoding="utf-8") as f:
            _json.dump(cap_log, f, ensure_ascii=False, indent=1)
    return out_wav, caps, ends


def build_film(run_dir, shots, stamp, fps=None, captions=None, audio=None,
               narr_ends=None, tail=0.4):
    """按清单顺序把某个 run 目录里的分镜拼成成片（标准 H.264 mp4）。"""
    fps = fps or DEFAULT_FPS
    ok = [s for s in shots if s.get("status") == "OK" and s.get("video")
          and os.path.isfile(os.path.join(run_dir, s["video"]))]
    clips = [os.path.join(run_dir, s["video"]) for s in ok]
    if not clips:
        print("没有可拼接的分镜，未生成成片。")
        return None
    annos = {i: s.get("annos") or [] for i, s in enumerate(ok)}
    held = sum(a[1] for lst in annos.values() for a in lst)
    import cv2
    # 时间轴按"阶段"分段，与配图的架构段一一对应；封面（S1）不显示时间轴
    _DEF_GROUPS = [
        ("", ["S1"], False),
              ("总体架构", ["S1B"], True),
              ("业务痛点", ["S2B"], True),
              ("接入建档", ["S2", "S3", "S4", "S5"], True),
              ("设备接入", ["S6", "S7"], True),
              ("关键技术流", ["S7B"], True),
              ("异常汇聚", ["S8", "S9"], True),
              ("恢复闭环", ["S10"], True),
        ("留存溯源", ["S11"], True)]
    GROUPS = ([(c.get("label", ""), c.get("shots", []), c.get("show", True))
               for c in CHAPTER_SPEC] if CHAPTER_SPEC else _DEF_GROUPS)
    dur = {}
    trims = {}
    for i, s in enumerate(ok):
        c = cv2.VideoCapture(os.path.join(run_dir, s["video"]))
        d = c.get(cv2.CAP_PROP_FRAME_COUNT) / (c.get(cv2.CAP_PROP_FPS) or fps)
        c.release()
        d += sum(a[1] for a in (s.get("annos") or [])
                 if len(a) < 5 or a[4])
        end = (narr_ends or {}).get(s["code"])
        if end and d - (end + tail) > 0.4:
            trims[i] = end + tail
            d = trims[i]
        dur[s["code"]] = d
    # 时间轴必须覆盖全部镜头、按成片顺序累加；漏掉任何镜头都会让整条轴错位
    label_of = {}
    for ci, (_lab, codes, _show) in enumerate(GROUPS):
        for code in codes:
            label_of[code] = ci
    order = [s["code"] for s in ok]
    missed = [c for c in order if c not in label_of]
    if missed:
        print("[提示] 时间轴章节未覆盖这些镜头，已并入上一章：%s" % "、".join(missed))
    chapters, t, cur = [], 0.0, None
    for code in order:
        ci = label_of.get(code, cur if cur is not None else 0)
        if cur is None or ci != cur:
            lab, _codes, show = GROUPS[ci]
            chapters.append([lab, t, t, show])
            cur = ci
        chapters[-1][2] = t + dur.get(code, 0.0)
        t += dur.get(code, 0.0)
    chapters = [tuple(c) for c in chapters]
    # 技术流：叠在演示画面右侧的纵向流条，讲解走到哪一段就亮哪一段
    if RAIL_SPEC:
        RAIL_STAGE = RAIL_SPEC.get("stage_of_shot", {})
        rail_pngs = list(RAIL_SPEC.get("images") or [])
    else:
        RAIL_STAGE = {"S2": 0, "S3": 0, "S4": 1, "S5": 1, "S6": 1,
                      "S7": 2, "S8": 2, "S9": 3, "S10": 4, "S11": 4}
        rail_pngs = [os.path.join(ROOT, "record", "diagrams",
                                  "RAIL_%d.png" % i) for i in range(5)]
    rail = None
    if all(os.path.isfile(p) for p in rail_pngs):
        rmap = {i: RAIL_STAGE[s["code"]] for i, s in enumerate(ok)
                if s["code"] in RAIL_STAGE}
        if rmap:
            rail = {"pngs": rail_pngs, "map": rmap}
    ffmpeg, encoder = find_h264_ffmpeg()
    ext = ".mp4" if ffmpeg else ".webm"
    dest = os.path.join(run_dir, "成片_%s%s" % (stamp, ext))
    total, size, skipped = stitch(clips, dest, fps, ffmpeg,
                                  encoder or "h264_mf", captions, audio, annos,
                                  chapters, trims, rail)
    ng = [s["code"] for s in shots if s.get("status") != "OK"]
    info = {"path": os.path.basename(dest), "clips": len(clips),
            "codec": encoder if ffmpeg else "vp8(webm fallback)",
            "subtitles": bool(captions), "audio": os.path.basename(audio) if audio else "",
            "annotations": sum(len(v) for v in annos.values()),
            "held_seconds": round(held, 1),
            "frames": total, "size": list(size) if size else None,
            "seconds": round(total / float(fps), 1),
            "trimmed_lead_frames": skipped, "skipped_ng": ng}
    print("\n成片：%s（%d 段 / %d 帧 / %.1fs / %s / %s）"
          % (dest, len(clips), total, info["seconds"], size, info["codec"]))
    if ng:
        print("未纳入成片的 NG 镜头：%s" % "、".join(ng))
    return info


# --------------------------------------------------------------------------
def dump_failure(page, out_dir, code):
    """NG 时留存现场：整屏截图 + DOM，便于定位而不用重跑。"""
    try:
        page.screenshot(path=os.path.join(out_dir, "%s_NG.png" % code))
        with open(os.path.join(out_dir, "%s_NG.html" % code),
                  "w", encoding="utf-8", errors="replace") as f:
            f.write(page.content())
    except Exception:
        pass


def run_shot(ctx, out_dir, shot, kwargs):
    """一个镜头 = 一个独立页面 = 一个独立视频文件。"""
    code, title, target_s, fn = shot["code"], shot["title"], shot["target"], shot["fn"]
    rec = Recorder(out_dir, code, title, target_s, ctx)
    pre = shot.get("pre")
    if pre:
        pre(rec)
    page = ctx.new_page()
    rec.t_page = time.time()
    ffmpeg_hq, encoder_hq = find_h264_ffmpeg()
    tmp_video = os.path.join(out_dir, "_rec_%s.mp4" % code)
    cast = capture.ScreenCast(page, tmp_video, ffmpeg_hq,
                              encoder_hq or "h264_mf", DEFAULT_FPS)
    status, err = "OK", ""
    try:
        fn(page, rec)
        if shot.get("pad", True):
            rec.pad(page)
        else:
            rec.note("本镜时长由数据源端真实相位锁定（实拍 %.1fs），不按剧本 %ds 硬凑"
                     % (time.time() - rec.t0, target_s))
    except ShotError as exc:
        status, err = "NG", str(exc)
        dump_failure(page, out_dir, code)
    except Exception as exc:
        # Playwright 的超时日志可以上千行，只留一行概要，别把清单也淹了
        head = (str(exc).strip().splitlines() or [""])[0]
        status, err = "NG", "%s: %s" % (type(exc).__name__, head[:300])
        traceback.print_exc(limit=3)
        dump_failure(page, out_dir, code)
    finally:
        cast.stop()
        page.close()

    name = "%s_%s%s.mp4" % (code, title, "" if status == "OK" else "_NG")
    dest = os.path.join(out_dir, name)
    try:
        if cast.frames and os.path.isfile(tmp_video):
            if os.path.exists(dest):
                os.remove(dest)
            os.replace(tmp_video, dest)
        else:
            raise RuntimeError("CDP 未取到任何画面帧")
    except Exception as exc:
        status = "NG"
        err = err or "视频保存失败：%s" % exc
        dest = None

    if status != "OK":
        rec.log("镜头 NG：%s" % err.strip().splitlines()[-1])
    mp4 = ""
    if dest and kwargs.get("mp4") and status == "OK":
        ffmpeg, encoder = find_h264_ffmpeg()
        mp4 = os.path.splitext(dest)[0] + ".mp4"
        try:
            frames, _size, skipped = stitch(
                [dest], mp4, kwargs.get("fps") or DEFAULT_FPS, ffmpeg, encoder or "h264_mf")
            rec.log("已转 mp4：%s（%d 帧，裁掉开头 %d 帧空白）"
                    % (os.path.basename(mp4), frames, skipped))
        except Exception as exc:
            mp4 = ""
            rec.note("mp4 转换失败（webm 仍可用）：%s" % exc)

    return {"code": code, "title": title, "target_s": target_s,
            "status": status, "error": err.strip(),
            "video": os.path.basename(dest) if dest else "",
            "mp4": os.path.basename(mp4) if mp4 else "",
            "duration_s": round(time.time() - rec.t0, 1),
            "annos": rec.annos if status == "OK" else [],
            "stills": rec.stills, "notes": rec.notes}


def main(argv=None):
    ap = argparse.ArgumentParser(description="效果演示视频录制器（Playwright 无头）")
    ap.add_argument("--shots", default="all", help="如 S1,S2,S3 或 all")
    ap.add_argument("--out", default=os.path.join(ROOT, "record", "out"))
    ap.add_argument("--headed", action="store_true", help="调试：显示浏览器窗口")
    ap.add_argument("--mp4", action="store_true",
                    help="额外输出 mp4（MPEG-4 Part 2，浏览器解不了，只给本地播放器用）")
    ap.add_argument("--stitch", action="store_true",
                    help="按剧本顺序把各镜拼成一条成片 成片_<时间戳>.webm")
    ap.add_argument("--stitch-only", metavar="RUN_DIR",
                    help="不录制，直接把某个已完成 run 目录里的分镜拼成成片")
    ap.add_argument("--narrate", action="store_true",
                    help="按剧本合成中文旁白并烧录字幕（会自动出成片）")
    ap.add_argument("--voice", default=narration.DEFAULT_VOICE,
                    help="SAPI 语音名，默认 %s" % narration.DEFAULT_VOICE)
    ap.add_argument("--rate", type=int, default=0,
                    help="语速 -10..10，默认 0")
    ap.add_argument("--no-subtitle", action="store_true", help="只要旁白不要字幕")
    ap.add_argument("--fps", type=float, default=None, help="mp4 帧率（默认取源帧率）")
    ap.add_argument("--no-fresh", action="store_true", help="不清空演示库")
    ap.add_argument("--keep-platform", action="store_true", help="录完不关闭软件平台")
    ap.add_argument("--list", action="store_true", help="只列出镜头")
    ap.add_argument("--shots-file", metavar="JSON",
                    help="用数据化镜头表代替内置镜头（见 shot_runner.md）")
    args = ap.parse_args(argv)

    if args.list:
        for s in SHOTS:
            lock = "锁定数据源端真实相位" if not s.get("pad", True) else "按剧本时长"
            print("%s  %-26s 剧本 %3ds  %s" % (s["code"], s["title"], s["target"], lock))
        return 0

    if args.stitch_only:
        run_dir = args.stitch_only
        man = os.path.join(run_dir, "manifest.json")
        if not os.path.isfile(man):
            print("找不到清单：%s" % man)
            return 2
        # 只重合成/只重拼时也要读镜头表，否则技术条与时间轴会丢
        if args.shots_file:
            _spec = shot_runner.load_spec(args.shots_file)
            globals()['RAIL_SPEC'] = _spec.get('rail')
            globals()['CHAPTER_SPEC'] = _spec.get('chapters')
            print("已加载镜头表：技术条 %s / 时间轴 %s"
                  % (bool(globals()['RAIL_SPEC']),
                     bool(globals()['CHAPTER_SPEC'])))
        with open(man, encoding="utf-8") as f:
            m = json.load(f)
        caps = aud = nends = None
        if args.narrate:
            script = narration.load_script(SCRIPT)
            ndir = os.path.join(run_dir, "narration")
            os.makedirs(ndir, exist_ok=True)
            entries = []
            print("\n=== 重新合成旁白（逐句计时，字幕与音频同源）===")
            for s in m.get("shots", []):
                if s.get("status") != "OK" or not s.get("video"):
                    continue
                item = script.get(s["code"])
                if not item:
                    continue
                chunks = narration.split_narration(item["narration"])
                wav = os.path.join(ndir, "%s.wav" % s["code"])
                dur, spans = narration.synth_sentences(
                    chunks, wav, args.voice, args.rate)
                print("  %s 旁白 %.1fs / %d 句" % (s["code"], dur, len(spans)))
                # 配图类镜头：按句号挂方框说明（不冻结画面，仅叠框）
                for ci, off, hold, box, label in (s.get("callouts") or []):
                    if 1 <= ci <= len(spans):
                        t0s, t1s = spans[ci - 1][0], spans[ci - 1][1]
                        # 框必须在"这一句正在念"的时间窗内，不许溢出到下一句
                        t0 = min(max(t0s + off, t0s), max(t1s - hold, t0s))
                        s.setdefault("annos", []).append(
                            [round(t0, 2), hold, box, label, False])
                entries.append((s["code"], os.path.join(run_dir, s["video"]),
                                wav, spans))
            extra = {s["code"]: sum(a[1] for a in (s.get("annos") or [])
                                    if len(a) < 5 or a[4])
                     for s in m.get("shots", [])}
            aud, caps, nends = assemble_narration(
                entries, os.path.join(run_dir, "narration.wav"),
                not args.no_subtitle, extra)
        film = build_film(run_dir, m.get("shots", []),
                          m.get("created_at", "run"), args.fps, caps, aud,
                          nends)
        if not film:
            return 1
        m["film"] = film
        with open(man, "w", encoding="utf-8") as f:
            json.dump(m, f, ensure_ascii=False, indent=2)
        return 0

    wanted = [c.strip().upper() for c in args.shots.split(",") if c.strip()]
    pool = SHOTS
    if args.shots_file:
        _spec = shot_runner.load_spec(args.shots_file)
        globals()['RAIL_SPEC'] = _spec.get('rail')
        globals()['CHAPTER_SPEC'] = _spec.get('chapters')
        pool = shot_runner.shots_of(_spec)
    selected = [dict(s) for s in pool if "ALL" in wanted or s["code"] in wanted]
    if not selected:
        print("没有匹配的镜头：%s" % args.shots)
        return 2

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(args.out, stamp)
    os.makedirs(out_dir, exist_ok=True)
    print("输出目录：%s" % out_dir)

    missing = [p for p in (SAMPLE_ZIP, SAMPLE_DOC) if not os.path.isfile(p)]
    if missing:
        # 数据化镜头表自带素材路径，内置素材缺失只告警不阻断
        if args.shots_file:
            print("[提示] 未找到内置演示素材（数据化镜头表不受影响）：%s"
                  % "；".join(missing))
        else:
            print("缺少演示素材：%s" % "；".join(missing))
            return 2
    if port_in_use(PORT):
        print("端口 %d 已被占用，请先关闭已在运行的软件平台。" % PORT)
        return 2
    if os.path.isfile(SENDER_APP) and port_in_use(SENDER_PORT):
        print("端口 %d 已被占用，请先关闭已在运行的虚拟数据源端。" % SENDER_PORT)
        return 2
    # 接收端口从环境变量读（逗号分隔），换项目与便携转移都不必改代码
    for p in [int(x) for x in
              os.environ.get("DEMO_RECV_PORTS", "9001,9002,9003").split(",")
              if x.strip()]:
        if port_in_use(p):
            print("接收端口 %d 已被占用，批量上线会失败，请先释放。" % p)
            return 2

    narr = {}
    if args.narrate:
        if not os.path.isfile(SCRIPT):
            print("找不到剧本：%s" % SCRIPT)
            return 2
        script = narration.load_script(SCRIPT)
        os.makedirs(os.path.join(out_dir, "narration"), exist_ok=True)
        print("\n=== 旁白合成（%s / rate %+d）===" % (args.voice, args.rate))
        for shot in selected:
            code = shot["code"]
            item = script.get(code)
            if not item:
                print("  %s 剧本无讲解词，跳过" % code)
                continue
            wav = os.path.join(out_dir, "narration", "%s.wav" % code)
            chunks = narration.split_narration(item["narration"])
            dur, spans = narration.synth_sentences(
                chunks, wav, args.voice, args.rate)
            narr[code] = {"wav": wav, "dur": dur, "chunks": chunks,
                          "spans": spans}
            if shot.get("pad", True) and dur + 0.8 > shot["target"]:
                print("  %s 旁白 %.1fs > 剧本 %ds → 本镜延长到 %.1fs"
                      % (code, dur, shot["target"], dur + 0.8))
                shot["target"] = round(dur + 0.8, 1)
            elif not shot.get("pad", True) and dur > shot["target"]:
                print("  %s 旁白 %.1fs，但该镜锁定数据源端相位不能延长，将压缩旁白"
                      % (code, dur))
            print("  %s 旁白 %.1fs / 字幕 %d 句（逐句计时，音字同源）"
                  % (code, dur, len(spans)))

    from playwright.sync_api import sync_playwright

    manifest = {"created_at": stamp, "base": BASE, "viewport": [VIEW_W, VIEW_H],
                "headed": bool(args.headed), "shots": []}
    app_proc = sender_proc = None
    try:
        # 录前归零：平台常把映射/产品持久化，重跑会"加一个减一个"。
        # DEMO_PLATFORM_RESET 给通配路径（可多个用 ; 分隔），启动前先删掉。
        reset = os.environ.get("DEMO_PLATFORM_RESET")
        if reset:
            import glob as _glob
            for pat in reset.split(";"):
                for p in _glob.glob(pat.strip()):
                    try:
                        os.remove(p)
                        print("已重置平台状态：%s" % p)
                    except Exception as exc:
                        print("重置失败 %s：%s" % (p, exc))
        app_log = os.path.join(out_dir, "platform.log")
        app_proc = start_platform(app_log, fresh=not args.no_fresh)
        if not wait_http(BASE + READY_PATH, timeout=90):
            print("软件平台未在 90s 内就绪，见 %s" % app_log)
            return 3
        print("软件平台已就绪：%s" % BASE)

        # 数据源端（可选）：项目没有独立发数端时跳过，不影响录制
        if os.path.isfile(SENDER_APP):
            sender_log = os.path.join(out_dir, "sender.log")
            sender_proc = start_sender(sender_log)
            if not wait_http(SENDER_BASE + "/sim/status", timeout=60):
                print("数据源端未在 60s 内就绪，见 %s" % sender_log)
                return 3
            print("数据源端已就绪：%s（与平台互不调用）" % SENDER_BASE)
        else:
            print("未发现独立数据源端，按“平台即全部”模式录制")

        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=not args.headed, args=CHROME_ARGS)
            ctx = browser.new_context(
                viewport={"width": VIEW_W, "height": VIEW_H},
                record_video_dir=os.path.join(out_dir, "raw"),
                record_video_size={"width": VIEW_W, "height": VIEW_H},
                device_scale_factor=1,
                locale="zh-CN",
                timezone_id="Asia/Shanghai",
                accept_downloads=True,
            )
            picked = [s["code"] for s in selected]
            for shot in selected:
                code, title, sec = shot["code"], shot["title"], shot["target"]
                print("\n=== %s %s（剧本目标 %ds）===" % (code, title, sec))
                if code in ("S4", "S5") and "S3" not in picked:
                    print("[提示] %s 依赖 S3 的配置导入，本镜将自动补齐前置数据。"
                          % code)
                if code in ("S8", "S9", "S10") and "S3" not in picked:
                    print("[提示] %s 依赖配置已上线，本镜将自动补齐前置数据。" % code)
                try:
                    manifest["shots"].append(
                        run_shot(ctx, out_dir, shot, vars(args)))
                except Exception:
                    traceback.print_exc()
                    manifest["shots"].append(
                        {"code": code, "title": title, "status": "NG",
                         "error": "录制器异常", "video": "", "stills": [], "notes": []})
            ctx.close()
            browser.close()
        # save_as 是复制，raw 里还留着同一份视频，清掉避免交付时混淆
        shutil.rmtree(os.path.join(out_dir, "raw"), ignore_errors=True)

        # 录完立刻落盘清单：合成阶段（旁白/字幕/拼接）万一报错，
        # 分镜与定格坐标也就留住了，可以 --stitch-only 重合成，不必重录。
        with open(os.path.join(out_dir, "manifest.json"), "w",
                  encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)

        if args.stitch or args.narrate:
            caps, aud, nends = None, None, None
            if args.narrate:
                entries = [(s["code"], os.path.join(out_dir, s["video"]),
                            narr[s["code"]]["wav"], narr[s["code"]]["spans"])
                           for s in manifest["shots"]
                           if s["status"] == "OK" and s.get("video")
                           and s["code"] in narr]
                # 定格标注会给画面加时长，配音时间轴必须一并算上
                extra = {s["code"]: sum(a[1] for a in (s.get("annos") or [])
                                        if len(a) < 5 or a[4])
                         for s in manifest["shots"]}
                if entries:
                    print("\n=== 合成旁白音轨（%d 段）===" % len(entries))
                    aud, caps, nends = assemble_narration(
                        entries, os.path.join(out_dir, "narration.wav"),
                        not args.no_subtitle, extra)
                    manifest["narration"] = {
                        "voice": args.voice, "rate": args.rate,
                        "clips": len(entries),
                        "subtitles": not args.no_subtitle,
                        "seconds": round(narration.wav_duration(aud), 1)}
            film = build_film(out_dir, manifest["shots"], stamp, args.fps,
                              caps, aud, nends)
            if film:
                manifest["film"] = film
    finally:
        if not args.keep_platform:
            if sender_proc is not None:
                stop_platform(sender_proc)
            if app_proc is not None:
                stop_platform(app_proc)

    bad = [s for s in manifest["shots"] if s["status"] != "OK"]
    manifest["result"] = "OK" if not bad else "NG"
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print("\n=== 录制结果 ===")
    for s in manifest["shots"]:
        print("%s %s %-24s %s %s" % (
            s["code"], s["status"], s["title"],
            s.get("video", ""), ("｜" + s["error"].splitlines()[-1]) if s["error"] else ""))
    print("清单：%s" % os.path.join(out_dir, "manifest.json"))
    if bad:
        print("有 %d 个镜头为 NG，成片前需补拍。" % len(bad))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
