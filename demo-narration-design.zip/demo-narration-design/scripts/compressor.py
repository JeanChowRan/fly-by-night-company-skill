# -*- coding: utf-8 -*-
"""静止段压缩：把"没有动作、也没有讲解"的长停顿快进掉，但保留末段原速。

规则（实测有效）：一段连续静止若超过 min_run 秒，把前面部分压成 target 秒，
**最后 keep_tail 秒保持原速**——那一段通常是结果出现的地方，快进会把结论吃掉。

用法：
    from compressor import compress_still
    compress_still(src, dst)          # 默认：>6s 的静止段压到 3s + 末尾保留 3s

环境变量（可覆盖默认）：
    DEMO_COMPRESS_STILL=0   关闭
    DEMO_STILL_MIN_RUN      触发压缩的最短静止时长（秒）
    DEMO_STILL_TARGET       压缩后头部时长（秒）
    DEMO_STILL_KEEP_TAIL    末尾保留原速的时长（秒）
    DEMO_STILL_THRESH       判定静止的帧间差阈值（0-255）
"""
import os
import subprocess


def _env_f(name, default):
    try:
        return float(os.environ.get(name, default))
    except Exception:
        return float(default)


def _motion(path, fps):
    """逐帧运动量（缩到小图算，够快也够准）。"""
    import cv2
    import numpy as np
    cap = cv2.VideoCapture(path)
    prev, motion = None, []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        small = cv2.resize(frame, (320, 180), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        motion.append(0.0 if prev is None
                      else float(np.abs(gray.astype(np.int16)
                                        - prev.astype(np.int16)).mean()))
        prev = gray
    cap.release()
    return motion


def _runs(motion, fps, thresh, min_run):
    """找出连续的静止段，返回 [(起帧, 止帧)]（止帧不含）。"""
    out, start = [], None
    for i, m in enumerate(motion):
        still = m < thresh
        if still and start is None:
            start = i
        elif not still and start is not None:
            if (i - start) >= int(min_run * fps):
                out.append((start, i))
            start = None
    if start is not None and (len(motion) - start) >= int(min_run * fps):
        out.append((start, len(motion)))
    return out


def compress_still(src, dst, ffmpeg=None, encoder="h264_mf", fps=25.0):
    """压缩 src 里的静止段并写出 dst；没有可压的段就返回 None（不产出）。"""
    if os.environ.get("DEMO_COMPRESS_STILL", "1") == "0":
        return None
    if not ffmpeg:
        try:
            import sys
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import director  # noqa: F401
        except Exception:
            pass
        from director import find_h264_ffmpeg
        ffmpeg, encoder = find_h264_ffmpeg()
        if not ffmpeg:
            return None
    min_run = _env_f("DEMO_STILL_MIN_RUN", 6.0)
    target = _env_f("DEMO_STILL_TARGET", 3.0)
    keep_tail = _env_f("DEMO_STILL_KEEP_TAIL", 3.0)
    thresh = _env_f("DEMO_STILL_THRESH", 2.0)

    motion = _motion(src, fps)
    runs = _runs(motion, fps, thresh, min_run)
    if not runs:
        return None

    drop = set()
    for a, b in runs:
        tail = int(keep_tail * fps)
        head_end = max(a, b - tail)
        head = head_end - a
        if head <= 0:
            continue
        keep = max(1, int(round(target * fps)))
        step = max(1, head // keep)
        for i in range(a, head_end):
            if (i - a) % step:
                drop.add(i)
    if not drop:
        return None

    import cv2
    cap = cv2.VideoCapture(src)
    proc = None
    n = 0
    i = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if i not in drop:
            if proc is None:
                h, w = frame.shape[:2]
                proc = subprocess.Popen(
                    [ffmpeg, "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
                     "-s", "%dx%d" % (w, h), "-r", str(fps), "-i", "-",
                     "-c:v", encoder, "-b:v", "20M", "-pix_fmt", "yuv420p",
                     "-loglevel", "error", dst], stdin=subprocess.PIPE)
            proc.stdin.write(frame.tobytes())
            n += 1
        i += 1
    cap.release()
    if proc is None:
        return None
    proc.stdin.close()
    proc.wait(timeout=900)
    saved = (len(drop)) / float(fps or 25)
    return {"runs": len(runs), "dropped_frames": len(drop),
            "saved_seconds": round(saved, 1), "kept_frames": n}
