# -*- coding: utf-8 -*-
"""把 shots.json 里的动作翻译成页面操作；换平台只改 JSON，不改 Python。

配合 director.py 使用：
    python -B scripts/director.py --shots-file scripts/shots.json --narrate

动作表见同目录 shot_runner.md。
"""
import json
import os
import re
import time

TITLE_CARD = """<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<style>html,body{margin:0;height:100%%;background:
radial-gradient(1200px 700px at 30%% 18%%,#0b2a4a 0%%,#04101f 55%%,#020a1e 100%%);
color:#e6f4ff;font-family:"Microsoft YaHei",sans-serif;display:flex;
align-items:center;justify-content:center}.w{text-align:center}
h1{margin:0;font-size:64px;line-height:1.4;letter-spacing:2px;
background:linear-gradient(90deg,#67e8f9,#38bdf8 45%%,#a5b4fc);
-webkit-background-clip:text;background-clip:text;color:transparent}
.r{margin:30px auto 0;width:360px;height:2px;
background:linear-gradient(90deg,transparent,#22d3ee,transparent)}
.c{margin-top:30px;font-size:30px;color:#9fd8ff;letter-spacing:6px}
.f{margin-top:26px;font-size:18px;color:#5f88ad;letter-spacing:3px}</style></head>
<body><div class="w"><h1>%s<br>%s</h1><div class="r"></div>
<div class="c">%s</div><div class="f">%s</div></div></body></html>"""


# ---------------- 加载 ----------------
def load(path):
    """读 shots.json，产出 director 可直接用的镜头表。"""
    import io
    spec = load_spec(path)
    return shots_of(spec)


def load_spec(path):
    """读整份 specs.json（含 cover / diagrams / rail / chapters）。"""
    import io
    return json.load(io.open(path, encoding="utf-8"))


def shots_of(spec):
    base = str(spec.get("base") or "").rstrip("/")
    out = []
    for s in spec.get("shots", []):
        steps = s.get("steps", [])
        pre = s.get("pre")
        out.append({
            "code": s["code"], "title": s.get("title", s["code"]),
            "target": float(s.get("target", 20)),
            "pad": not bool(s.get("locked", False)),
            "pre": (lambda rec, p=pre: pre_run(rec, p)) if pre else None,
            "fn": (lambda page, rec, st=steps, b=base: run_steps(page, rec, st, b)),
        })
    return out


def pre_run(rec, spec):
    """开拍前预处理：准备前置数据、启动外部程序、等到窗口前若干秒。"""
    if spec.get("prepare") and hasattr(rec, "ensure_ready"):
        rec.ensure_ready()
    for cond in (spec.get("prepare") or []):
        m = re.match(r"(\w+)\s*>=\s*([\d.]+)", str(cond))
        if m:
            wait_external(rec, {"kind": m.group(1), "value": float(m.group(2))})


# ---------------- 执行 ----------------
def run_steps(page, rec, steps, base):
    for st in steps:
        if not isinstance(st, dict) or not st:
            continue
        (kind, arg), = list(st.items())[:1]
        step(page, rec, kind, arg, base)


def step(page, rec, kind, arg, base):
    if kind == "goto":
        page.goto(base + str(arg), wait_until="domcontentloaded")
    elif kind == "wait":
        page.wait_for_timeout(int(float(arg) * 1000))
    elif kind == "title_card":
        m = arg if isinstance(arg, dict) else {"line1": str(arg)}
        page.set_content(TITLE_CARD % (m.get("line1", ""), m.get("line2", ""),
                                       m.get("case", ""), m.get("foot", "")),
                         wait_until="load")
    elif kind == "show_image":
        # 配图镜头：把一张 PNG/SVG 渲染出的图铺满画面，其余流程与页面镜头一致
        path = str(arg)
        if not os.path.isabs(path):
            raise ValueError("show_image 需要绝对路径：%r" % path)
        import base64
        ext = os.path.splitext(path)[1].lstrip(".").lower() or "png"
        mime = {"png": "image/png", "jpg": "image/jpeg",
                "jpeg": "image/jpeg", "svg": "image/svg+xml"}.get(ext, "image/png")
        with open(path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")
        # 注意：CSS 里有 %（100%），这里用 replace 拼装，别用 % 格式化
        html = ('<!doctype html><html><head><meta charset="utf-8"><style>'
                'html,body{margin:0;height:100%;background:#F5F8FC;}'
                'img{width:100%;height:100%;object-fit:contain;display:block}'
                '</style></head><body><img src="data:__MIME__;base64,__B64__">'
                '</body></html>'
                .replace("__MIME__", mime).replace("__B64__", b64))
        page.set_content(html, wait_until="load")
        page.wait_for_timeout(500)
    elif kind == "expect_text":
        if isinstance(arg, dict):
            txt, to = arg.get("text", ""), int(arg.get("timeout", 30000))
        else:
            txt, to = arg, 30000
        rec.expect_visible(page.get_by_text(str(txt)), "文案：%s" % txt,
                           timeout_ms=to)
    elif kind == "expect_selector":
        rec.expect_visible(page.locator(arg["css"]).first,
                           arg.get("what") or arg["css"],
                           timeout_ms=int(arg.get("timeout", 30000)))
    elif kind == "click":
        click(page, arg)
    elif kind == "fill":
        loc = page.locator(arg["selector"]).first
        loc.fill(str(arg.get("text", "")))
    elif kind == "scroll":
        # 结果常在折叠下方：滚到指定元素，或直接到底
        if isinstance(arg, str) and arg == "bottom":
            page.evaluate("() => window.scrollTo(0, document.body.scrollHeight)")
        elif isinstance(arg, str) and arg == "top":
            page.evaluate("() => window.scrollTo(0, 0)")
        else:
            page.locator(arg["selector"]).first.scroll_into_view_if_needed()
        page.wait_for_timeout(600)
    elif kind == "select":
        # Element UI 下拉：先点 el-select，再在浮层里点同名选项（精确匹配，避免 X1 命中 X1_01）
        import re as _re
        sel = arg.get("selector") or ".el-select"
        box = page.locator(sel).nth(int(arg.get("nth", 0)))
        # 幂等：multiple 下拉点已选项 = 取消选择。平台会持久化映射，
        # 重跑同一镜时必须先看是否已经选中，避免"点一次加、再点一次减"。
        # 用完整选项名判断（去掉尾部的列数），否则「单列 X1」会被误判成「【全组】X1」
        want = str(arg["option"]).split("（")[0]
        box.click()
        page.wait_for_timeout(400)
        tags_before = box.locator(".el-tag").count()
        if arg.get("type"):
            # remote 模式：选项要输入关键字触发远程检索后才出现
            page.keyboard.type(str(arg["type"]))
            page.wait_for_timeout(900)
        opts = page.locator(".el-select-dropdown__item:visible")
        if arg.get("exact", True):
            item = opts.filter(
                has_text=_re.compile("^%s$" % _re.escape(str(arg["option"]))))
        else:
            # 整组选项的标签形如「【全组】Y1（50）」，只能用子串匹配
            item = opts.filter(has_text=str(arg["option"]))
        # 幂等：多选下拉点已选项等于取消选择。标签在 collapse-tags 下会被折叠成
        # “+N”，靠标签文本判断不可靠；直接读选项自身的选中态。
        cls = item.first.get_attribute("class") or ""
        if "selected" in cls:
            page.keyboard.press("Escape")
            page.wait_for_timeout(150)
            return
        item.first.click()
        page.wait_for_timeout(400)
        page.keyboard.press("Escape")      # 关掉浮层，避免影响下一个下拉
        page.wait_for_timeout(200)
        # 多选下拉必须确认值真的写进去了，否则后续门禁会静默不通过
        tags_after = box.locator(".el-tag").count()
        shown = box.inner_text() if not tags_after else ""
        if tags_after <= tags_before and str(arg["option"]) not in shown.replace("×", ""):
            raise ValueError("下拉未生效：%s 未写入 %r（选前 %d / 选后 %d 个标签）"
                             % (sel, arg["option"], tags_before, tags_after))
    elif kind == "click_row_action":
        row_action(page, arg["row_text"], arg["button"])
    elif kind == "upload":
        upload(page, arg, base)
    elif kind == "mark":
        mark(page, rec, arg)
    elif kind == "still":
        rec.still(page, str(arg))
    elif kind == "assert_text_count":
        txt = page.locator(arg["selector"]).first.inner_text()
        if str(arg["expect"]) not in txt:
            raise ValueError("断言失败：%s 中未出现 %s（实际 %r）"
                             % (arg["selector"], arg["expect"], txt[:60]))
    elif kind == "wait_external":
        wait_external(rec, arg)
    elif kind == "wait_until_event":
        wait_until_event(rec, page, arg)
    elif kind == "call":
        fn = getattr(rec, str(arg), None)
        if fn is None:
            raise ValueError("call 目标不存在：%s" % arg)
        fn()
    else:
        raise ValueError("未知动作：%s（见 shot_runner.md 动作表）" % kind)


def click(page, spec):
    if "selector" in spec:
        page.locator(spec["selector"]).first.click()
    else:
        page.get_by_role(spec.get("role", "button"),
                         name=spec["name"]).first.click()


def row_action(page, row_text, button):
    """表格固定列专用：按钮不在数据行里，只能按数据行序号对齐按钮序号。"""
    deadline = time.time() + 30
    while time.time() < deadline:
        rows = page.locator(".el-table__body-wrapper tbody tr, tbody tr")
        idx = None
        for i in range(rows.count()):
            try:
                if row_text in rows.nth(i).inner_text():
                    idx = i
                    break
            except Exception:
                pass
        if idx is not None:
            page.get_by_role("button", name=button).nth(idx).click()
            return
        page.wait_for_timeout(200)
    raise ValueError("未找到含 %r 的数据行，无法点击 %r" % (row_text, button))


def upload(page, spec, base):
    path = str(spec["file"])
    if path.startswith("<") or not os.path.isabs(path):
        raise ValueError("upload.file 必须是绝对路径，当前为 %r" % path)
    with page.expect_file_chooser(timeout=30000) as fc:
        click(page, spec["click"])
    fc.value.set_files(path)
    if spec.get("selector"):
        sel = spec["selector"]
        if page.locator(sel).count() == 0:
            raise ValueError("上传后找不到目标元素：%s" % sel)


def mark(page, rec, spec):
    if spec.get("click"):
        click(page, spec["click"])
        page.wait_for_timeout(600)
    sel = spec.get("selector") or spec.get("css")
    if not sel:
        raise ValueError("mark 需要 selector 或 click")
    rec.mark(page, sel, spec.get("label") or "标注", float(spec.get("hold", 3.5)))


def _get_json(url, timeout=15):
    import urllib.request
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def wait_external(rec, spec):
    """等外部时序推进：轮询状态接口的某个字段到阈值（接口用环境变量配置）。"""
    url = os.environ.get("EXTERNAL_STATUS_URL")
    if not url:
        raise ValueError("wait_external 需要环境变量 EXTERNAL_STATUS_URL")
    key_name = spec.get("kind") or "t"
    limit = time.time() + float(spec.get("timeout", 180))
    while time.time() < limit:
        try:
            if float(_get_json(url).get(key_name) or 0) >= float(spec["value"]):
                return
        except Exception:
            pass
        time.sleep(0.4)
    raise ValueError("等待外部 %s >= %s 超时" % (key_name, spec["value"]))


def wait_until_event(rec, page, spec):
    """等某类事件出现；出现即按要求加框标注。接口用环境变量 EVENTS_URL 配置。"""
    url = os.environ.get("EVENTS_URL")
    if not url:
        raise ValueError("wait_until_event 需要环境变量 EVENTS_URL")
    key = spec.get("keyword") or ""
    limit = time.time() + float(spec.get("timeout", 180))
    while time.time() < limit:
        try:
            data = _get_json(url)
            evs = data.get("events") if isinstance(data, dict) else data
            if any(key in ((e.get("symbol") or "") + (e.get("title") or ""))
                   for e in (evs or [])):
                if spec.get("selector") and spec.get("mark_label"):
                    rec.mark(page, spec["selector"], spec["mark_label"],
                             float(spec.get("hold", 4.5)))
                return
        except Exception:
            pass
        page.wait_for_timeout(1000)
    raise ValueError("等待事件 %r 超时" % key)
