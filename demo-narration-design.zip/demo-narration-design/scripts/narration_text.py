# -*- coding: utf-8 -*-
"""演示剧本讲解词的精简版（缩句用），并把结果写回剧本。

约束：每镜必须保留三要素——瓶颈（原来靠人做什么、错在哪）、
工作（软件这一步接管了什么）、亮点（支撑它可信的技术/机制）。
字数按配音时长倒推：Huihui 默认语速约 3.2 字/秒，剧本各镜时长为
20/20/40/30/20/20/30/20/20/10/10 秒，本表按约 4 字/秒留出余量。

Run:  python -B record\\narration_text.py --apply
"""
import argparse
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPT = os.path.join(ROOT, "demo", "<SCRIPT_MD>")

# code -> (瓶颈 / 工作 / 亮点 三要素齐全的精简讲解词)
NARRATION = {
    "S1": "本方案主题为基于多传感器混合数据流的自适应集成接入与深度软测量，"
          "覆盖接入、监测、判型、预测与召回全链路，下面以<OBJECT>为例走完一次实际业务。",

    "S2": "软件启动不预置方案、数据源与历史事件，每次接入都由操作人员显式建档。"
          "联调现场因此能在干净状态下按同一套步骤复现，不被历史数据干扰，"
          "变更全程可追溯。",

    "S3": "软件在空白状态下仅接收一份配置 ZIP，即完成两条时序接入方案与一路<SUBJECT>图像"
          "通道的建档。配置采用总 CSV 加协议详情 txt 的结构，端口、同步字、解析模板与"
          "引擎参数均由文件描述。该流程把协议接入从工程师手工改代码，转为标准化配置交付，"
          "为异构仪器接入提供可复用、可留档、可回滚的路径。",

    "S4": "原始协议以自然语言或 Markdown 形式存在，无法直接交给解析器执行；原先只能人工"
          "逐条誊写成模板，一处笔误就会打断接收链路。系统调用语言模型按纯符号规范转换成"
          "中间产物模板，再由确定性编译器即时校验，输出非法就回馈模型重试。协议理解由此"
          "变为描述即配置，并以编译期校验约束模型输出。",

    "S5": "解析结果进入业务链路前，系统设置一道质量门：离线编译、保存、批量上线依次完成。"
          "校验拦截不可执行的模板，保存形成配置基线，上线才把规则投入运行，每次变更都"
          "留下记录。",

    "S6": "档案建立后，虚拟数据源端作为测试仪器接入链路，按同一份配置向三个端口发送时序与"
          "图像数据。仪器侧独立运行，软件只消费协议定义的数据，测试设备可不停软件地接入、"
          "替换或退出。",

    "S7": "本方案采用无监督冷启动：只用正常数据建立动态正常原点带，不依赖故障标签训练"
          "分类器。航天在轨场景故障标签稀缺，标签分布差异还会带来外推误差，固定阈值又随"
          "工况漂移频繁失效。正常标定段建立带内约束，为异常判定提供可解释基础。",

    "S8": "传统做法把时序与图像分开，同一物理事件的证据无法在一个事件流里检索。本例图像"
          "裂纹与时序功率跌落指向同一物理过程；软件统一接入、分离证据，再按设备与时间"
          "汇聚事件，通道证据各自留存。",

    "S9": "另一个痛点是阈值尺度与故障尺度不匹配：组级故障要多通道同步判据，少通道退化要"
          "单通道持续证据。本例故障集中在温度等少量通道，采用窗前基线局部签名与趋势签名，"
          "保留通道级归因。",

    "S10": "传统预警直接在原始时序上设阈或回归，噪声与周期会淹没趋势。本方案让监测与预测"
           "共用同一归一化偏移，只外推诊断孪生指标，并以残差给出置信度、屏蔽弱证据；"
           "故障恢复后事件闭合，演化曲线可一并回看。",

    "S11": "全流程由此闭合：接入、监测、判型、预测与召回共用同一数据契约。即使数据源端停止，"
           "软件仍可回看历史事件与预测记录；新对象只需新增配置，不必改软件本体，每条结论"
           "都能回指通道、点位与时间。",
}


def wrap(text, width=40):
    return "\n".join(text[i:i + width] for i in range(0, len(text), width))


def apply(path=SCRIPT):
    with open(path, encoding="utf-8") as f:
        text = f.read()
    hits = []

    def repl(m):
        code = "S" + m.group(2)
        new = NARRATION.get(code)
        if not new:
            return m.group(0)
        hits.append(code)
        return m.group(1) + wrap(new)

    pattern = re.compile(r"(^###\s+S(\d+)\s+.*?^讲解词：)(.*?)(?=\n\s*\n|\Z)",
                         flags=re.M | re.S)
    text = pattern.sub(repl, text)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return hits


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="把精简讲解词写回演示剧本")
    ap.add_argument("--apply", action="store_true", help="确认写回剧本文件")
    ap.add_argument("--script", default=SCRIPT)
    args = ap.parse_args()
    if not args.apply:
        for code in sorted(NARRATION, key=lambda c: int(c[1:])):
            print("%s %3d 字" % (code, len(NARRATION[code])))
        print("\n加 --apply 才会写回剧本")
        sys.exit(0)
    changed = apply(args.script)
    print("已改写讲解词：%s" % "、".join(changed))
