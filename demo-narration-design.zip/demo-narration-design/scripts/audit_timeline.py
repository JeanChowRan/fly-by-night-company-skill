# -*- coding: utf-8 -*-
"""成片逐镜审计：时长账、标注窗口、代表帧非空，三条都要过。

用法：python scripts/audit_timeline.py <run目录> [成片文件]

为什么需要它：
- 镜头"标题里有封面/架构/创新"≠那段画面真的到位，必须抽帧看像素；
- 定格标注若落在裁剪点之后，观众永远看不到，必须逐处核对时间窗；
- 音轨与画面若各按一套收尾公式算，会逐镜累计成字幕大空档，必须把账对齐。
"""
import glob
import io
import json
import os
import re
import subprocess
import sys
import tempfile

import numpy as np
from PIL import Image

TAIL = 0.4


def _ffmpeg():
    from director import find_h264_ffmpeg
    return find_h264_ffmpeg()[0] or "ffmpeg"


def _duration(exe, path):
    out = subprocess.run([exe, "-hide_banner", "-i", path],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         timeout=300).stdout.decode("utf-8", "replace")
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", out)
    if not m:
        return None
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def _holds(shot):
    # 配图类框注（第 5 位为 False）不冻结画面，不计入时长
    return sum(a[1] for a in (shot.get("annos") or [])
               if len(a) < 5 or a[4])


def audit(run_dir):
    """返回 (rows, problems)：rows 为逐镜台账，problems 为阻止交付的问题。"""
    exe = _ffmpeg()
    with io.open(os.path.join(run_dir, "manifest.json"),
                 encoding="utf-8") as fh:
        man = json.load(fh)
    films = [p for p in glob.glob(os.path.join(run_dir, "成片_*.mp4"))
             if "_part_" not in p and "_joined" not in p]
    film = films[0] if films else ""
    if film:
        with io.open(os.path.join(run_dir, "shots.json"), "a+"):
            pass
    audio = os.path.join(run_dir, "narration.wav")
    audio_s = _duration(exe, audio) if os.path.isfile(audio) else None
    rows, problems, t = [], [], 0.0
    shots = [s for s in man.get("shots", [])
             if s.get("status") == "OK" and s.get("video")]
    for s in shots:
        clip = _duration(exe, os.path.join(run_dir, s["video"]))
        hold = _holds(s)
        wav = os.path.join(run_dir, "narration", "%s.wav" % s["code"])
        need = _duration(exe, wav) if os.path.isfile(wav) else None
        raw = (clip or 0) + hold
        span = raw
        if need and raw - (need + TAIL) > 0.4:
            span = need + TAIL
        for a in (s.get("annos") or []):
            t_anno, hold_a = float(a[0]), float(a[1])
            if len(a) > 4 and not a[4]:
                continue            # 静态图段只叠框，不冻结
            if t_anno + hold_a > span + 0.01:
                problems.append(
                    "%s 定格标注（%.1fs + %.1fs）落在画面窗口 %.1fs 之外，"
                    "观众看不到" % (s["code"], t_anno, hold_a, span))
        if need and need > raw + 0.05:
            problems.append("%s 旁白 %.1fs 长于画面 %.1fs，配音会被压缩"
                            % (s["code"], need, raw))
        rows.append({"code": s["code"], "title": s.get("title", ""),
                     "start": t, "end": t + span, "clip": clip or 0,
                     "hold": hold, "need": need or 0, "span": span})
        t += span
    # 代表帧非空：空白/纯色帧说明这段没画面
    tmp = os.path.join(tempfile.gettempdir(), "_audit_frame.png")
    if film:
        for r in rows:
            stamp = r["start"] + max(0.4, (r["end"] - r["start"]) * 0.5)
            subprocess.run([exe, "-y", "-ss", "%.2f" % stamp, "-i", film,
                            "-frames:v", "1", tmp, "-loglevel", "error"],
                           check=False)
            if not os.path.isfile(tmp):
                problems.append("%s 未能抽到代表帧" % r["code"])
                continue
            arr = np.asarray(Image.open(tmp).convert("RGB")).astype(float)
            r["std"] = float(arr.std())
            if arr.std() < 5.0:
                problems.append("%s（%.1f–%.1fs）代表帧近乎空白（std %.1f）"
                                % (r["code"], r["start"], r["end"], arr.std()))
        if os.path.isfile(tmp):
            os.remove(tmp)
    if audio_s and abs((rows[-1]["end"] if rows else 0) - audio_s) > 2.0:
        problems.append("画面总长 %.1fs 与旁白轨 %.1fs 相差超过 2s"
                        % (rows[-1]["end"] if rows else 0, audio_s))
    return rows, problems, audio_s, film


def main(run_dir):
    rows, problems, audio_s, film = audit(run_dir)
    print("成片：%s（旁白轨 %.1fs）" % (os.path.basename(film or "-"),
                                       audio_s or 0))
    print("%-6s %-28s %8s %8s %7s %7s %7s %6s"
          % ("镜头", "标题", "起点", "终点", "分镜", "定格", "旁白", "帧std"))
    for r in rows:
        print("%-6s %-28s %8.1f %8.1f %7.1f %7.1f %7.1f %6.1f"
              % (r["code"], r["title"][:24], r["start"], r["end"], r["clip"],
                 r["hold"], r["need"], r.get("std", -1)))
    print("\n镜头 %d 个，画面总长 %.1fs" % (len(rows), rows[-1]["end"]
                                            if rows else 0))
    if problems:
        print("未通过 %d 项：" % len(problems))
        for p in problems:
            print("  - %s" % p)
        return 1
    print("三项门禁全部通过：时长账一致 / 标注都在画面窗口内 / 代表帧非空")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "."))
