# -*- coding: utf-8 -*-
"""生成两张配图：业务痛点图（S2B）、关键技术流图（S7B，4 个高亮状态）。"""
import io
import os

OUT = os.path.dirname(os.path.abspath(__file__))

DEFS = '''  <defs>
    <linearGradient id="gb" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#0E7C86" stop-opacity="0.10"/>
      <stop offset="1" stop-color="#0E7C86" stop-opacity="0.04"/></linearGradient>
    <pattern id="dots" width="16" height="16" patternUnits="userSpaceOnUse">
      <circle cx="2" cy="2" r="1" fill="#0E7C86" opacity="0.20"/></pattern>
    <pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse">
      <path d="M24 0H0V24" fill="none" stroke="#1E3A5F" stroke-width="0.6" opacity="0.18"/></pattern>
    <filter id="soft" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="2" stdDeviation="4" flood-color="#1E3A5F" flood-opacity="0.10"/></filter>
  </defs>
'''

HEAD = ('<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" '
        'viewBox="0 0 1920 1080">\n' + DEFS +
        '<rect x="0" y="0" width="1920" height="1080" fill="#F5F8FC"/>\n'
        '<rect x="0" y="0" width="1920" height="1080" fill="url(#grid)" opacity="0.35"/>\n')


def title(main, sub):
    return ('<text x="80" y="96" font-family="SimSun, serif" font-size="46" '
            'font-weight="bold" fill="#12263A">%s</text>\n'
            '<text x="80" y="136" font-family="SimSun, serif" font-size="24" '
            'fill="#5A6B7C">%s</text>\n'
            '<rect x="80" y="152" width="1760" height="2" fill="#1E3A5F" '
            'opacity="0.18"/>\n' % (main, sub))


def band(y, h, color, name, sub):
    return ('<rect x="80" y="%d" width="1760" height="%d" rx="14" fill="url(#gb)"/>\n'
            '<rect x="80" y="%d" width="1760" height="%d" rx="14" fill="url(#dots)" opacity="0.5"/>\n'
            '<rect x="80" y="%d" width="1760" height="%d" rx="14" fill="none" '
            'stroke="%s" stroke-width="1.5" stroke-opacity="0.45"/>\n'
            '<rect x="80" y="%d" width="8" height="%d" rx="4" fill="%s"/>\n'
            '<text x="112" y="%d" font-family="SimSun, serif" font-size="34" '
            'font-weight="bold" fill="%s">%s</text>\n'
            '<text x="112" y="%d" font-family="SimSun, serif" font-size="21" '
            'fill="#5A6B7C">%s</text>\n'
            % (y, h, y, h, y, h, color, y, h, color,
               y + 108, color, name, y + 146, sub))


def card(x, y, w, h, lines, accent, big=False, icon_cx=None):
    s = ('<rect x="%d" y="%d" width="%d" height="%d" rx="12" fill="#FFFFFF" '
         'filter="url(#soft)"/>\n' % (x, y, w, h))
    s += ('<rect x="%d" y="%d" width="%d" height="%d" rx="12" fill="%s" fill-opacity="%s"/>\n'
          '<rect x="%d" y="%d" width="%d" height="%d" rx="12" fill="none" stroke="%s" '
          'stroke-width="%s"/>\n' % (x, y, w, h, accent,
                                     "0.10" if big else "0.05", x, y, w, h,
                                     accent, "1.8" if big else "1.2"))
    fs = 24 if big else 21
    step = 34 if big else 31
    ty = y + 44
    for i, ln in enumerate(lines):
        fill = accent if (i == 0 and big) else "#455A6E"
        weight = ' font-weight="bold"' if i == 0 else ""
        s += ('<text x="%d" y="%d" font-family="SimSun, serif" font-size="%d"%s '
              'fill="%s">%s</text>\n' % (x + 22, ty, fs, weight, fill, ln))
        ty += step
    return s


# ---------------- 图一：业务痛点图 ----------------
def pain_svg():
    b = [HEAD, title("业务痛点与突破", "从人工誊写与固定阈值，到配置化接入与可解释判据")]
    b.append(band(176, 196, "#B3353A", "传统做法", "人工驱动"))
    for i, (t, ln) in enumerate([
            ("协议接入", ["人工誊写改代码", "一处笔误即停线"]),
            ("异常判定", ["固定阈值", "随工况漂移失效"]),
            ("多源巡检", ["时序看曲线", "图像靠人工判读"])]):
        b.append(card(252 + i * 520, 200, 490, 148, [t] + ln, "#B3353A"))
    b.append(band(396, 196, "#B3353A", "业务痛点", "代价明确"))
    for i, (t, ln) in enumerate([
            ("标签稀缺", ["在轨故障样本少", "分类器难训练"]),
            ("证据割裂", ["同一事件两路证据", "无法同流检索"]),
            ("追溯困难", ["结论指不回", "通道与点位"])]):
        b.append(card(252 + i * 520, 420, 490, 148, [t] + ln, "#B3353A"))
    b.append(band(616, 196, "#0E7C86", "软件突破", "机制接管"))
    for i, (t, ln) in enumerate([
            ("协议即配置", ["LLM 转中间契约", "编译期门禁校验"]),
            ("无监督基线", ["只用正常数据", "动态原点带"]),
            ("跨源汇聚", ["统一接入分离证据", "按设备与时间聚合"])]):
        b.append(card(252 + i * 520, 640, 490, 148, [t] + ln, "#0E7C86", big=True))
    b.append(band(836, 196, "#2F7D4F", "业务收益", "可回查"))
    for i, (t, ln) in enumerate([
            ("接入提速", ["改代码变为配配置", "可复用可回滚"]),
            ("误报受控", ["残差给置信度", "弱证据屏蔽"]),
            ("全程可溯", ["回指通道与点位", "事件可闭合"])]):
        b.append(card(252 + i * 520, 860, 490, 148, [t] + ln, "#2F7D4F"))
    b.append('</svg>\n')
    return "".join(b)


# ---------------- 图二：关键技术流图（4 个高亮态） ----------------
FLOW = [("采集接入", ["帧同步解析", "端口与通道"]),
        ("特征构建", ["动态原点带", "窗前局部签名"]),
        ("图像签名", ["金字塔分区", "逐叶余弦评分"]),
        ("判定汇聚", ["AND 规则链", "按设备时间聚合"]),
        ("预测闭环", ["趋势外推", "事件闭合可回查"])]


def flow_svg(active):
    b = [HEAD, title("关键技术流", "采集接入 → 特征构建 → 图像签名 → 判定汇聚 → 预测闭环")]
    for i, (t, ln) in enumerate(FLOW):
        x = 80 + i * 356
        on = (i == active)
        color = "#0E7C86" if on else "#8794A3"
        b.append('<rect x="%d" y="236" width="316" height="256" rx="14" fill="%s" '
                 'fill-opacity="%s"/>\n'
                 '<rect x="%d" y="236" width="316" height="256" rx="14" fill="none" '
                 'stroke="%s" stroke-width="%s"/>\n'
                 % (x, color, "0.14" if on else "0.04", x, color,
                    "2.4" if on else "1.2"))
        b.append('<rect x="%d" y="236" width="316" height="56" rx="14" fill="%s" '
                 'fill-opacity="%s"/>\n' % (x, color, "0.22" if on else "0.08"))
        b.append('<text x="%d" y="272" text-anchor="middle" font-family="SimSun, serif" '
                 'font-size="26" font-weight="bold" fill="%s">%s</text>\n'
                 % (x + 158, color if on else "#5A6B7C", t))
        b.append('<text x="%d" y="273" text-anchor="middle" font-family="SimSun, serif" '
                 'font-size="24" font-weight="bold" fill="%s">%d</text>\n'
                 % (x + 292, color if on else "#B8C2CC", i + 1))
        ty = 344
        for ln in ln:
            b.append('<text x="%d" y="%d" text-anchor="middle" font-family="SimSun, serif" '
                     'font-size="22" fill="%s">%s</text>\n'
                     % (x + 158, ty, "#455A6E" if on else "#8A98A6", ln))
            ty += 40
        b.append('<rect x="%d" y="440" width="240" height="6" rx="3" fill="%s" '
                 'fill-opacity="%s"/>\n' % (x + 38, color, "0.85" if on else "0.20"))
    b.append('<text x="80" y="560" font-family="SimSun, serif" font-size="24" '
             'fill="#5A6B7C">当前环节以强调色标示，其余环节压灰——说明链条走到哪一步</text>\n')
    b.append('</svg>\n')
    return "".join(b)


# ---------------- 纵向技术流条（叠在演示右侧） ----------------
def rail_svg(active):
    W, H = 430, 1000
    b = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
         'viewBox="0 0 %d %d">\n' % (W, H, W, H) + DEFS]
    b.append('<rect x="0" y="0" width="%d" height="%d" rx="18" fill="#0B1A2B" '
             'fill-opacity="0.90"/>\n' % (W, H))
    b.append('<rect x="0" y="0" width="%d" height="%d" rx="18" fill="none" '
             'stroke="#22D3EE" stroke-opacity="0.35"/>\n' % (W, H))
    b.append('<text x="28" y="52" font-family="SimSun, serif" font-size="26" '
             'font-weight="bold" fill="#9FE8F5">关键技术流</text>\n')
    top, gap, ch = 88, 176, 156
    for i, (t, ln) in enumerate(FLOW):
        y = top + i * gap
        on = (i == active)
        col = "#22D3EE" if on else "#5A7186"
        below = (i < active)
        b.append('<rect x="26" y="%d" width="378" height="%d" rx="12" fill="%s" '
                 'fill-opacity="%s"/>\n'
                 '<rect x="26" y="%d" width="378" height="%d" rx="12" fill="none" '
                 'stroke="%s" stroke-width="%s"/>\n'
                 % (y, ch, col, "0.20" if on else "0.06", y, ch, col,
                    "2.2" if on else "1"))
        b.append('<circle cx="58" cy="%d" r="15" fill="%s" fill-opacity="%s"/>\n'
                 '<circle cx="58" cy="%d" r="15" fill="none" stroke="%s" '
                 'stroke-width="2"/>\n'
                 % (y + 30, col, "0.95" if on else "0.20", y + 30, col))
        b.append('<text x="58" y="%d" text-anchor="middle" font-family="SimSun, serif" '
                 'font-size="18" font-weight="bold" fill="%s">%d</text>\n'
                 % (y + 37, "#06202B" if on else "#8AA0B4", i + 1))
        b.append('<text x="88" y="%d" font-family="SimSun, serif" font-size="25" '
                 'font-weight="bold" fill="%s">%s</text>\n'
                 % (y + 38, "#EAF7FC" if on else "#7F96AB", t))
        for k, x in enumerate(ln):
            b.append('<text x="%d" y="%d" font-family="SimSun, serif" font-size="19" '
                     'fill="%s">%s</text>\n'
                     % (88, y + 70 + k * 27, "#BFE4F0" if on else "#5F7A90", x))
        if i < len(FLOW) - 1:
            b.append('<rect x="56" y="%d" width="4" height="%d" rx="2" fill="%s" '
                     'fill-opacity="%s"/>\n'
                     % (y + ch, gap - ch - 6, "#22D3EE" if below else "#3B4E60",
                        "0.75" if below else "0.30"))
    b.append('</svg>\n')
    return "".join(b)


# ---------------- 效益总结 ----------------
BENEFIT = [("接入提速", ["协议理解由人工誊写", "转为描述即配置", "可复用 · 可留档 · 可回滚"]),
           ("判据可信", ["无监督冷启动建基线", "不依赖故障标签", "编译期校验约束模型输出"]),
           ("证据合一", ["时序与图像同流检索", "按设备与时间汇聚", "通道与点位级归因"]),
           ("闭环可溯", ["残差给置信度", "弱证据屏蔽防误报", "结论可回指时间与证据"])]


def summary_svg():
    b = [HEAD, title("效益总结", "接入、监测、判型、预测与召回共用同一数据契约")]
    for i, (t, ln) in enumerate(BENEFIT):
        x = 80 + i * 440
        b.append(card(x, 208, 400, 356, [t] + ln, "#0E7C86", big=True))
        b.append('<rect x="%d" y="%d" width="400" height="6" rx="3" '
                 'fill="#0E7C86" fill-opacity="0.75"/>\n' % (x, 544))
    b.append(band(612, 176, "#2F7D4F", "闭环口径", "每条结论可回指"))
    for i, ln in enumerate(["新对象只新增配置", "不改软件程序",
                            "配置承载对象差异", "证据承载解释", "事件承载结论"]):
        x = 252 + i * 332
        b.append('<rect x="%d" y="648" width="300" height="112" rx="12" '
                 'fill="#2F7D4F" fill-opacity="0.07"/>\n'
                 '<rect x="%d" y="648" width="300" height="112" rx="12" '
                 'fill="none" stroke="#2F7D4F" stroke-opacity="0.30"/>\n'
                 '<text x="%d" y="714" text-anchor="middle" font-family="SimSun, serif" '
                 'font-size="22" fill="#455A6E">%s</text>\n'
                 % (x, x, x + 150, ln))
    b.append('<text x="80" y="860" font-family="SimSun, serif" font-size="22" '
             'fill="#8A98A6">软件监视平台与虚拟数据源端为两个独立进程，'
             '仅通过配置 ZIP 对齐协议、端口、通道与引擎参数</text>\n')
    return "".join(b) + "</svg>\n"


if __name__ == "__main__":
    io.open(os.path.join(OUT, "S2B_业务痛点图.svg"), "w",
            encoding="utf-8", newline="").write(pain_svg())
    for i in range(len(FLOW)):
        io.open(os.path.join(OUT, "S7B_关键技术流_%d.svg" % i), "w",
                encoding="utf-8", newline="").write(flow_svg(i))
        io.open(os.path.join(OUT, "RAIL_%d.svg" % i), "w",
                encoding="utf-8", newline="").write(rail_svg(i))
    io.open(os.path.join(OUT, "S12_效益总结.svg"), "w",
            encoding="utf-8", newline="").write(summary_svg())
    print("已生成：S2B / S7B×5 / RAIL×5 / S12")
