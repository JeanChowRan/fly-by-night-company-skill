# 可复用录制管线（本目录）

这套脚本来自"<OBJECT> · 软件监视平台"演示视频的实际生产，直接复制到目标项目的
`record/` 目录即可复用。**它不是软件交付物的一部分**：只是摄像机，不修改被测平台。

## 文件

| 文件 | 作用 |
|---|---|
| `director.py` | 主流程：启动平台 → 逐镜录制 → 配音 → 字幕 → 拼接 → 时间轴 → 校验产物 |
| `capture.py` | CDP 无损 PNG 取帧，按时间戳展开成固定帧率，补齐末帧到结束 |
| `narration.py` | 剧本解析、逐句 SAPI 配音（多 transport + SHA 校验）、字幕渲染、定格画框 |
| `film.py` | 分镜拼接的独立实现（与 director 内嵌版本同源） |
| `narration_text.py` | 讲解词精简（按"瓶颈 / 工作 / 亮点"三要素压字数）并写回剧本 |
| `gen_diagrams.py` | 配图生成器：架构图 / 痛点图 / 技术流（多状态高亮）/ 纵向流条 / 效益总结 |

## 环境要求

- Python 3.8+，`playwright`（含 Chromium 内核）、`opencv-python`、`Pillow`、`numpy`
- 一个带 H.264 编码器的 ffmpeg（`h264_mf` / `libx264` / `h264_nvenc` 任一）。脚本会自动
  在 PATH 与常见安装位置里找；找不到会退回 VP8 webm 并提示
- Windows 中文语音（SAPI，如 `Microsoft Huihui Desktop`）用于离线配音
- 渲染 SVG→PNG 用 Edge 或 Inkscape（**不要用 Chrome**）

## 典型调用

```bat
python -B record\director.py --list
python -B record\director.py --shots all --narrate          :: 全片录制 + 配音 + 字幕 + 成片
python -B record\director.py --stitch-only <run目录> --narrate  :: 用已有分镜重出成片
python -B record\diagrams\gen.py                              :: 重新生成全部配图 SVG
```

## 适配到新项目时要改的地方

1. `director.py` 顶部的路径常量（平台入口、数据源端入口、剧本路径）；
2. `SHOTS` 镜头表：每镜的标题、目标时长、镜头函数、是否锁定外部时序、开拍前预处理；
3. `GROUPS`（时间轴阶段）与 `RAIL_STAGE`（纵向技术流与镜头的对应）；
4. 配图生成器里的文案与分块——只放文本里已有的实体与数值，不编造。

改动后先跑 `--list` 与单镜，再跑全片；出片前务必执行 SKILL.md 第 4 段的两轮校验闭环。

## 整包 ZIP 转移（给别人用）

**所有路径都是相对的，换机器/换项目不用改脚本里的任何绝对路径。**

```text
scripts/
├─ 各 .py 脚本            全部相对自身定位；项目根靠环境变量或参数指定
├─ tools/                 可选：把 ffmpeg.exe / msedge.exe / inkscape.exe 放这里
└─ assets/font.ttf        可选：想让字幕字体随包走就放这里
```

查找顺序（都是"先本地后系统"，所以 ZIP 带走依赖也能跑）：

| 依赖 | 顺序 |
|---|---|
| ffmpeg | `scripts/tools/ffmpeg.exe` → PATH → 系统安装目录（递归找） |
| SVG 渲染器 | `scripts/tools/msedge.exe` / `inkscape.exe` → 系统 Edge → Inkscape |
| 字幕字体 | `scripts/assets/font.ttf` → 系统微软雅黑 → 项目 `static/font/` → 系统黑体 |
| 浏览器内核 | 环境变量 `PLAYWRIGHT_BROWSERS_PATH` → 默认用户目录 |
| 项目根 | 环境变量 `DEMO_PROJECT_ROOT` → 脚本上两级目录 |

**接收方三步**：

1. 解压整包，`python scripts/doctor.py` 看缺什么（它会直接告诉你缺哪个、放哪里）；
2. 缺的按提示补：Python 包用 pip，浏览器内核用 `python -m playwright install chromium`，
   编解码/渲染器丢进 `scripts/tools/`；
3. 改 `director.py` 顶部的项目路径常量与 `SHOTS` 镜头表（这是唯一必须手改的地方）。

**打包方注意**：打包前跑一次 `doctor.py`，把它的输出一起放进压缩包说明里，接收方一眼就知道
要准备什么；`scripts/tools/` 里放了可执行文件会显著增大压缩包，按需取舍。
