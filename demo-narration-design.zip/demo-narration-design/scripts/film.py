# -*- coding: utf-8 -*-
"""成片拼接：分镜顺序拼接 + 字幕铺轨 + 旁白混音 + 定格画框标注。"""
import subprocess

import narration

DEFAULT_FPS = 25.0


def stitch(clips, dest, fps=DEFAULT_FPS, ffmpeg=None, encoder="h264_mf",
           captions=None, audio=None, annos=None):
    """把分镜按剧本顺序拼成一条成片，丢掉每段开头的无头空白帧。

    ffmpeg 可用时出标准 H.264 mp4（播放器、浏览器、PPT 都认）；
    否则退回 opencv 的 VP8 webm（浏览器能播，但慢且兼容性差）。

    captions: [(t0, t1, RGBA 贴图)]，按成片全局时间轴铺字幕；
    audio:    旁白 wav，作为第二路输入直接混进 mp4（aac）；
    annos:    {分镜序号: [(镜内时刻, 定格秒数, (x,y,w,h), 标签)]}。
              到点后冻住当前帧、压暗并画框，讲解词继续念。
    """
    import cv2
    proc, writer, total, size, skipped = None, None, 0, None, 0
    caps = sorted(captions or [], key=lambda c: c[0])
    cap_idx = 0

    def start_pipeline(w, h):
        nonlocal proc, writer, size
        size = (w, h)
        if ffmpeg:
            cmd = [ffmpeg, "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
                   "-s", "%dx%d" % size, "-r", str(fps), "-i", "-"]
            if audio:
                cmd += ["-i", audio]
            cmd += ["-c:v", encoder, "-b:v", "20M", "-pix_fmt", "yuv420p"]
            if audio:
                cmd += ["-c:a", "aac", "-b:a", "128k", "-shortest"]
            cmd += ["-loglevel", "error", dest]
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        else:
            writer = cv2.VideoWriter(dest, cv2.VideoWriter_fourcc(*"VP80"),
                                     float(fps), size)
            if not writer.isOpened():
                raise RuntimeError("没有可用的视频编码器")

    def emit(frame):
        nonlocal total, cap_idx
        if size is None:
            start_pipeline(frame.shape[1], frame.shape[0])
        if caps:
            now = total / float(fps)
            while cap_idx < len(caps) and now > caps[cap_idx][1]:
                cap_idx += 1
            if cap_idx < len(caps):
                t0, t1, img = caps[cap_idx]
                if t0 <= now <= t1:
                    narration.paste_rgba(frame, img, size[0] / 2.0)
        if proc is not None:
            proc.stdin.write(frame.tobytes())
        else:
            writer.write(frame)
        total += 1

    try:
        for clip_i, path in enumerate(clips):
            pending = sorted((annos or {}).get(clip_i) or [],
                             key=lambda a: a[0])
            local_frames = 0
            active = []
            cap = cv2.VideoCapture(path)
            if not cap.isOpened():
                raise RuntimeError("无法打开分镜：%s" % path)
            first, lead = True, 0
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                if (first and lead < int(float(fps) * 2)
                        and float(frame.std()) < 2.0):
                    lead += 1
                    skipped += 1
                    continue
                first = False
                if size is not None and (frame.shape[1], frame.shape[0]) != size:
                    raise RuntimeError("分镜尺寸不一致，无法拼接：%s" % path)
                local_t = local_frames / float(fps)
                while pending and local_t >= pending[0][0]:
                    item = pending.pop(0)
                    _t, hold, box, label = item[:4]
                    freeze = item[4] if len(item) > 4 else True
                    if freeze:
                        frozen = narration.annotate_frame(frame, box, label)
                        for _ in range(max(1, int(round(hold * float(fps))))):
                            emit(frozen)
                    else:
                        # 静态图段：只叠方框说明，不冻结画面
                        active.append((local_t + hold, box, label))
                if active:
                    active = [a for a in active if a[0] > local_t]
                    if active:
                        frame = narration.annotate_frame(
                            frame, active[0][1], active[0][2], dim=1.0)
                emit(frame)
                local_frames += 1
            cap.release()
        if proc is not None:
            proc.stdin.close()
            rc = proc.wait(timeout=1800)
            if rc != 0:
                raise RuntimeError("ffmpeg 退出码 %s" % rc)
    finally:
        if writer is not None:
            writer.release()
    return total, size, skipped
