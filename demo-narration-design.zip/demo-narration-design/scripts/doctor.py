# -*- coding: utf-8 -*-
"""录制环境自检：确认第三方依赖是否齐备，缺什么就明确说缺什么。

用法：python scripts/doctor.py
"""
import glob
import importlib
import os
import shutil
import subprocess
import sys

OK, BAD, WARN = "[OK]  ", "[缺]  ", "[注意]"

# 便携约定：随 skill 一起 ZIP 转移时，可选的可执行文件放进脚本同级的 tools/
# 目录，脚本优先用它，找不到再退回系统位置——换机器不用改任何路径。
HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(HERE, "tools")


def say(tag, name, detail):
    print("%s %-22s %s" % (tag, name, detail))


def check_python():
    say(OK if sys.version_info >= (3, 8) else BAD, "Python",
        "%d.%d.%d" % sys.version_info[:3])


def check_modules():
    for mod, use in (("playwright", "页面驱动与 CDP 取帧"),
                     ("cv2", "帧处理与视频读写"),
                     ("PIL", "字幕与标注渲染"),
                     ("numpy", "帧与音频运算"),
                     ("docx", "读技术报告 docx（可选）"),
                     ("pptx", "读汇报 pptx（可选）")):
        try:
            importlib.import_module(mod)
            say(OK, mod, use)
        except Exception:
            say(BAD, mod, "%s —— 未安装" % use)


def check_browsers():
    base = (os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
            or os.path.join(os.environ.get("LOCALAPPDATA", ""), "ms-playwright"))
    if os.path.isdir(base):
        names = [d for d in os.listdir(base) if d.startswith("chromium")]
        say(OK if names else BAD, "playwright 内核", ", ".join(names) or "无")
        say(OK if any(d.startswith("ffmpeg") for d in os.listdir(base)) else WARN,
            "playwright 自带 ffmpeg", "仅用于内置录制，转 mp4 需完整 ffmpeg")
    else:
        say(BAD, "playwright 内核", "未安装：python -m playwright install chromium")
    for p in (os.path.join(TOOLS, "msedge.exe"),
              os.path.join(TOOLS, "inkscape.exe"),
              r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
              r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
              r"C:\Program Files\Inkscape\bin\inkscape.exe"):
        if os.path.isfile(p):
            say(OK, "SVG 渲染器", p)
            break
    else:
        say(BAD, "SVG 渲染器",
            "需 Edge 或 Inkscape（不要用 Chrome）；也可把 msedge.exe 放到 %s" % TOOLS)


def has_h264(exe):
    try:
        out = subprocess.run([exe, "-hide_banner", "-encoders"],
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             timeout=30).stdout.decode("utf-8", "replace")
    except Exception:
        return ""
    for enc in ("h264_mf", "libx264", "h264_nvenc", "h264_qsv", "h264_amf"):
        if enc in out:
            return enc
    return ""


def check_ffmpeg():
    cands = [os.path.join(TOOLS, "ffmpeg.exe"),
             os.path.join(TOOLS, "ffmpeg"),
             shutil.which("ffmpeg")]
    # 第三方软件常把完整 ffmpeg 藏在自己的安装目录里，按目录递归找（限量避免过慢）
    for root in (r"C:\Program Files (x86)", r"C:\Program Files",
                 os.environ.get("LOCALAPPDATA", "")):
        if root and os.path.isdir(root):
            cands += glob.glob(os.path.join(root, "**", "ffmpeg.exe"),
                               recursive=True)[:5]
    for exe in [c for c in cands if c and os.path.isfile(c)]:
        enc = has_h264(exe)
        if enc:
            say(OK, "ffmpeg + H.264", "%s (%s)" % (enc, exe))
            return
        say(WARN, "ffmpeg（无 H.264）", exe)
    say(BAD, "ffmpeg + H.264",
        "未找到带 H.264 编码器的 ffmpeg。把 ffmpeg.exe 放到 %s 即可（推荐），"
        "否则只能出 VP8 webm（慢且兼容性差）" % TOOLS)


def check_tts():
    ps = ("Add-Type -AssemblyName System.Speech;"
          "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
          "$s.GetInstalledVoices()|ForEach-Object{$_.VoiceInfo.Name}")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             timeout=60).stdout.decode("utf-8", "replace")
        zh = [l.strip() for l in out.splitlines() if "Chinese" in l or "zh" in l
              or "Huihui" in l or "Kangkang" in l]
        say(OK if zh else BAD, "中文语音(SAPI)", "、".join(zh) or "未找到中文语音")
    except Exception as exc:
        say(BAD, "中文语音(SAPI)", str(exc))


if __name__ == "__main__":
    check_python()
    check_modules()
    check_browsers()
    check_ffmpeg()
    check_tts()
