#!/usr/bin/env python3
"""裁掉图片四周的纯色边（默认白边），用于修复导出图的白边问题。

用法:
    python trim_white.py figure.png                 # 覆盖写回，保留另存备份
    python trim_white.py figure.png --pad 4         # 裁剪后四周留 4px
    python trim_white.py figure.png --out trimmed.png
    python trim_white.py figure.png --color FFFFFF --tolerance 6

说明：只裁"整行/整列都是背景色"的边，不会损伤内容；若图片本身没有白边则原样另存。
"""

import argparse
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:  # pragma: no cover
    print("需要 Pillow：pip install pillow", file=sys.stderr)
    sys.exit(2)


def parse_color(text):
    text = text.lstrip("#")
    if len(text) != 6:
        raise ValueError("颜色需为 6 位十六进制，如 FFFFFF")
    return tuple(int(text[i:i + 2], 16) for i in (0, 2, 4))


def bbox_of_content(image, color, tolerance):
    """返回内容包围盒；某条边整条都是背景色才裁。"""
    rgb = image.convert("RGB")
    width, height = rgb.size
    pixels = rgb.load()

    def is_bg(x, y):
        r, g, b = pixels[x, y]
        return abs(r - color[0]) <= tolerance and abs(g - color[1]) <= tolerance and abs(b - color[2]) <= tolerance

    left, top, right, bottom = 0, 0, width - 1, height - 1
    while left < right and all(is_bg(left, y) for y in range(height)):
        left += 1
    while right > left and all(is_bg(right, y) for y in range(height)):
        right -= 1
    while top < bottom and all(is_bg(x, top) for x in range(width)):
        top += 1
    while bottom > top and all(is_bg(x, bottom) for x in range(width)):
        bottom -= 1
    return left, top, right, bottom


def main():
    parser = argparse.ArgumentParser(description="裁掉图片四周的纯色边")
    parser.add_argument("image", help="图片路径（png/jpg）")
    parser.add_argument("--color", default="FFFFFF", help="背景色，默认 FFFFFF")
    parser.add_argument("--tolerance", type=int, default=6, help="颜色容差，默认 6")
    parser.add_argument("--pad", type=int, default=0, help="裁剪后四周保留的像素，默认 0")
    parser.add_argument("--out", help="输出路径，默认在原图旁另存 *_trimmed.png")
    args = parser.parse_args()

    path = Path(args.image)
    if not path.is_file():
        print(f"找不到图片：{path}", file=sys.stderr)
        return 2

    with Image.open(path) as image:
        original = image.size
        left, top, right, bottom = bbox_of_content(image, parse_color(args.color), args.tolerance)
        left = max(0, left - args.pad)
        top = max(0, top - args.pad)
        right = min(image.width - 1, right + args.pad)
        bottom = min(image.height - 1, bottom + args.pad)
        if (left, top, right, bottom) == (0, 0, image.width - 1, image.height - 1):
            print("未检测到可裁剪的边，原样输出。")
        trimmed = image.crop((left, top, right + 1, bottom + 1))
        out = Path(args.out) if args.out else path.with_name(path.stem + "_trimmed.png")
        trimmed.save(out)

    print(f"{original[0]}×{original[1]} → {trimmed.width}×{trimmed.height}　输出 {out.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
