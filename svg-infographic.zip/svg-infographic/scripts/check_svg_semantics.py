"""素材语义校验：一材多用（同页语义冲突）与同义不同材（跨页不一致）。

要求 SVG 的素材容器上标注：
    data-slot="material" data-semantic="<语义键>" data-asset="<素材 id>"

判定：
  1. 同一张图内，同一 asset 不许服务两个不同 semantic（一材多用）；
  2. 多张图之间，同一 semantic 必须绑定同一 asset（同义同材）；
  3. 素材容器缺 data-semantic / data-asset 视为未登记（无法校验，报提示）。

用法：python check_svg_semantics.py *.svg
"""

import glob
import sys
from collections import defaultdict
from pathlib import Path

from lxml import etree

SVG = "http://www.w3.org/2000/svg"


def main():
    files = []
    for pattern in sys.argv[1:]:
        matched = [Path(item) for item in glob.glob(pattern)]
        files += matched if matched else [Path(pattern)]
    if not files:
        print(__doc__)
        return 2
    per_file = {}
    semantic_to_asset = defaultdict(set)
    unmarked = 0
    for path in files:
        if not path.is_file():
            continue
        root = etree.parse(str(path)).getroot()
        pairs = []
        for node in root.findall(f".//{{{SVG}}}rect"):
            if node.get("data-slot") != "material":
                continue
            semantic = node.get("data-semantic")
            asset = node.get("data-asset")
            if not semantic or not asset:
                unmarked += 1
                continue
            pairs.append((semantic, asset))
            semantic_to_asset[semantic].add(asset)
        per_file[path.name] = pairs

    issues = []
    for name, pairs in per_file.items():
        by_asset = defaultdict(set)
        for semantic, asset in pairs:
            by_asset[asset].add(semantic)
        for asset, semantics in by_asset.items():
            if len(semantics) > 1:
                issues.append(f"{name}：素材 {asset} 一材多用（{ '、'.join(sorted(semantics)) }）")
        seen = set()
        for semantic, asset in pairs:
            if (semantic, asset) in seen:
                continue
            seen.add((semantic, asset))
    for semantic, assets in semantic_to_asset.items():
        if len(assets) > 1:
            issues.append(f"同义不同材：{semantic} 绑定了 {sorted(assets)}")

    registered = sum(len(pairs) for pairs in per_file.values())
    print(f"检查 {len(per_file)} 张图，登记素材 {registered} 处，涉及语义 {len(semantic_to_asset)} 个")
    for semantic in sorted(semantic_to_asset):
        print(f"  {semantic:<22} → {sorted(semantic_to_asset[semantic])}")
    if unmarked:
        print(f"  提示：{unmarked} 处素材位未登记 data-semantic / data-asset（无法校验）")
    print(f"问题 {len(issues)} 项")
    for item in issues[:12]:
        print("  -", item)
    return 0 if not issues else 1


if __name__ == "__main__":
    sys.exit(main())
