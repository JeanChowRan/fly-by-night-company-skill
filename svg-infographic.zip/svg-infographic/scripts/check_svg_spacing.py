"""间距后校验（自底向上逐层）：同级相邻本体的空隙、底层本体到上层容器四周的边距。

规则（用户规范）：
  A. 同级相邻本体之间的空隙 ≤ 0.75 × 该本体自身的宽（横向）/高（纵向）；
     若两者之间有"带文字的连线"，阈值放宽到 1.5 ×。
  B. 自底向上逐层检查：底层本体并集在各上层容器内的上/下/左/右边距，
     不得超过 0.75 × 对应方向的底层本体尺寸（高或宽）。
     - 若该边距内上层容器有文字（标题、说明）→ 属"有内容边距"，一般合规；
     - 若没有文字且容器需要与同层对齐而无法改尺寸 → 必须用素材图片（优先无背景，
       有背景则边缘虚化）、关键词说明文本或纹饰填充；
     - 否则 → 缩小该上层容器。

用法：python check_svg_spacing.py "inc*.svg" [--ratio 0.75] [--labeled-ratio 1.5]
"""

import argparse
import glob
import sys
from collections import defaultdict
from pathlib import Path

from lxml import etree

NS = "http://www.w3.org/2000/svg"


def box(node):
    try:
        x, y = float(node.get("x", 0)), float(node.get("y", 0))
        return [x, y, x + float(node.get("width", 0)), y + float(node.get("height", 0))]
    except (TypeError, ValueError):
        return None


def area(b):
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def text_boxes(root):
    out = []
    for node in root.findall(f".//{{{NS}}}text"):
        value = "".join(node.itertext()).strip()
        if not value:
            continue
        try:
            size = float(node.get("font-size", 16))
            x, y = float(node.get("x", 0)), float(node.get("y", 0))
        except (TypeError, ValueError):
            continue
        anchor = node.get("text-anchor", "start")
        width = sum(0.28 if c.isspace() else (1.0 if ord(c) > 0x2E80 else 0.5) for c in value) * size
        if anchor == "middle":
            x -= width / 2
        elif anchor == "end":
            x -= width
        out.append((value, [x, y - size * 0.92, x + width, y + size * 0.36]))
    return out


def check(path, ratio, labeled_ratio):
    root = etree.parse(str(path)).getroot()
    texts = text_boxes(root)
    cards = []
    for node in root.findall(f".//{{{NS}}}rect"):
        b = box(node)
        if not b:
            continue
        if node.get("data-slot") in ("card", "material"):      # 只把登记过的本体当"同级本体"
            cards.append((node.get("data-slot") or "shape", b))
    cards.sort(key=lambda item: area(item[1]), reverse=True)

    def parent_card(box):
        """返回包含该块的最小 card 矩形（用于判断两块是否属于同一父容器）。"""
        for kind, outer in reversed(cards):
            if kind != "card":
                continue
            if box is outer:
                continue
            if (box[0] >= outer[0] - 1 and box[1] >= outer[1] - 1
                    and box[2] <= outer[2] + 1 and box[3] <= outer[3] + 1):
                return tuple(round(v) for v in outer)
        return None
    issues = []

    # A. 同级"最近邻"空隙：只在同一行/同一列的相邻块之间判定，避免把远距离块当邻居
    for index, (kind_a, a) in enumerate(cards):
        neighbours = []
        for kind_b, b in cards:
            if b is a:
                continue
            # 只有"同为卡片"或"同属一个父卡片"的块才算同级邻居，避免跨列误判
            same_level = (kind_a == kind_b == "card") or (parent_card(a) is not None
                                                          and parent_card(a) == parent_card(b))
            if not same_level:
                continue
            v_overlap = min(a[3], b[3]) - max(a[1], b[1])
            h_overlap = min(a[2], b[2]) - max(a[0], b[0])
            if v_overlap > 0.5 * min(a[3] - a[1], b[3] - b[1]) and b[0] >= a[2] - 1:
                neighbours.append(("右", b[0] - a[2], a[2] - a[0], b))
            if h_overlap > 0.5 * min(a[2] - a[0], b[2] - b[0]) and b[1] >= a[3] - 1:
                neighbours.append(("下", b[1] - a[3], a[3] - a[1], b))
        for direction, gap, ref, other in neighbours:
            # 该方向上若还夹着第三个块，则两块并非相邻，跳过（避免"第1列 vs 第3列"这类误判）
            blocked = False
            for kind_c, c in cards:
                if c is a or c is other:
                    continue
                v_ov = min(a[3], c[3]) - max(a[1], c[1])
                h_ov = min(a[2], c[2]) - max(a[0], c[0])
                if direction == "右" and v_ov > 0.5 * min(a[3] - a[1], c[3] - c[1]) \
                        and c[0] >= a[2] - 1 and c[2] <= other[0] + 1:
                    blocked = True
                    break
                if direction == "下" and h_ov > 0.5 * min(a[2] - a[0], c[2] - c[0]) \
                        and c[1] >= a[3] - 1 and c[3] <= other[1] + 1:
                    blocked = True
                    break
            if blocked:
                continue
            limit = ratio * ref
            if gap > limit:
                issues.append(f"最近邻{direction}向空隙 {round(gap)} > 0.75×{round(ref)}")

    # B. 自底向上：每个容器内的子本体并集与其四周的边距
    for kind, outer in cards:
        inner = [b for _, b in cards if b is not outer and
                 b[0] >= outer[0] - 1 and b[1] >= outer[1] - 1 and b[2] <= outer[2] + 1 and b[3] <= outer[3] + 1]
        if not inner:
            continue
        left = min(b[0] for b in inner) - outer[0]
        right = outer[2] - max(b[2] for b in inner)
        top = min(b[1] for b in inner) - outer[1]
        bottom = outer[3] - max(b[3] for b in inner)
        ref_w = min(b[2] - b[0] for b in inner)
        ref_h = min(b[3] - b[1] for b in inner)
        for side, margin, ref in (("左", left, ref_w), ("右", right, ref_w),
                                  ("上", top, ref_h), ("下", bottom, ref_h)):
            if margin <= ratio * ref:
                continue
            strip = {"左": [outer[0], outer[1], outer[0] + margin, outer[3]],
                     "右": [outer[2] - margin, outer[1], outer[2], outer[3]],
                     "上": [outer[0], outer[1], outer[2], outer[1] + margin],
                     "下": [outer[0], outer[3] - margin, outer[2], outer[3]]}[side]
            has_text = any(t[1][0] < strip[2] and t[1][2] > strip[0]
                           and t[1][1] < strip[3] and t[1][3] > strip[1] for t in texts)
            if has_text:
                issues.append(f"{side}边距 {round(margin)} > 0.75×{round(ref)}，但边距内有文字（需确认是否合规）")
            else:
                issues.append(f"{side}边距 {round(margin)} > 0.75×{round(ref)} 且无内容 → 填素材/关键词/纹饰，或缩小容器")
    return issues


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+")
    parser.add_argument("--ratio", type=float, default=0.75)
    parser.add_argument("--labeled-ratio", type=float, default=1.5)
    args = parser.parse_args()
    files = []
    for pattern in args.files:
        matched = [Path(p) for p in glob.glob(pattern)]
        files += matched if matched else [Path(pattern)]
    total = 0
    for path in files:
        if not path.is_file():
            continue
        issues = check(path, args.ratio, args.labeled_ratio)
        total += len(issues)
        print(f"{path.name}: {'OK' if not issues else str(len(issues)) + ' 项间距问题'}")
        for item in issues[:6]:
            print("   -", item)
    print(f"\n合计 {total} 项")
    return 0 if total == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
