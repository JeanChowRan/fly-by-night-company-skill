"""批量把 SVG 渲染成 PNG（Chromium 内核浏览器 headless / Inkscape），并做"内容过稀"自检。

用法：python render_svg_batch.py <目录> [--scale 2] [--pattern inc*.svg]
渲染器查找：环境变量 SVG_RENDERER > PATH（msedge / inkscape / chromium 等）> 各系统常见安装位置。
          按用户规范不得回退到 Google Chrome；找不到渲染器会直接报错。
输出：同目录下的 <同名>.png；任一图墨迹覆盖 <10% 会打印告警（疑似渲染失败/空白）。
"""

import argparse
import glob
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image

# 渲染器优先级：Microsoft Edge（Chromium 内核）→ 其他 Chromium 内核浏览器 → Inkscape。
# **禁止使用 Google Chrome 及任何 Google 相关服务**（用户规范）：不得回退到 chrome.exe；
# 找不到渲染器时直接报错，不私自换方案。
#
# 查找顺序（不写死本机路径，换机器可直接用）：
#   1) 环境变量 SVG_RENDERER 指定的可执行文件；
#   2) PATH 中的常用命令名；
#   3) 各系统的常见安装位置。
CANDIDATE_COMMANDS = [
    "msedge", "msedge.exe",                                  # Microsoft Edge
    "inkscape", "inkscape.exe",                              # Inkscape
    "chromium", "chromium-browser", "chrome-headless-shell",  # 非 Google 的 Chromium 构建
]

CANDIDATE_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Inkscape\bin\inkscape.exe",
    "/usr/bin/inkscape",
    "/usr/local/bin/inkscape",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/Applications/Inkscape.app/Contents/MacOS/inkscape",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
]

BANNED = ("chrome.exe", "google-chrome", "google-chrome-stable", "/google/chrome")


def _banned(path):
    lowered = str(path).lower()
    return any(token in lowered for token in BANNED)


def find_renderer():
    override = os.environ.get("SVG_RENDERER")
    if override:
        if Path(override).is_file() and not _banned(override):
            return override
        raise SystemExit(
            "环境变量 SVG_RENDERER 指向的渲染器不可用（不存在或是 Google Chrome）：%s\n"
            "请改为 Microsoft Edge / Inkscape 等非 Google 渲染器的可执行文件路径。" % override)
    for name in CANDIDATE_COMMANDS:
        found = shutil.which(name)
        if found and not _banned(found):
            return found
    for path in CANDIDATE_PATHS:
        if Path(path).is_file() and not _banned(path):
            return path
    raise SystemExit(
        "未找到可用渲染器。按用户规范不得回退到 Google Chrome；请先安装 Microsoft Edge 或 Inkscape，\n"
        "或用环境变量 SVG_RENDERER 指定渲染器可执行文件的绝对路径。")


def render(path, scale):
    renderer = find_renderer()
    path = path.resolve()                       # 渲染器只认绝对路径，否则产物会写到别处
    head = path.read_text(encoding="utf-8")[:600]
    match = re.search(r'width="(\d+)" height="(\d+)"', head)
    if not match:
        print(f"  {path.name}: SVG 头部未找到 width/height，跳过")
        return None
    cw, ch = int(match.group(1)), int(match.group(2))
    png = path.with_suffix(".png").resolve()
    if png.is_file():
        png.unlink()
    if "inkscape" in Path(renderer).name.lower():
        # Inkscape 用自己的导出参数，不接受 Chromium 的 headless 参数
        try:
            subprocess.run([renderer, "--export-type=png", f"--export-filename={png}",
                            f"--export-dpi={96 * scale}", str(path)],
                           check=False, capture_output=True, timeout=180)
        except subprocess.TimeoutExpired:
            pass
    else:
        # Chromium 内核（Edge / Chromium）：headless 截图
        html = path.with_name(f"_r_{path.stem}.html")          # 与 SVG 同目录，避免加载不到
        html.write_text('<!doctype html><html><head><meta charset="utf-8"><style>'
                        f"html,body{{margin:0;padding:0;background:#fff}}"
                        f"img{{display:block;width:{cw * scale}px;height:{ch * scale}px}}"
                        f'</style></head><body><img src="{path.name}"></body></html>', encoding="utf-8")
        profile = path.with_name(f"_rp_{path.stem}")
        try:
            subprocess.run([renderer, "--headless=new", "--no-sandbox", "--disable-gpu", "--hide-scrollbars",
                            "--default-background-color=FFFFFFFF", f"--user-data-dir={profile}",
                            f"--screenshot={png}", f"--window-size={cw * scale},{ch * scale}",
                            f"file:///{html.as_posix()}"], check=False, capture_output=True, timeout=180)
        except subprocess.TimeoutExpired:
            pass
        shutil.rmtree(profile, ignore_errors=True)
        html.unlink(missing_ok=True)
    if not png.is_file():
        return None
    with Image.open(png) as image:
        array = np.asarray(image.convert("L"))
        return float((array < 246).mean())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("folder")
    parser.add_argument("--scale", type=int, default=2)
    parser.add_argument("--pattern", default="*.svg")
    parser.add_argument("--min-ink", type=float, default=0.10,
                        help="墨迹覆盖下限（文档配图线框 0.015，汇报卡片图 0.10）")
    args = parser.parse_args()
    files = [Path(p) for p in glob.glob(str(Path(args.folder) / args.pattern))]
    thin = []
    for path in files:
        coverage = render(path, args.scale)
        if coverage is None:
            print(f"  {path.name}: 渲染失败")
        elif coverage < args.min_ink:
            thin.append((path.name, round(coverage, 3)))
    print(f"渲染 {len(files)} 张；内容过稀 {len(thin)} 张 {thin}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
