"""图形后校验：文字溢出容器、文字被素材/图形遮挡、素材位是空占位、元素越界画布。

与 check_svg.py 的分工：check_svg.py 管契约（字体/外链/引用/比例），
本脚本管**排版几何**——判断"框里到底装得下吗、有没有互相压住、素材位是不是空的"。

用法：
    python check_svg_layout.py figure.svg [--pad 6]
    python check_svg_layout.py *.svg            # 批量

判定口径：
  1. 文字溢出：按 CJK=1.0em / ASCII=0.5em / 空格=0.28em 估宽，字高 1.28em；
     文字包围盒必须落在"最近的外层容器矩形"内（容差 pad）。
  2. 素材遮挡：带 data-slot="material|media|visual" 的矩形内必须被 <image> 或
     <use> 覆盖 ≥80% 面积，否则判为"空占位"；文字包围盒与 <image>/素材矩形重叠 ≥15%
     判为"文字被素材遮挡"。
  3. 越界：所有元素的包围盒必须在画布内（容差 pad）。
"""

import argparse
import glob
import re
import sys
from pathlib import Path

from lxml import etree

SVG = "http://www.w3.org/2000/svg"
NS = {"s": SVG}
UNIT = {"cjk": 1.0, "ascii": 0.5, "space": 0.28}
EDGE_MIN = 10.0        # 容器四边最小留白（文档/汇报通用下限；底边最容易失守）


def text_width(value, size):
    total = 0.0
    for char in value:
        if char.isspace():
            total += UNIT["space"]
        elif ord(char) > 0x2E80:
            total += UNIT["cjk"]
        else:
            total += UNIT["ascii"]
    return total * size


def box(x, y, w, h):
    return [float(x), float(y), float(x) + float(w), float(y) + float(h)]


def overlap(a, b):
    width = min(a[2], b[2]) - max(a[0], b[0])
    height = min(a[3], b[3]) - max(a[1], b[1])
    return max(0.0, width) * max(0.0, height)


def area(a):
    return max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])


def contains(outer, inner, pad=0.0):
    return (inner[0] >= outer[0] - pad and inner[1] >= outer[1] - pad
            and inner[2] <= outer[2] + pad and inner[3] <= outer[3] + pad)


def nodes(root, tag):
    return root.findall(f".//{{{SVG}}}{tag}")


def rect_box(node):
    try:
        return box(float(node.get("x", 0)), float(node.get("y", 0)),
                   float(node.get("width", 0)), float(node.get("height", 0)))
    except (TypeError, ValueError):
        return None


def text_box(node):
    value = "".join(node.itertext()).strip()
    if not value:
        return None, value
    size = float(node.get("font-size", 16))
    x, y = float(node.get("x", 0)), float(node.get("y", 0))
    width = text_width(value, size)
    anchor = node.get("text-anchor", "start")
    if anchor == "middle":
        x -= width / 2
    elif anchor == "end":
        x -= width
    return box(x, y - size * 0.92, width, size * 1.28), value


def check_file(path, pad=6.0, talk=False):
    tree = etree.parse(str(path))
    root = tree.getroot()
    canvas = box(0, 0, float(root.get("width", 0)), float(root.get("height", 0)))
    issues = []
    edge_issues = []

    containers = [(rect_box(r), r.get("data-slot") or "card") for r in nodes(root, "rect")]
    containers = [(b, kind) for b, kind in containers if b and b[2] - b[0] > 40 and b[3] - b[1] > 30]
    containers.sort(key=lambda item: area(item[0]))

    texts = []
    for node in nodes(root, "text"):
        b, value = text_box(node)
        if not b:
            continue
        texts.append((b, value))
        if not contains(canvas, b, pad):
            issues.append(f"越界文字：{value[:16]} → {[round(v) for v in b]}")
        center = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
        holder = None
        for candidate, _ in containers:
            if (candidate[0] - pad <= center[0] <= candidate[2] + pad
                    and candidate[1] - pad <= center[1] <= candidate[3] + pad):
                holder = candidate          # containers 已按面积升序，取最小者
                break
        if holder and not contains(holder, b, pad):
            issues.append(f"文字溢出容器：{value[:18]} 超出 {[round(v) for v in holder]} "
                          f"（文字 {[round(v) for v in b]}）")
        # 四边留白（尤其底边）：文字不得贴边、压底边
        if holder:
            gaps = {"左": b[0] - holder[0], "上": b[1] - holder[1],
                    "右": holder[2] - b[2], "下": holder[3] - b[3]}
            worst = min(gaps.values())
            if worst < EDGE_MIN:
                side = min(gaps, key=gaps.get)
                edge_issues.append(
                    f"文字贴边：\"{value[:14]}\" {side}边留白 {worst:.1f} < {EDGE_MIN:g}"
                    f"（容器 {[round(v) for v in holder]}）")

    materials = []
    for node in nodes(root, "image"):
        b = rect_box(node)
        if b:
            materials.append(b)
    for node in nodes(root, "use"):
        try:
            b = box(float(node.get("x", 0)), float(node.get("y", 0)),
                    float(node.get("width", 0)), float(node.get("height", 0)))
        except (TypeError, ValueError):
            continue
        materials.append(b)

    slot_nodes = [r for r in nodes(root, "rect") if r.get("data-slot") == "material"]
    slots = [rect_box(r) for r in slot_nodes]
    for node, slot in zip(slot_nodes, slots):
        if not slot:
            continue
        strong = chart_like = labels = 0
        for child in node.getparent().iter():
            if child is node or child.tag == f"{{{SVG}}}defs":
                continue
            b = None
            if child.tag in (f"{{{SVG}}}rect", f"{{{SVG}}}image", f"{{{SVG}}}use"):
                b = rect_box(child) if child.tag != f"{{{SVG}}}use" else None
                if b is None and child.tag == f"{{{SVG}}}use":
                    try:
                        b = box(float(child.get("x", 0)), float(child.get("y", 0)),
                                float(child.get("width", 0)), float(child.get("height", 0)))
                    except (TypeError, ValueError):
                        b = None
            if b is None:
                continue
            center = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
            inside = (slot[0] - 2 <= center[0] <= slot[2] + 2 and slot[1] - 2 <= center[1] <= slot[3] + 2)
            if not inside:
                continue
            if child.tag in (f"{{{SVG}}}image", f"{{{SVG}}}use"):
                strong += 1
            elif child.tag == f"{{{SVG}}}rect" and area(b) < area(slot) * 0.95:
                chart_like += 1
        # 真图表由 <path>/<circle> 构成，这里额外统计
        for child in node.getparent().iter():
            if child.tag not in (f"{{{SVG}}}path", f"{{{SVG}}}circle", f"{{{SVG}}}line", f"{{{SVG}}}polyline"):
                continue
            d = child.get("d") or ""
            nums = [float(v) for v in re.findall(r"-?\d+\.?\d*", d)][:2]
            if len(nums) < 2:
                continue
            if slot[0] - 4 <= nums[0] <= slot[2] + 4 and slot[1] - 4 <= nums[1] <= slot[3] + 4:
                chart_like += 1
        for child in node.getparent().iter():
            if child.tag != f"{{{SVG}}}text":
                continue
            tb, _ = text_box(child)
            if tb and overlap(tb, slot) > 0.5 * area(tb):
                labels += 1
        if strong == 0 and chart_like < 3:
            issues.append(f"素材位是空占位：{[round(v) for v in slot]}（图片/图表元素 "
                          f"{strong} 个、图形元素 {chart_like} 个、标注 {labels} 个；需图片或 ≥3 个图形元素）")
        elif strong == 0 and labels == 0:
            issues.append(f"素材位缺标注：{[round(v) for v in slot]}（纯图形无任何文字，读不懂在讲什么）")

    # 内部词汇泄漏（图内不得出现工艺/内部术语）
    internal = ["本地素材", "语义图元", "素材库", "SVG 库", "SVG库", "迷你图", "占位", "图元",
                "本体", "缩略", "详细表示", "关键度", "重点度", "示意图", "本图"]
    for _tb, value in texts:
        for word in internal:
            if word in value:
                issues.append(f"内部词汇：\"{word}\" 出现在图内文字 \"{value[:16]}\"")
                break

    for tb, value in texts:
        for m in materials:
            ratio = overlap(tb, m) / max(1e-6, area(tb))
            if ratio > 0.15:
                issues.append(f"文字被素材遮挡：{value[:16]} 与素材 {[round(v) for v in m]} 重叠 "
                              f"{ratio * 100:.0f}%")
                break

    # 背景必须包含其承载的元素（并留边距）：容器内元素的包围盒不得超出容器
    for node in nodes(root, "rect"):
        if node.get("data-slot") not in ("card", "material", "background"):
            continue
        outer = rect_box(node)
        if not outer or area(outer) <= 0:
            continue
        for child in node.getparent().iter():
            if child is node:
                continue
            tag = child.tag.split("}")[-1]
            if tag in ("rect", "image"):
                cb = rect_box(child)
            elif tag == "use":
                try:
                    cb = box(float(child.get("x", 0)), float(child.get("y", 0)),
                             float(child.get("width", 0)), float(child.get("height", 0)))
                except (TypeError, ValueError):
                    cb = None
            else:
                continue
            if cb is None or area(cb) <= 0 or area(cb) >= area(outer) * 0.995:
                continue
            center = ((cb[0] + cb[2]) / 2, (cb[1] + cb[3]) / 2)
            if not (outer[0] <= center[0] <= outer[2] and outer[1] <= center[1] <= outer[3]):
                continue
            if not contains(outer, cb, pad):
                issues.append(
                    f"背景未包住承载元素：{tag}{[round(v) for v in cb]} 超出容器 "
                    f"{[round(v) for v in outer]}（需留 ≥{pad:g} 边距）")

    if talk:
        for node in nodes(root, "rect"):
            if node.get("data-slot") == "card":
                b = rect_box(node)
                if b:
                    print(f"    卡片 {[round(v) for v in b]} 内文字 {sum(1 for t, _ in texts if contains(b, t, 0))} 处")
    return issues + edge_issues


def repair(path, pad=6.0, min_size=13.0):
    """自动处理文字溢出：按容器宽度等比缩小字号，仍放不下就截断加省略号。"""
    tree = etree.parse(str(path))
    root = tree.getroot()
    containers = []
    for node in root.findall(f".//{{{SVG}}}rect"):
        try:
            b = box(float(node.get("x", 0)), float(node.get("y", 0)),
                    float(node.get("width", 0)), float(node.get("height", 0)))
        except (TypeError, ValueError):
            continue
        if b[2] - b[0] > 40 and b[3] - b[1] > 30:
            containers.append(b)
    containers.sort(key=area)
    fixed = 0
    for node in root.findall(f".//{{{SVG}}}text"):
        value = "".join(node.itertext()).strip()
        if not value:
            continue
        size = float(node.get("font-size", 16))
        tb, _ = text_box(node)
        if tb is None:
            continue
        center = ((tb[0] + tb[2]) / 2, (tb[1] + tb[3]) / 2)
        holder = None
        for candidate in containers:
            if (candidate[0] - pad <= center[0] <= candidate[2] + pad
                    and candidate[1] - pad <= center[1] <= candidate[3] + pad):
                holder = candidate
                break
        if holder is None or contains(holder, tb, pad):
            continue
        available = (holder[2] - holder[0]) - 2 * pad
        available_h = (holder[3] - holder[1]) - 2 * pad
        width_now = text_width(value, size)
        scale = available / max(1.0, width_now)
        new_size = min(size, max(min_size, size * scale))       # 只缩不放
        while new_size > min_size and (text_width(value, new_size) > available
                                       or new_size * 1.28 > available_h):
            new_size -= 0.5
        if text_width(value, new_size) > available:
            keep = max(2, int(len(value) * available / max(1.0, text_width(value, new_size))) - 1)
            value = value[:keep] + "…"
        node.set("font-size", f"{new_size:g}")
        # 垂直夹紧：把基线收进容器内
        y = float(node.get("y", 0))
        top = y - new_size * 0.92
        bottom = y + new_size * 0.36
        if top < holder[1] + pad:
            y += (holder[1] + pad) - top
        bottom = y + new_size * 0.36
        if bottom > holder[3] - pad:
            y -= bottom - (holder[3] - pad)
        node.set("y", f"{y:g}")
        # 水平夹紧：把整行收进容器内（按 text-anchor 处理）
        width_now = text_width(value, new_size)
        anchor = node.get("text-anchor", "start")
        x = float(node.get("x", 0))
        left_edge = x if anchor == "start" else (x - width_now / 2 if anchor == "middle" else x - width_now)
        right_edge = left_edge + width_now
        if right_edge > holder[2] - pad:
            x -= right_edge - (holder[2] - pad)
        elif left_edge < holder[0] + pad:
            x += (holder[0] + pad) - left_edge
        node.set("x", f"{x:g}")
        for child in list(node):
            node.remove(child)
        node.text = value
        fixed += 1
    if fixed:
        tree.write(str(path), xml_declaration=False, encoding="utf-8")
    return fixed


def expand(patterns):
    files = []
    for pattern in patterns:
        matched = [Path(p) for p in glob.glob(pattern)]
        files += matched if matched else [Path(pattern)]
    return [path for path in files if path.is_file()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+")
    parser.add_argument("--pad", type=float, default=6.0)
    parser.add_argument("--talk", action="store_true")
    parser.add_argument("--fix", action="store_true", help="自动缩小/截断溢出文字")
    args = parser.parse_args()
    files = expand(args.files)
    if args.fix:
        total_fixed = 0
        for path in files:
            total_fixed += repair(path, args.pad)
        print(f"自动处理 {total_fixed} 处溢出文字")
    total = 0
    for path in files:
        issues = check_file(path, args.pad, args.talk)
        total += len(issues)
        flag = "OK" if not issues else f"{len(issues)} 项待修"
        print(f"{path.name}: {flag}")
        for item in issues[:12]:
            print(f"  - {item}")
    print(f"\n检查 {len(files)} 张，合计待修 {total} 项")
    return 0 if total == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
