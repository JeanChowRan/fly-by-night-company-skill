#!/usr/bin/env python3
"""把下载到本地的素材图转成可内联的 data URI 或 <image> 片段。

用法示例:
    # 输出 data URI（背景层用，降到 20% 透明度并羽化）
    python inline_image.py photo.jpg --max-width 1200 --x 0 --y 0 --w 1200 --h 1600 \
        --opacity 0.2 --mask fade-y-mask --mode jpeg

    # 前景贴图：自动裁剪透明边、限制最大宽度、输出 <image> 片段
    python inline_image.py icon.png --trim-alpha --max-width 600 --x 120 --y 320 --w 300 --h 200

    # 只拿 data URI 字符串
    python inline_image.py icon.png --output data-uri

说明：脚本只读取本地文件并输出文本，不联网、不写文件（除非显式给 --outfile）。
最终 SVG 必须内联，禁止出现任何 http/https 链接。
"""

import argparse
import base64
import io
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:  # pragma: no cover
    print("需要 Pillow：pip install pillow", file=sys.stderr)
    sys.exit(2)


def trim_alpha(image, padding=1):
    """按 alpha 通道裁掉透明留白；无 alpha 时返回原图。"""
    if image.mode not in ("RGBA", "LA"):
        return image
    bbox = image.getchannel("A").getbbox()
    if not bbox:
        return image
    left, top, right, bottom = bbox
    left = max(0, left - padding)
    top = max(0, top - padding)
    right = min(image.width, right + padding)
    bottom = min(image.height, bottom + padding)
    return image.crop((left, top, right, bottom))


def trim_white(image, tolerance=6, padding=1):
    """按"接近纯白"裁掉白边（下载来的白底图常用）。"""
    rgb = image.convert("RGB")
    pixels = rgb.load()
    width, height = rgb.size

    def is_blank(x, y):
        r, g, b = pixels[x, y]
        return r >= 255 - tolerance and g >= 255 - tolerance and b >= 255 - tolerance

    left, top, right, bottom = width, height, 0, 0
    found = False
    for y in range(height):
        for x in range(width):
            if not is_blank(x, y):
                found = True
                left = min(left, x)
                right = max(right, x + 1)
                top = min(top, y)
                bottom = max(bottom, y + 1)
    if not found:
        return image
    left = max(0, left - padding)
    top = max(0, top - padding)
    right = min(width, right + padding)
    bottom = min(height, bottom + padding)
    return image.crop((left, top, right, bottom))


def encode(image, mode):
    buffer = io.BytesIO()
    if mode == "jpeg":
        if image.mode in ("RGBA", "LA", "P"):
            flat = Image.new("RGB", image.size, (255, 255, 255))
            rgba = image.convert("RGBA")
            flat.paste(rgba, mask=rgba.getchannel("A"))
            image = flat
        image.save(buffer, format="JPEG", quality=82, optimize=True)
        mime = "image/jpeg"
    else:
        if image.mode not in ("RGBA", "LA", "P"):
            image = image.convert("RGBA")
        image.save(buffer, format="PNG", optimize=True)
        mime = "image/png"
    payload = base64.b64encode(buffer.getvalue()).decode("ascii")
    return mime, payload


def main():
    parser = argparse.ArgumentParser(description="把本地素材图转成内联 data URI 或 <image> 片段")
    parser.add_argument("image", help="本地图片路径（png/jpg/webp/gif 等）")
    parser.add_argument("--max-width", type=int, default=1600, help="最大宽度，超出则等比缩小（默认 1600）")
    parser.add_argument("--trim-alpha", action="store_true", help="按 alpha 通道裁掉透明留白")
    parser.add_argument("--trim-white", action="store_true", help="裁掉接近纯白的边（白底图用）")
    parser.add_argument("--mode", choices=["png", "jpeg"], default="png", help="输出编码格式；背景层照片可用 jpeg")
    parser.add_argument("--max-kb", type=float, default=0, help="超过该大小（KB）时自动降采样重编码一次")
    parser.add_argument("--x", default="0", help="<image> 的 x")
    parser.add_argument("--y", default="0", help="<image> 的 y")
    parser.add_argument("--w", help="<image> 的 width，缺省用图片实际宽度")
    parser.add_argument("--h", help="<image> 的 height，缺省用图片实际高度")
    parser.add_argument("--opacity", help="背景层建议 0.15–0.25（默认 0.2）")
    parser.add_argument("--mask", help="羽化蒙版 id，如 fade-mask / fade-x-mask / fade-y-mask")
    parser.add_argument("--slice", action="store_true", help="加 preserveAspectRatio=\"xMidYMid slice\"（铺满背景用）")
    parser.add_argument("--output", choices=["snippet", "data-uri"], default="snippet",
                        help="snippet=可直接粘贴的 <image> 片段；data-uri=只输出 URI")
    parser.add_argument("--outfile", help="把结果写入文件（默认打印到标准输出）")
    args = parser.parse_args()

    path = Path(args.image)
    if not path.is_file():
        print(f"找不到图片：{path}", file=sys.stderr)
        return 2
    if path.suffix.lower() == ".svg":
        print(
            "SVG 是矢量素材：请把代码清理后直接内联为 <symbol>/<g>（见素材与纹饰库 §3.1），不要转 base64。",
            file=sys.stderr,
        )
        return 2

    try:
        image = Image.open(path)
        image.load()
    except Exception as exc:  # noqa: BLE001 - 交给用户看具体原因
        print(
            f"无法读取图片：{exc}\n"
            "  若为 webp/avif，请先用 Pillow 装好对应解码支持，或转成 png/jpg 后重试。",
            file=sys.stderr,
        )
        return 2

    original = (image.width, image.height)
    if args.trim_alpha:
        image = trim_alpha(image)
    if args.trim_white:
        image = trim_white(image)
    if image.width > args.max_width:
        ratio = args.max_width / image.width
        image = image.resize((args.max_width, max(1, round(image.height * ratio))), Image.LANCZOS)

    mime, payload = encode(image, args.mode)
    if args.max_kb:
        guard = 0
        while len(payload) / 1024 > args.max_kb and image.width > 80 and guard < 6:
            image = image.resize((int(image.width * 0.8), int(image.height * 0.8)), Image.LANCZOS)
            mime, payload = encode(image, args.mode)
            guard += 1

    data_uri = f"data:{mime};base64,{payload}"

    width = args.w or str(image.width)
    height = args.h or str(image.height)
    attrs = [f'x="{args.x}"', f'y="{args.y}"', f'width="{width}"', f'height="{height}"']
    if args.slice:
        attrs.append('preserveAspectRatio="xMidYMid slice"')
    attrs.append(f'href="{data_uri}"')
    image_tag = "<image " + " ".join(attrs) + "/>"
    if args.opacity:
        image_tag = f'<g opacity="{args.opacity}"' + (f' mask="url(#{args.mask})"' if args.mask else "") + ">\n  " + image_tag + "\n</g>"
    elif args.mask:
        image_tag = f'<g mask="url(#{args.mask})">\n  {image_tag}\n</g>'

    output = data_uri if args.output == "data-uri" else image_tag
    if args.outfile:
        Path(args.outfile).write_text(output, encoding="utf-8")
    else:
        print(output)

    print(
        f"原图 {original[0]}×{original[1]} → 输出 {image.width}×{image.height}，"
        f"{mime}，base64 {len(payload) / 1024:.1f} KB",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
