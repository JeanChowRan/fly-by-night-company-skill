"""文字容纳量校验：每行能放多少字、需要几行、是否越出背景框。

规则（用户规范）：文字必须落在背景框内，超限的处理顺序是
  ① 缩字号（下限：正文 13 / 注释 12）→ ② 按标点换行 → ③ 改短文案 → ④ 才加宽背景框。

计算：可用内宽 = 背景框宽 − 2×内边距（默认 12）；每行字数 ≈ 可用内宽 ÷ 字号（纯中文）；
      所需行数 = ceil(文字宽 ÷ 可用内宽)；所需高 = 行数 × 字号 × 1.25 + 上下内边距。

用法：python check_svg_textfit.py "inc*.svg" [--pad 12] [--min-size 12]
"""

import argparse
import glob
import math
import sys
from pathlib import Path

from lxml import etree

NS = "http://www.w3.org/2000/svg"


def char_width(value, size):
    return sum(0.28 if c.isspace() else (1.0 if ord(c) > 0x2E80 else 0.5) for c in value) * size


def rect(node):
    try:
        x, y = float(node.get("x", 0)), float(node.get("y", 0))
        return [x, y, x + float(node.get("width", 0)), y + float(node.get("height", 0))]
    except (TypeError, ValueError):
        return None


def area(b):
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def check(path, pad, min_size):
    root = etree.parse(str(path)).getroot()
    boxes = []
    for node in root.findall(f".//{{{NS}}}rect"):
        b = rect(node)
        if b and b[2] - b[0] > 60 and b[3] - b[1] > 24:
            boxes.append((node.get("data-slot") or "shape", b))
    boxes.sort(key=lambda item: area(item[1]), reverse=True)   # 从大到小：优先最大的包含框
    issues = []
    for node in root.findall(f".//{{{NS}}}text"):
        value = "".join(node.itertext()).strip()
        if not value:
            continue
        size = float(node.get("font-size", 16))
        width = char_width(value, size)
        x, y = float(node.get("x", 0)), float(node.get("y", 0))
        anchor = node.get("text-anchor", "start")
        left = x if anchor == "start" else (x - width / 2 if anchor == "middle" else x - width)
        tb = [left, y - size * 0.92, left + width, y + size * 0.36]
        center = ((tb[0] + tb[2]) / 2, (tb[1] + tb[3]) / 2)
        inside = [item for item in boxes
                  if item[1][0] - 2 <= center[0] <= item[1][2] + 2 and item[1][1] - 2 <= center[1] <= item[1][3] + 2]
        card = next((b for kind, b in inside if kind == "card"), None)
        holder = card or (inside[0][1] if inside else None)
        if holder is None:
            continue
        inner_w = (holder[2] - holder[0]) - 2 * pad
        inner_h = (holder[3] - holder[1]) - 2 * pad
        if inner_w <= 0:
            continue
        per_line = max(1, int(inner_w / max(1.0, size)))
        lines_needed = max(1, math.ceil(width / inner_w))
        height_needed = lines_needed * size * 1.25
        overflow_w = tb[2] > holder[2] - pad + 0.5 or tb[0] < holder[0] + pad - 0.5
        overflow_h = height_needed > inner_h
        if overflow_w or overflow_h:
            action = "缩字号" if size > min_size else ("改行/改短文案" if lines_needed > 1 else "加宽背景框")
            issues.append(f"「{value[:16]}」每行≤{per_line}字，需{lines_needed}行 / 高{round(height_needed)} "
                          f"（框内高{round(inner_h)}）→ {action}")
    return issues


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+")
    parser.add_argument("--pad", type=float, default=12)
    parser.add_argument("--min-size", type=float, default=12)
    args = parser.parse_args()
    files = []
    for pattern in args.files:
        matched = [Path(p) for p in glob.glob(pattern)]
        files += matched if matched else [Path(pattern)]
    total = 0
    for path in files:
        if not path.is_file():
            continue
        issues = check(path, args.pad, args.min_size)
        total += len(issues)
        if issues:
            print(f"{path.name}: {len(issues)} 处文字容纳不足")
            for item in issues[:5]:
                print("   -", item)
    print(f"\n检查 {len(files)} 张，合计 {total} 处")
    return 0 if total == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
