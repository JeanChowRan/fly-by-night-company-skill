#!/usr/bin/env python3
"""机械校验学术信息图 SVG：结构、外链、术语泄漏、use 悬空、画布比例、文字溢出估算、位图内联质量。

用法:
    python check_svg.py figure.svg [--ratio 3:4] [--margin 48] [--max-warn 20]

退出码 0 表示无硬错误（警告仍可能输出）；1 表示存在硬错误或文件不可用。
本脚本只覆盖可机械判定的部分，详略是否分明、语义是否贴切仍需按 SKILL.md 人工复核。
"""

import argparse
import re
import sys
import xml.etree.ElementTree as ET

ALLOWED_NAMESPACES = {
    "http://www.w3.org/2000/svg",
    "http://www.w3.org/1999/xlink",
    "http://www.w3.org/XML/1998/namespace",
    "http://www.w3.org/1999/xhtml",
}

# 内部术语：出现即视为泄漏
TERM_ERRORS = ["详细表示", "缩略表示", "重点度", "关键度"]
# 可能与正文同名的词：只提示
TERM_WARNINGS = ["本体", "实例"]

URL_RE = re.compile(r"(?:https?://|//)[^\s\"'()<>]+")
REMOTE_CSS_RE = re.compile(r"@(?:import|font-face)\b[^}]*?https?://", re.IGNORECASE)

GEOMETRIC_TAGS = {"rect", "circle", "ellipse", "image", "use"}


def local_name(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def parse_length(value):
    if value is None:
        return None
    match = re.match(r"^\s*(-?[\d.]+)\s*(px|pt|%)?\s*$", value)
    if not match:
        return None
    number = float(match.group(1))
    unit = match.group(2)
    if unit == "pt":
        return number * 4.0 / 3.0
    if unit == "%":
        return None
    return number


def parse_number(value):
    if value is None:
        return None
    try:
        return float(str(value).strip())
    except ValueError:
        return None


def text_width_estimate(text, font_size):
    width = 0.0
    for char in text:
        code = ord(char)
        if 0x3000 <= code <= 0x303F or 0x4E00 <= code <= 0x9FFF or 0xFF00 <= code <= 0xFFEF:
            width += font_size
        elif char.isdigit():
            width += font_size * 0.6
        elif char in ".,:;'|!i l":
            width += font_size * 0.3
        else:
            width += font_size * 0.55
    return width


def element_box(element, parent_font_size):
    """返回 (x, y, w, h, font_size) 估算盒；无法估算返回 None。"""
    tag = local_name(element.tag)
    attrs = element.attrib
    font_size = parse_length(attrs.get("font-size")) or parent_font_size

    if tag == "rect":
        x = parse_length(attrs.get("x")) or 0.0
        y = parse_length(attrs.get("y")) or 0.0
        w = parse_length(attrs.get("width")) or 0.0
        h = parse_length(attrs.get("height")) or 0.0
        return x, y, w, h, font_size
    if tag in ("image", "use"):
        x = parse_length(attrs.get("x")) or 0.0
        y = parse_length(attrs.get("y")) or 0.0
        w = parse_length(attrs.get("width")) or 0.0
        h = parse_length(attrs.get("height")) or 0.0
        return x, y, w, h, font_size
    if tag == "circle":
        cx = parse_length(attrs.get("cx")) or 0.0
        cy = parse_length(attrs.get("cy")) or 0.0
        r = parse_length(attrs.get("r")) or 0.0
        return cx - r, cy - r, 2 * r, 2 * r, font_size
    if tag == "ellipse":
        cx = parse_length(attrs.get("cx")) or 0.0
        cy = parse_length(attrs.get("cy")) or 0.0
        rx = parse_length(attrs.get("rx")) or 0.0
        ry = parse_length(attrs.get("ry")) or 0.0
        return cx - rx, cy - ry, 2 * rx, 2 * ry, font_size
    if tag == "text":
        x = parse_length(attrs.get("x")) or 0.0
        y = parse_length(attrs.get("y")) or 0.0
        content = "".join(element.itertext())
        width = text_width_estimate(content, font_size)
        anchor = attrs.get("text-anchor", "start")
        if anchor == "middle":
            x -= width / 2
        elif anchor == "end":
            x -= width
        return x, y - font_size * 0.8, width, font_size * 1.2, font_size
    return None


def collect(root, canvas):
    """返回 (节点列表, 父映射, id 集合, 文本节点列表)。"""
    nodes = []
    parents = {}
    ids = set()
    stack = [(root, None, 1.0)]
    while stack:
        element, parent, parent_font_size = stack.pop()
        nodes.append(element)
        if parent is not None:
            parents[element] = parent
        if element.get("id"):
            ids.add(element.get("id"))
        font_size = parse_length(element.get("font-size")) or parent_font_size
        for child in list(element):
            stack.append((child, element, font_size))
    return nodes, parents, ids


def find_containers(element, parents, boxes, canvas_w):
    """在祖先链上找包裹该文本的最小容器矩形。"""
    _, _, _, _, _ = boxes[element]
    x, y, w, h, _ = boxes[element]
    point_x, point_y = x + w / 2, y + h / 2
    best = None
    current = parents.get(element)
    while current is not None:
        box = boxes.get(current)
        if box:
            bx, by, bw, bh, _ = box
            if (
                bx <= point_x <= bx + bw
                and by <= point_y <= by + bh
                and bw < canvas_w * 0.98
            ):
                if best is None or bw * bh < best[2] * best[3]:
                    best = box
        current = parents.get(current)
    return best


def check(path, ratio, margin, max_warn):
    errors, warnings = [], []
    try:
        with open(path, "r", encoding="utf-8") as handle:
            raw = handle.read()
    except OSError as exc:
        return [f"无法读取文件: {exc}"], []

    try:
        root = ET.fromstring(raw)
    except ET.ParseError as exc:
        return [f"XML 解析失败（SVG 不合法）: {exc}"], []

    if local_name(root.tag) != "svg":
        errors.append(f"根节点不是 svg，而是 {local_name(root.tag) or root.tag}")

    canvas_w = parse_length(root.get("width"))
    canvas_h = parse_length(root.get("height"))
    view_box = root.get("viewBox")

    if not view_box:
        warnings.append("缺少 viewBox 属性")
    if canvas_w is None or canvas_h is None:
        if view_box:
            parts = view_box.replace(",", " ").split()
            if len(parts) == 4:
                canvas_w = canvas_w or float(parts[2])
                canvas_h = canvas_h or float(parts[3])
        if canvas_w is None or canvas_h is None:
            errors.append("缺少可解析的 width/height（且 viewBox 无法兜底）")

    if canvas_w and canvas_h:
        want_w, want_h = (float(part) for part in ratio)
        got = canvas_w / canvas_h
        want = want_w / want_h
        if abs(got - want) / want > 0.01:
            errors.append(
                f"画布比例不符：实际 {canvas_w:g}×{canvas_h:g} = {got:.3f}，期望 {want:.3f}（{ratio[0]}:{ratio[1]}）"
            )

    # 外链（先剥离内联 data URI——base64 里天然含 "//"，不是外链）
    scan = re.sub(r"data:[^\"')>\s]*", "data:", raw)
    for match in URL_RE.finditer(scan):
        url = match.group(0)
        if any(url.startswith(ns) or ns.startswith(url) for ns in ALLOWED_NAMESPACES):
            continue
        if url.startswith("//www.w3.org"):
            continue
        errors.append(
            f"存在外部引用，断网可能无法显示: {url[:80]}"
            "（Bing 等渠道下载的素材必须内联；输出 SVG 中不得出现任何 URL）"
        )
    if REMOTE_CSS_RE.search(raw):
        errors.append("样式表引用了远程字体/资源（@import 或 @font-face 带 http）")

    nodes, parents, ids = collect(root, canvas_w)

    # 术语泄漏
    for element in nodes:
        if local_name(element.tag) != "text":
            continue
        content = "".join(element.itertext())
        for term in TERM_ERRORS:
            if term in content:
                errors.append(f"文本中包含内部术语「{term}」: {content[:40]}")
        for term in TERM_WARNINGS:
            if term in content:
                warnings.append(f"文本中出现可能为内部术语的词「{term}」: {content[:40]}")

    # 字体：中文宋体、英文 Times New Roman、公式按 MathType（TNR 斜体变量 + 正体数字）
    font_decls = [element.get("font-family") for element in nodes if element.get("font-family")]
    for element in nodes:
        if local_name(element.tag) == "style" and element.text:
            font_decls.extend(re.findall(r"font-family\s*:\s*([^;}]+)", element.text))
    joined = " ".join(font_decls).lower()
    if not font_decls:
        errors.append(
            "未声明字体：中文须用宋体（SimSun）、英文与数字须用 Times New Roman，"
            "公式按 MathType（变量 TNR 斜体、数字与函数名正体）"
        )
    else:
        if "times new roman" not in joined:
            warnings.append("字体声明中未见 Times New Roman：英文与数字应使用 Times New Roman")
        cjk_doc = "simsun" in joined or "宋体" in joined
        cjk_ppt = "microsoft yahei" in joined or "微软雅黑" in joined
        if not cjk_doc and not cjk_ppt:
            warnings.append("字体声明中未见 SimSun/宋体：中文应使用宋体")
        # 汇报配图（PPT）用微软雅黑：此时通用回退名不算冲突
        bad_list = ("arial", "helvetica", "roboto", "segoe") if cjk_ppt else \
            ("arial", "helvetica", "roboto", "segoe", "sans-serif")
        for bad in bad_list:
            if bad in joined:
                warnings.append(f"字体声明含 {bad}：与“中文宋体 / 英文 Times New Roman”不一致")

    # use 引用悬空
    for element in nodes:
        if local_name(element.tag) != "use":
            continue
        href = element.get("href") or element.get("{http://www.w3.org/1999/xlink}href") or ""
        if not href.startswith("#"):
            if href:
                errors.append(f"<use> 引用了非本地目标: {href[:60]}")
            continue
        if href[1:] not in ids:
            errors.append(f"<use> 引用了未定义的 id: {href}")

    # 位图素材：内联、透明通道、收边
    for element in nodes:
        if local_name(element.tag) != "image":
            continue
        href = element.get("href") or element.get("{http://www.w3.org/1999/xlink}href") or ""
        if not href.startswith("data:"):
            if href and not href.startswith(("http://", "https://")):
                warnings.append(f"<image> 未使用 base64 data URI 内联: {href[:60]}")
        elif href[:24].lower().startswith(("data:image/jpeg", "data:image/jpg")):
            warnings.append("<image> 使用 JPEG（无透明通道）：仅适合 0.2 透明度的背景层并配羽化蒙版；前景贴图请用 PNG/SVG")

        has_mask = False
        current = element
        while current is not None:
            if current.get("mask") or current.get("clip-path"):
                has_mask = True
                break
            current = parents.get(current)
        if not has_mask:
            warnings.append("<image> 未加 mask/clip-path：位图建议羽化或圆角裁切，避免白底方块")

        opacity = parse_number(element.get("opacity"))
        current = parents.get(element)
        while current is not None and opacity is None:
            opacity = parse_number(current.get("opacity"))
            current = parents.get(current)
        if opacity is None:
            opacity = 1.0

        box = element_box(element, 16.0)
        if box and canvas_w and canvas_h:
            area_ratio = (box[2] * box[3]) / (canvas_w * canvas_h)
            if area_ratio >= 0.3 and opacity > 0.3:
                warnings.append(
                    f"大面积素材图透明度为 {opacity:g}（约占画布 {area_ratio:.0%}）："
                    "作背景层时应取 0.15–0.25，并在其上垫白色 60–80% 安全底"
                )
            elif area_ratio > 0.15 and opacity > 0.35:
                warnings.append(
                    f"前景贴图约占画布 {area_ratio:.0%}（>15%）：建议裁小，或降到 0.2 改为背景层"
                )

    # 文字溢出估算 + 安全边距
    boxes = {}
    for element in nodes:
        parent_font = 16.0
        parent = parents.get(element)
        while parent is not None:
            value = parse_length(parent.get("font-size"))
            if value:
                parent_font = value
                break
            parent = parents.get(parent)
        box = element_box(element, parent_font)
        if box:
            boxes[element] = box

    overflow_count = 0
    for element in nodes:
        if local_name(element.tag) != "text":
            continue
        box = boxes.get(element)
        if not box:
            continue
        x, y, w, h, font_size = box
        container = find_containers(element, parents, boxes, canvas_w or 1200.0)
        content = "".join(element.itertext()).strip()
        if container:
            cx, cy, cw, ch, _ = container
            if x + w > cx + cw - 4 or x < cx + 4:
                overflow_count += 1
                warnings.append(
                    f"文字可能溢出容器: 「{content[:16]}」(估算宽 {w:.0f}px, 容器宽 {cw:.0f}px)"
                )
        elif canvas_w and canvas_h:
            if (
                x < margin
                or y < margin * 0.2
                or x + w > canvas_w - margin
                or y + h > canvas_h - margin * 0.5
            ):
                overflow_count += 1
                warnings.append(f"文字可能越出安全边距: 「{content[:16]}」")

    # 顶层元素的边距检查（跳过整幅底图）
    if canvas_w and canvas_h:
        for element in list(root):
            tag = local_name(element.tag)
            if tag in ("defs", "style", "title", "desc", "metadata", "mask", "pattern"):
                continue
            box = boxes.get(element)
            if not box:
                continue
            x, y, w, h, _ = box
            if w >= canvas_w * 0.98 and h >= canvas_h * 0.98:
                continue
            if x < -1 or y < -1 or x + w > canvas_w + 1 or y + h > canvas_h + 1:
                warnings.append(f"顶层 <{tag}> 超出画布范围: x={x:.0f} y={y:.0f} w={w:.0f} h={h:.0f}")

        # 内容包围盒与四周留白：防止"声明大画布、内容只占一半"的白边问题
        # 容器内部占用率：防止"一级容器里子要素挤一角、容器大片留白"
        for element in nodes:
            if local_name(element.tag) != "rect":
                continue
            box = boxes.get(element)
            if not box:
                continue
            cx, cy, cw, ch, _ = box
            container_area = cw * ch
            if container_area < canvas_w * canvas_h * 0.03:
                continue  # 只检查容器级别的矩形
            if ch < 90:
                continue  # 细标题带/条状容器不参与铺开率判定（文字本就占满宽度）
            pad = 12.0
            inner_w, inner_h = max(1.0, cw - 2 * pad), max(1.0, ch - 2 * pad)
            inner_area = inner_w * inner_h
            min_x = min_y = float("inf")
            max_x = max_y = float("-inf")
            children = 0
            for other in nodes:
                if other is element:
                    continue
                other_box = boxes.get(other)
                if not other_box:
                    continue
                ox, oy, ow, oh, _ = other_box
                if ow <= 0 or oh <= 0:
                    continue
                center_x, center_y = ox + ow / 2, oy + oh / 2
                if not (cx + 4 <= center_x <= cx + cw - 4 and cy + 4 <= center_y <= cy + ch - 4):
                    continue
                if ow * oh >= container_area * 0.95:
                    continue
                children += 1
                min_x, min_y = min(min_x, ox), min(min_y, oy)
                max_x, max_y = max(max_x, ox + ow), max(max_y, oy + oh)
            if children >= 2:
                union_w = max(0.0, min(max_x, cx + cw) - max(min_x, cx))
                union_h = max(0.0, min(max_y, cy + ch) - max(min_y, cy))
                ratio = min(1.0, (union_w * union_h) / inner_area)
                if ratio < 0.6:
                    warnings.append(
                        f"容器内部留白过大：容器 ({cx:.0f},{cy:.0f},{cw:.0f}×{ch:.0f}) 内有 {children} 个子要素，"
                        f"子要素只铺开 {ratio:.0%}（建议 ≥60%）；应收紧容器尺寸、扩大子要素、或按栅格重排"
                    )

        ink_boxes = []
        for element in nodes:
            box = boxes.get(element)
            if not box:
                continue
            x, y, w, h, _ = box
            if w >= canvas_w * 0.98 and h >= canvas_h * 0.98:
                continue  # 整幅底色不算内容
            if w <= 0 or h <= 0:
                continue
            ink_boxes.append((x, y, x + w, y + h))
        if ink_boxes:
            left_ink = min(b[0] for b in ink_boxes)
            top_ink = min(b[1] for b in ink_boxes)
            right_ink = canvas_w - max(b[2] for b in ink_boxes)
            bottom_ink = canvas_h - max(b[3] for b in ink_boxes)
            margins = {"左": left_ink, "上": top_ink, "右": right_ink, "下": bottom_ink}
            worst_side, worst_value = max(margins.items(), key=lambda kv: kv[1])
            limit = max(margin * 1.8, 60.0)
            if worst_value > limit:
                warnings.append(
                    "边缘白边过大："
                    + "　".join(f"{side}{value:.0f}px" for side, value in margins.items())
                    + f"（{worst_side}侧 {worst_value:.0f}px 超上限 {limit:.0f}px）"
                    "；应把画布收缩到内容包围盒，或把内容铺满安全区"
                )
            elif max(margins.values()) - min(margins.values()) > max(margin * 1.5, 48.0):
                warnings.append(
                    "四周留白不均："
                    + "　".join(f"{side}{value:.0f}px" for side, value in margins.items())
                    + "；建议对齐到同一安全边距"
                )

    if not any(local_name(element.tag) == "defs" for element in nodes):
        warnings.append("未发现 <defs>：若使用了图标或纹饰，请确认素材已内联")

    if len(warnings) > max_warn:
        hidden = len(warnings) - max_warn
        warnings = warnings[:max_warn] + [f"…另有 {hidden} 条警告未显示（--max-warn 可调整）"]

    return errors, warnings


def main():
    parser = argparse.ArgumentParser(description="校验信息图 SVG 的可机械判定问题")
    parser.add_argument("svg", help="待校验的 SVG 文件路径")
    parser.add_argument("--ratio", default="3:4", help="期望的宽:高，默认 3:4")
    parser.add_argument("--margin", type=float, default=48.0, help="安全边距，默认 48px")
    parser.add_argument("--max-warn", type=int, default=20, help="最多显示的警告条数")
    args = parser.parse_args()

    ratio = tuple(args.ratio.split(":"))
    if len(ratio) != 2:
        print("--ratio 需形如 3:4")
        return 2

    errors, warnings = check(args.svg, ratio, args.margin, args.max_warn)

    for item in errors:
        print(f"[错误] {item}")
    for item in warnings:
        print(f"[提示] {item}")

    print(f"\n校验结果: 错误 {len(errors)} 条，提示 {len(warnings)} 条")
    if not errors:
        print("结构类检查通过；详略是否分明、语义是否贴切请按 SKILL.md 人工复核。")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
