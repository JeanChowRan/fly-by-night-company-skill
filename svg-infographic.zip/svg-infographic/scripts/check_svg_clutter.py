"""图内错乱检测：兄弟块互相压（非包含关系）、文字互相压、文字压住非所属卡片。

用法：python check_svg_clutter.py "inc*.svg"
判定：
  1. 两个矩形块相互重叠但不构成包含关系，且重叠 >较小的 8% → 块互压；
  2. 两个文字包围盒重叠 >20%（以较小者计）→ 文字互压；
  3. 文字中心在某卡片内、但文字越出该卡片 → 跑出卡片。
"""

import glob
import sys
from pathlib import Path

from lxml import etree

SVG = "http://www.w3.org/2000/svg"


def box(x, y, w, h):
    return [float(x), float(y), float(x) + float(w), float(y) + float(h)]


def rect_of(node):
    try:
        if node.tag.endswith("rect"):
            return box(node.get("x", 0), node.get("y", 0), node.get("width", 0), node.get("height", 0))
        if node.tag.endswith("image"):
            return box(node.get("x", 0), node.get("y", 0), node.get("width", 0), node.get("height", 0))
        if node.tag.endswith("use"):
            return box(node.get("x", 0), node.get("y", 0), node.get("width", 0), node.get("height", 0))
    except (TypeError, ValueError):
        return None
    return None


def text_of(node):
    try:
        size = float(node.get("font-size", 16))
        anchor = node.get("text-anchor", "start")
        value = "".join(node.itertext()).strip()
        if not value:
            return None
        width = sum(0.28 if c.isspace() else (1.0 if ord(c) > 0x2E80 else 0.5) for c in value) * size
        x, y = float(node.get("x", 0)), float(node.get("y", 0))
        if anchor == "middle":
            x -= width / 2
        elif anchor == "end":
            x -= width
        return box(x, y - size * 0.92, width, size * 1.28)
    except (TypeError, ValueError):
        return None


def area(b):
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def inter(a, b):
    return max(0.0, min(a[2], b[2]) - max(a[0], b[0])) * max(0.0, min(a[3], b[3]) - max(a[1], b[1]))


def contains(o, i, tol=1.0):
    return i[0] >= o[0] - tol and i[1] >= o[1] - tol and i[2] <= o[2] + tol and i[3] <= o[3] + tol


def check(path):
    root = etree.parse(str(path)).getroot()
    blocks = []
    for node in root.iter():
        if not isinstance(node.tag, str):
            continue
        if node.tag.endswith("rect"):
            b = rect_of(node)
            if b and node.get("data-slot") in ("card", "material"):   # 只比较登记的本体块
                blocks.append(("rect", node.get("data-slot") or "shape", b))
        elif node.tag.endswith("image"):
            b = rect_of(node)
            if b:
                blocks.append(("image", "material", b))
    texts = []
    for node in root.findall(f".//{{{SVG}}}text"):
        b = text_of(node)
        value = "".join(node.itertext()).strip()
        if b:
            texts.append((value[:14], b))
    issues = []
    for i in range(len(blocks)):
        for j in range(i + 1, len(blocks)):
            a, b = blocks[i][2], blocks[j][2]
            ov = inter(a, b)
            if ov <= 0:
                continue
            if contains(a, b) or contains(b, a):
                continue
            if ov > 0.08 * min(area(a), area(b)):
                issues.append(f"块互压：{blocks[i][1]}{[round(v) for v in a]} × {blocks[j][1]}{[round(v) for v in b]}")
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            ov = inter(texts[i][1], texts[j][1])
            if ov > 0.2 * min(area(texts[i][1]), area(texts[j][1])):
                issues.append(f"文字互压：{texts[i][0]} × {texts[j][0]}")
    return issues


def main():
    files = []
    for pattern in sys.argv[1:]:
        matched = [Path(p) for p in glob.glob(pattern)]
        files += matched if matched else [Path(pattern)]
    total = 0
    for path in files:
        if not path.is_file():
            continue
        issues = check(path)
        total += len(issues)
        print(f"{path.name}: {'OK' if not issues else str(len(issues)) + ' 项错乱'}")
        for item in issues[:8]:
            print("   -", item)
    print(f"\n合计 {total} 项")
    return 0 if total == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
