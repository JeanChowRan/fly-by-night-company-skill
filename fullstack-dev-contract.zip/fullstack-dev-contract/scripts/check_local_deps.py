"""前端本地依赖自检：确认项目内已物理存在契约要求的前端库文件。

用法：python scripts/check_local_deps.py <项目根目录>
检查：static/jsscripts/ 下契约要求的 .js / .css 是否齐备（缺文件、只有空目录、0 字节都会报出来）。
退出码：0 = 全部就绪；1 = 有缺项（逐条列出，缺失项属项目资产，从本机旧项目或内网共享目录补齐）。
本脚本只读、不联网、不修改项目。
"""

import sys
from pathlib import Path

# 契约 7.2 规定的本地依赖（相对项目根目录）
REQUIRED = [
    "static/jsscripts/vue.js",
    "static/jsscripts/axios.js",
    "static/jsscripts/elementui/lib-master/index.js",
    "static/jsscripts/elementui/lib-master/theme-chalk/index.css",
    "static/jsscripts/database-preference.js",
    "static/jsscripts/office/plugin.js",
    "static/jsscripts/office/xspreadsheet.js",
    "static/jsscripts/office/xspreadsheet.css",
    "static/jsscripts/office/jszip.min.js",
    "static/jsscripts/office/xlsx.full.min.js",
    "static/jsscripts/office/docx-preview.min.js",
    "static/jsscripts/office/pdf.min.js",
    "static/jsscripts/office/pdf.worker.min.js",
    "static/design-system.css",
]


def check(root):
    missing, empty, ok = [], [], []
    for rel in REQUIRED:
        target = root / rel
        if target.is_file():
            if target.stat().st_size == 0:
                empty.append(rel)
            else:
                ok.append(rel)
        elif target.is_dir():
            empty.append(rel + "（存在同名目录，不是文件）")
        else:
            missing.append(rel)
    print("项目根目录:", root)
    print("就绪 %d 项" % len(ok))
    for rel in ok:
        print("  [OK]  ", rel)
    for rel in empty:
        print("  [空/异常]", rel)
    for rel in missing:
        print("  [缺失]", rel)
    if missing or empty:
        print("--")
        print("结论：有 %d 项待补。" % (len(missing) + len(empty)))
        print("处置：从本机旧项目、历史安装包或内网共享目录把这些文件复制到对应路径；")
        print("      禁止改用 CDN 或在线引用，缺项补齐后再生成页面代码。")
        return 1
    print("--")
    print("结论：本地依赖齐备，可离线运行前端页面。")
    return 0


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    root = Path(sys.argv[1]).expanduser().resolve()
    if not root.is_dir():
        print("目录不存在：%s" % root)
        return 2
    return check(root)


if __name__ == "__main__":
    sys.exit(main())
