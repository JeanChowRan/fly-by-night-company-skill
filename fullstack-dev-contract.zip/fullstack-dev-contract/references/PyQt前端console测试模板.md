# PyQt 前端验证模板（HTML 服务：业务需求 → 用例 → 触发流 → 执行）

> 用途：用 PyQt5 QWebEngineView 验证后端渲染的 HTML 服务（Flask 页面 + 本地 Vue/JS，
> 无 Node、无 CDN）。判定重点是“页面渲染无 console error + 事件触发后的 UI/落库行为”。
> 本文件是**可裁剪模板**，不是具体项目案例；四层细化节奏：
> 业务需求 → 用例 → 触发流 → 执行。

## 0) 细化链路（从需求到执行逐层展开）

| 层 | 要回答的问题 | 产物形态 |
|---|---|---|
| 业务需求 | 页面/服务要满足什么业务？成功与失败分别长什么样？ | 一句验收目标 + 约束清单（前置上下文、数据依赖、模型/状态依赖） |
| 用例 | 给什么前置与输入、做什么动作、期待什么结果？ | 每条“前置 → 数据 → 动作 → 期待输出”的用例；期待输出含 UI 反馈、DOM/落库、无 console error |
| 触发流 | 动作按什么顺序触发？涉及哪些可触发事件？ | 编号步骤：建上下文 → 喂数据 → 触发计算 → 断言结果 |
| 执行 | 用 PyQt 怎么驱动、怎么判定、怎么进 CI？ | 驱动函数 + console 捕获 + 快检/完整分档 + 退出码 |

触发流编排规则（由业务前置决定顺序，不“乱点”）：
- 先有上下文（登录/产品/项目）→ 再喂数据（上传/示例/输入）→ 再触发计算（训练/优化/分析）→
  最后断言结果（DOM/图表/落库）。
- 前置不满足时：断言按钮 `disabled` 或结果区保持占位，而不是硬点按钮去等一个不存在的 toast。
- 后端 400 类负例在 axios 一律进 `catch`，页面通常只显示“请求失败”类通用文案；
  负例断言 = 通用文案 + 结果区不变 + 无 console error，不期望后端 message 原样上屏。
- 长耗时步骤分档：默认快检跳过真实训练/长推理，完整档才跑，保证 CI 能快速回归。

## 1) 用例与触发流模板（填写式）

### 用例模板（每个用例一条）
- 业务需求编号：R-xx（对应第 0 层需求）
- 前置：已存在哪些数据/状态；哪些按钮此时应 disabled
- 数据：要输入/上传/选择什么
- 触发流：
  1. 打开页面并等待组件挂载（动作：导航）
  2. 建立上下文（动作：弹窗/下拉/选择）
  3. 喂入数据（动作：input/上传/示例按钮）
  4. 触发主动作（动作：主按钮，等待 loading 态结束）
  5. 断言结果（动作：轮询等待 UI 反馈、DOM/落库、console）
- 期待输出：toast 文案 / 表格行数与内容 / 图表节点 / DB 行数 / 全程无 console error
- 负例：未满足前置时点击，应得到什么（通用失败文案 + 状态不变 + 无 console error）

### 事件触发速查（自动化 vs 打桩）
| 可触发事件 | 驱动方式 |
|---|---|
| 普通 button | 定位后 `.click()` |
| 输入框（Vue v-model） | 原生 value setter + `dispatchEvent('input')` |
| 下拉选择（Element UI 等） | 打开下拉 → 点可见 option；断言用组件实例数据而非 innerText |
| 文件上传 | DataTransfer 注入 File → 绑定 `input[type=file]` → dispatch change（不弹系统框） |
| 原生 confirm | `window.confirm` 打桩 true/false 两分支 |
| 弹窗按钮 | 弹窗可见后按文案点击 |
| 长任务按钮 | 断言 loading/disabled 态翻转 |

## 2) console 捕获骨架（最小可跑模板）

```python
# html_console_smoke.py —— 模板，页面清单在使用方按项目填写
import sys
from PyQt5.QtCore import QTimer, QUrl
from PyQt5.QtWebEngineWidgets import QWebEnginePage, QWebEngineView
from PyQt5.QtWidgets import QApplication, QMainWindow

PAGES = ()            # 使用方填写：待验证页面路径，如 ('/', '/modeling')
BASE = 'http://127.0.0.1:5000'


class ConsolePage(QWebEnginePage):
    def __init__(self, parent=None):
        super(ConsolePage, self).__init__(parent)
        self.errors = []

    def javaScriptConsoleMessage(self, level, message, line, source):
        tag = {0: 'info', 1: 'warning', 2: 'error'}.get(level, str(level))
        text = '[console:%s] %s (%s:%s)' % (tag, message, source, line)
        if level == 2:
            self.errors.append(text)
        print(text)


class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.browser = QWebEngineView()
        self.page = ConsolePage(self.browser)
        self.browser.setPage(self.page)
        self.setCentralWidget(self.browser)
        self._idx = 0

    def start(self):
        self.show()
        QTimer.singleShot(0, self._next)

    def _next(self):
        if self._idx >= len(PAGES):
            n = len(self.page.errors)
            print('SMOKE_RESULT pages=%d console_errors=%d' % (len(PAGES), n))
            QApplication.instance().exit(0 if n == 0 else 1)
            return
        self.browser.load(QUrl(BASE + PAGES[self._idx]))
        self._idx += 1
        QTimer.singleShot(7000, self._next)


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.start()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
```

## 3) 触发流执行骨架（用例 → 可执行步骤）

下列 helper 是**通用驱动模板**：触发流本身写在用例函数里（见第 1 节），
不要在模板里写死项目页面名/URL/流程。

```python
# html_flow_test.py —— 模板
import time
from PyQt5.QtCore import QEventLoop, QTimer, QUrl
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWidgets import QApplication
# ConsolePage 复用第 2 节定义


def now_ms():
    return int(time.time() * 1000)


class FlowDriver(object):
    """通用执行器：所有页面操作走 run_js + 轮询等待。"""

    def __init__(self, base_url):
        self.app = QApplication.instance() or QApplication([])
        self.view = QWebEngineView()
        self.page = ConsolePage(self.view)
        self.view.setPage(self.page)
        self.view.hide()
        self.base = base_url

    def _pump(self, ms):
        loop = QEventLoop()
        QTimer.singleShot(ms, loop.quit)
        loop.exec_()

    def goto(self, path, timeout=45000):
        # 同一 URL 重复 load 不保证整页刷新：追加 nav 参数强制重载
        sep = '&' if '?' in path else '?'
        self.view.load(QUrl(self.base + path + sep + 'nav=' + str(now_ms())))
        # 模板：此处连接一次性 loadFinished 槽，轮询置位直到 timeout；
        # 超时抛 RuntimeError('page load timeout')。
        raise NotImplementedError('等待 loadFinished 的模板实现')

    def js(self, code, timeout=15000):
        box = {}
        loop = QEventLoop()
        QTimer.singleShot(timeout, loop.quit)
        self.view.page().runJavaScript(code, lambda v: (box.update(v=v), loop.quit()))
        loop.exec_()
        return box.get('v')

    def wait_js(self, expr, timeout=20000):
        deadline = now_ms() + timeout
        while now_ms() < deadline:
            if self.js('(function(){ try { return (%s) ? 1 : 0; }'
                       ' catch (e) { return 0; } })()' % expr) == 1:
                return True
            self._pump(200)
        return False

    def wait_text(self, text, timeout=20000):
        # 注意：组件选中值不一定在 innerText（见第 1 节速查）
        return self.wait_js('document.body && document.body.innerText.indexOf("%s") !== -1' % text,
                            timeout=timeout)

    def click_button(self, root_selector, text):
        # 通用实现：root.querySelectorAll('button') 按 innerText 命中后 .click()
        raise NotImplementedError('按使用方页面填写命中规则')

    def set_input(self, index, value):
        # Vue v-model：原生 setter + input 事件
        raise NotImplementedError('按使用方页面填写选择器')

    def upload_via_data_transfer(self, file_name, text, file_input_selector):
        # File 注入，不弹系统框
        raise NotImplementedError('按使用方页面填写 file input 选择器')


def run_cases(cases):
    """cases: [(用例名, 执行函数)]；执行函数内逐断言抛出即失败。"""
    failed = []
    for name, fn in cases:
        try:
            fn()
            print('[PASS]', name)
        except Exception as exc:
            failed.append(name)
            print('[FAIL]', name, exc)
    print('RESULT passed=%d failed=%d' % (len(cases) - len(failed), len(failed)))
    return 1 if failed else 0
```

## 4) 用法与判定

- 桌面运行：真实桌面会话；`QT_QPA_PLATFORM=offscreen` 在 Windows 下 WebEngine 不可用
  （实测），无窗口环境改用 headless Chromium 内核浏览器（如 Microsoft Edge）抓
  `--enable-logging=stderr` 的 CONSOLE 行；按契约不得使用 Google Chrome 及 Google 相关服务。
- 判定口径：error 级 console 才算失败；`[Vue warn]` 属 warning，应修复但不是失败项。
- 快检/完整分档：默认跑不触发长耗时的用例；`--full` 追加训练/长推理用例。
- 判定分三层、各自独立：JS console error / UI 反馈（toast/message）/ DOM 与后端落库。

## 5) 经验沉淀（模板层，非具体案例）

- 事件按业务前置顺序组织：先上下文、再数据、再计算、后断言；不要“乱点”。
- 组件文本断言：Element UI 等组件选中值不一定进 `body.innerText`
  （例如 el-select 的选中 label 在 input.value）；优先断言组件实例数据或可见下拉项。
- 后端 400 负例在 axios 走 catch：断言通用失败文案 + 结果区不变 + 无 console error。
- 同 URL 重复 `load()` 不保证刷新：导航统一追加 query 参数（缓存击穿）。
- 跨页 localStorage 透传属业务上下文：主链按真实用户保留，单页独立用例才可重置。
- 文件选择框用 DataTransfer 注入；原生 confirm 打桩两分支。
- UI 测试负责链路、状态与落库行数/内容；算法数值正确性交给独立数值测试。
