"""环境自检（只读、不联网）：报告本技能所需的宿主组件在目标机器上是否就绪。

用法：python scripts/doctor.py
检查项：Python 版本、必需的 Python 包、可用的本地 SVG 渲染器、中文字体与 Times New Roman。
退出码：0 = 必需项齐全；1 = 有必需项缺失（缺失项会逐条列出并给出处置建议）。
本脚本不写文件、不联网、不修改任何配置。
"""

import importlib
import os
import shutil
import sys
from pathlib import Path

# (导入名, 说明, 是否必需)
PKGS = [
    ("docx", "python-docx（md→docx 装配）", True),
    ("PIL", "Pillow（位图缩放与压缩）", False),
    ("numpy", "NumPy（数值与图像处理）", False),
]

RENDERER_COMMANDS = ["msedge", "msedge.exe", "inkscape", "inkscape.exe",
                     "chromium", "chromium-browser", "chrome-headless-shell"]

RENDERER_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Inkscape\bin\inkscape.exe",
    "/usr/bin/inkscape",
    "/usr/local/bin/inkscape",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/Applications/Inkscape.app/Contents/MacOS/inkscape",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
]

# 按用户规范：不得使用 Google Chrome 及任何 Google 相关服务
BANNED = ("chrome.exe", "google-chrome", "google-chrome-stable", "/google/chrome")

FONT_DIRS = [
    Path(r"C:\Windows\Fonts"),
    Path("/usr/share/fonts"),
    Path("/usr/local/share/fonts"),
    Path("/Library/Fonts"),
    Path("/System/Library/Fonts"),
    Path.home() / ".fonts",
]

FONT_CANDIDATES = {
    "中文字体（宋体族）": ["simsun", "song", "simhei", "msyh", "noto serif cjk", "noto sans cjk",
                          "source han serif", "wqy", "fangsong", "kaiti"],
    "Times New Roman": ["times", "liberation serif", "nimbus roman", "dejavu serif"],
}


def _banned(path):
    lowered = str(path).lower()
    return any(token in lowered for token in BANNED)


def find_renderer():
    override = os.environ.get("SVG_RENDERER")
    if override:
        if Path(override).is_file() and not _banned(override):
            return override
        return None
    for name in RENDERER_COMMANDS:
        found = shutil.which(name)
        if found and not _banned(found):
            return found
    for path in RENDERER_PATHS:
        if Path(path).is_file() and not _banned(path):
            return path
    return None


def find_font(tokens):
    for folder in FONT_DIRS:
        if not folder.is_dir():
            continue
        try:
            entries = list(folder.iterdir())
        except OSError:
            continue
        for entry in entries:
            name = entry.name.lower()
            if any(token in name for token in tokens):
                return str(entry)
        # 字体目录常按子目录分级，再扫一层
        for entry in entries:
            if entry.is_dir():
                try:
                    for sub in entry.iterdir():
                        if any(token in sub.name.lower() for token in tokens):
                            return str(sub)
                except OSError:
                    continue
    return None


def main():
    problems = []
    print("==", "tech-summary-report 环境自检", "==")
    print("Python:", sys.version.split()[0], "|", sys.platform)
    if sys.version_info < (3, 8):
        problems.append("Python 版本过低：需要 3.8 及以上（当前 %s）" % sys.version.split()[0])

    for module, label, required in PKGS:
        try:
            importlib.import_module(module)
            print("[OK]  ", label)
        except Exception as exc:                       # noqa: BLE001 - 自检需报告任意导入失败
            tag = "[缺失]" if required else "[可选缺失]"
            print(tag, label, "->", exc)
            if required:
                problems.append("缺少必需组件：%s（pip install %s）" % (label, label.split("（")[0]))

    renderer = find_renderer()
    if renderer:
        print("[OK]   本地 SVG 渲染器:", renderer)
    else:
        print("[缺失] 本地 SVG 渲染器：未找到 Edge / Inkscape / Chromium 内核浏览器")
        problems.append("缺少 SVG 渲染器：装 Microsoft Edge 或 Inkscape，"
                        "或用环境变量 SVG_RENDERER 指定可执行文件路径（按规范不得用 Google Chrome）")

    for label, tokens in FONT_CANDIDATES.items():
        found = find_font(tokens)
        if found:
            print("[OK]   %s: %s" % (label, found))
        else:
            print("[提示] %s 未在常见字体目录找到：用系统同族字体替代并在交付说明中注明" % label)

    print("--")
    if problems:
        print("结论：需先处理以下 %d 项——" % len(problems))
        for item in problems:
            print("  -", item)
        return 1
    print("结论：必需组件齐全，可离线完成 md→docx 装配、矢量图绘制与图片回填。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
