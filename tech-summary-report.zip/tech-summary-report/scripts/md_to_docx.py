"""md → docx 基线装配（离线、本地、无外部服务）。

实现 references/docx-delivery-and-layout.md 第 2、5、6 节的版式基线：
封面节 / 目录节（自动目录域）/ 正文节（页码从 1 起编）三节；
中文字体宋体、西文与数字 Times New Roman；一级 12pt / 二级 10.5pt / 三级 9pt / 正文 9pt / 图题表题 7.5pt；
正文首行缩进 2 字符、单倍行距、段后距 0；每章另起一页；图题后、表题前、表体后各留一个空段。

用法：
    python scripts/md_to_docx.py 源稿.md -o 报告.docx
    python scripts/md_to_docx.py 源稿.md -o 报告.docx --title "报告标题" --no-toc

支持的 md 子集：标题（# / ## / ###）、自然段、无序/有序列表、管道表格、图片（![图题](相对路径)）、
围栏代码块（原样按等宽缩进段落写入）、公式行（$...$ / 独立成行的 $$...$$ 按原文写入）。

**交付后仍需按 reference 第 6、7 节收口**：在 Word 里更新目录域一次，再把 toc 1/2/3 样式的
rFonts 收口为宋体 + Times New Roman，之后不再更新域；随后逐条跑第 7 节核验清单。
本脚本只依赖 python-docx 与 Pillow，不联网、不上传，不写源稿。
"""

import argparse
import re
import sys
from pathlib import Path

try:
    import docx
    from docx.enum.section import WD_SECTION
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Inches, Pt, RGBColor
except ImportError:  # pragma: no cover
    print("需要 python-docx：pip install python-docx", file=sys.stderr)
    raise SystemExit(2)

CN_FONT = "宋体"
EN_FONT = "Times New Roman"
SIZES = {"h1": 12, "h2": 10.5, "h3": 9, "body": 9, "caption": 7.5}
CT_PAGE = 'w:pgNumType'


def set_run_fonts(run, size=None, bold=None):
    run.font.name = EN_FONT
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    rfonts.set(qn("w:ascii"), EN_FONT)
    rfonts.set(qn("w:hAnsi"), EN_FONT)
    rfonts.set(qn("w:eastAsia"), CN_FONT)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    run.font.color.rgb = RGBColor(0, 0, 0)


def style_baseline(document):
    normal = document.styles["Normal"]
    normal.font.name = EN_FONT
    normal.font.size = Pt(SIZES["body"])
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    rfonts.set(qn("w:ascii"), EN_FONT)
    rfonts.set(qn("w:hAnsi"), EN_FONT)
    rfonts.set(qn("w:eastAsia"), CN_FONT)
    pf = normal.paragraph_format
    pf.space_after = Pt(0)
    pf.line_spacing = 1.0
    for name, size in (("Heading 1", SIZES["h1"]), ("Heading 2", SIZES["h2"]), ("Heading 3", SIZES["h3"])):
        style = document.styles[name]
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(0, 0, 0)
        srpr = style.element.get_or_add_rPr()
        srfonts = srpr.find(qn("w:rFonts"))
        if srfonts is None:
            srfonts = OxmlElement("w:rFonts")
            srpr.append(srfonts)
        srfonts.set(qn("w:ascii"), EN_FONT)
        srfonts.set(qn("w:hAnsi"), EN_FONT)
        srfonts.set(qn("w:eastAsia"), CN_FONT)
        style.paragraph_format.space_after = Pt(0)
        style.paragraph_format.line_spacing = 1.0


def set_first_line_chars(paragraph, chars=200):
    """正文首行缩进 2 字符（w:ind firstLineChars=200）。"""
    ppr = paragraph._p.get_or_add_pPr()
    ind = ppr.find(qn("w:ind"))
    if ind is None:
        ind = OxmlElement("w:ind")
        ppr.append(ind)
    ind.set(qn("w:firstLineChars"), str(chars))


def add_field(paragraph, instr, placeholder="（请在 Word 中按 F9 更新域）"):
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    run._r.append(begin)
    run2 = paragraph.add_run()
    instr_el = OxmlElement("w:instrText")
    instr_el.set(qn("xml:space"), "preserve")
    instr_el.text = instr
    run2._r.append(instr_el)
    run3 = paragraph.add_run()
    sep = OxmlElement("w:fldChar")
    sep.set(qn("w:fldCharType"), "separate")
    run3._r.append(sep)
    run4 = paragraph.add_run(placeholder)
    set_run_fonts(run4, SIZES["body"])
    run5 = paragraph.add_run()
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run5._r.append(end)


def restart_page_numbering(section):
    sect_pr = section._sectPr
    pg = sect_pr.find(qn(CT_PAGE))
    if pg is None:
        pg = OxmlElement("w:pgNumType")
        sect_pr.append(pg)
    pg.set(qn("w:start"), "1")


def add_page_break_paragraph(document):
    paragraph = document.add_paragraph()
    run = paragraph.add_run()
    br = OxmlElement("w:br")
    br.set(qn("w:type"), "page")
    run._r.append(br)


def parse_blocks(text):
    lines = text.split("\n")
    blocks, i = [], 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped:
            i += 1
            continue
        if stripped.startswith("```"):
            fence, i, buf = stripped[:3], i + 1, []
            while i < len(lines) and not lines[i].strip().startswith(fence):
                buf.append(lines[i])
                i += 1
            i += 1
            blocks.append(("code", "\n".join(buf)))
            continue
        match = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if match:
            blocks.append(("h%d" % min(len(match.group(1)), 3), match.group(2).strip()))
            i += 1
            continue
        image = re.match(r"^!\[(.*?)\]\((.*?)\)$", stripped)
        if image:
            blocks.append(("image", (image.group(1), image.group(2))))
            i += 1
            continue
        if stripped.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            blocks.append(("table", rows))
            continue
        if re.match(r"^([-*+]|\d+[.)])\s+", stripped):
            items = []
            while i < len(lines) and re.match(r"^([-*+]|\d+[.)])\s+", lines[i].strip()):
                items.append(re.sub(r"^([-*+]|\d+[.)])\s+", "", lines[i].strip()))
                i += 1
            blocks.append(("list", items))
            continue
        blocks.append(("p", stripped))
        i += 1
    return blocks


def clean_inline(text):
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"(?<!\*)\*(?!\s)(.+?)(?<!\s)\*(?!\*)", r"\1", text)
    text = re.sub(r"`(.+?)`", r"\1", text)
    return text


def add_table(document, rows):
    if len(rows) < 2:
        return
    header = rows[0]
    body = [r for r in rows[2:]] if re.match(r"^:?-{2,}", rows[1][0] or "-") else rows[1:]
    table = document.add_table(rows=1, cols=len(header))
    table.style = "Table Grid"
    for index, text in enumerate(header):
        cell = table.rows[0].cells[index]
        cell.text = ""
        run = cell.paragraphs[0].add_run(clean_inline(text))
        set_run_fonts(run, SIZES["body"], bold=True)
    for row in body:
        cells = table.add_row().cells
        for index, text in enumerate(row[: len(header)]):
            cells[index].text = ""
            run = cells[index].paragraphs[0].add_run(clean_inline(text))
            set_run_fonts(run, SIZES["body"])
    document.add_paragraph()


def build(source, target, title, with_toc=True):
    blocks = parse_blocks(source.read_text(encoding="utf-8"))
    document = docx.Document()
    style_baseline(document)
    section = document.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.bottom_margin = Inches(1)
    section.left_margin = section.right_margin = Inches(1.25)

    for text, size in ((title, 16), ("", SIZES["body"])):
        paragraph = document.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if text:
            set_run_fonts(paragraph.add_run(text), size, bold=True)

    if with_toc:
        toc_section = document.add_section(WD_SECTION.NEW_PAGE)
        toc_section.top_margin = toc_section.bottom_margin = Inches(1)
        toc_section.left_margin = toc_section.right_margin = Inches(1.25)
        heading = document.add_paragraph()
        heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_run_fonts(heading.add_run("目录"), SIZES["h1"], bold=True)
        add_field(document.add_paragraph(), 'TOC \\o "1-3" \\h \\z \\u')

    body_section = document.add_section(WD_SECTION.NEW_PAGE)
    body_section.top_margin = body_section.bottom_margin = Inches(0.79)
    body_section.left_margin = body_section.right_margin = Inches(0.96)
    restart_page_numbering(body_section)
    # 封面与目录不编正文页码；正文节页脚放 PAGE 域
    section.footer.is_linked_to_previous = False
    toc_section_footer = document.sections[-2].footer if with_toc else None
    if toc_section_footer is not None:
        toc_section_footer.is_linked_to_previous = False
    body_section.footer.is_linked_to_previous = False
    footer_paragraph = body_section.footer.paragraphs[0]
    footer_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_field(footer_paragraph, "PAGE", "1")

    first_h1 = True
    for kind, payload in blocks:
        if kind == "h1":
            if not first_h1:
                add_page_break_paragraph(document)
            first_h1 = False
            paragraph = document.add_heading(clean_inline(payload), level=1)
            for run in paragraph.runs:
                set_run_fonts(run, SIZES["h1"], bold=True)
        elif kind in ("h2", "h3"):
            paragraph = document.add_heading(clean_inline(payload), level=int(kind[1]))
            for run in paragraph.runs:
                set_run_fonts(run, SIZES[kind], bold=True)
        elif kind == "p":
            paragraph = document.add_paragraph()
            set_run_fonts(paragraph.add_run(clean_inline(payload)), SIZES["body"])
            set_first_line_chars(paragraph)
        elif kind == "list":
            for item in payload:
                paragraph = document.add_paragraph(style="List Bullet")
                set_run_fonts(paragraph.add_run(clean_inline(item)), SIZES["body"])
        elif kind == "table":
            add_table(document, payload)
        elif kind == "code":
            for line in payload.split("\n"):
                paragraph = document.add_paragraph()
                run = paragraph.add_run(line)
                run.font.name = "Consolas"
                run.font.size = Pt(SIZES["body"])
        elif kind == "image":
            caption, rel = payload
            image_path = (source.parent / rel).resolve()
            paragraph = document.add_paragraph()
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            if image_path.is_file() and image_path.suffix.lower() in (".png", ".jpg", ".jpeg", ".bmp", ".gif"):
                paragraph.add_run().add_picture(str(image_path), width=Inches(5.98))
            else:
                set_run_fonts(paragraph.add_run("[缺图：%s]" % rel), SIZES["body"])
            caption_paragraph = document.add_paragraph()
            caption_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            set_run_fonts(caption_paragraph.add_run(caption), SIZES["caption"])
            document.add_paragraph()
    document.save(str(target))
    print("已生成:", target)
    print("下一步（reference 第 6、7 节）：在 Word 里更新目录域 → 收口 toc 1/2/3 字体 → 逐条核验。")
    return 0


def main():
    parser = argparse.ArgumentParser(description="md → docx 基线装配（离线）")
    parser.add_argument("source", help="md 源稿路径")
    parser.add_argument("-o", "--output", help="输出 docx 路径，默认与源稿同名")
    parser.add_argument("--title", default="", help="封面标题，默认取源稿首个一级标题")
    parser.add_argument("--no-toc", action="store_true", help="不插入目录节")
    args = parser.parse_args()
    source = Path(args.source).expanduser().resolve()
    if not source.is_file():
        print("源稿不存在：%s" % source, file=sys.stderr)
        return 2
    text = source.read_text(encoding="utf-8")
    title = args.title
    if not title:
        match = re.search(r"^#\s+(.+)$", text, re.M)
        title = match.group(1).strip() if match else source.stem
    target = Path(args.output).expanduser().resolve() if args.output else source.with_suffix(".docx")
    return build(source, target, title, with_toc=not args.no_toc)


if __name__ == "__main__":
    sys.exit(main())
