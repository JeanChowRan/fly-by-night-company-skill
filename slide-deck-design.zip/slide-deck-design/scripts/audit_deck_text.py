"""文案终检：占位变量 / 人名单位 / 草稿腔元描述 / 标题句法。

用法：python audit_deck_text.py deck.pptx [更多 pptx]

判定（【必改】必须为 0 才可交付）：
  A 占位与工程变量：undefined / null / NaN / None / TBD / TODO / 待补 / 待定 / xxx
  B 人名与单位：主讲人 / 汇报人 / 作者 / 导师 / 单位： / 部门 / 学院 / 大学 / 研究院 /
    研究所 / 有限公司 / 公司（材料里没有署名时，这些一律不该出现在页面上）
  C 草稿腔与元描述：左： 右： 中： / 一一对应 / 总-分 / 如图 / 见表 / 如图所示 /
    接下来 / 下面介绍 / 我们来看 / 本节 / 本页 / 本章对象 / 模块 XX
  D 标题句法：内容页标题必须是名词短语，≤22 字，且不含动词谓语句标记
    （让 / 使得 / 保持 / 收敛到 / 把 / 能够 / 从而 / 即可 / 实现 / 提升 / 降低 / 增强）

【提示】只提示不拦截：标题里出现 总览 / 总体分解 / 概述 / 综述，可能是在描述文档结构而非命名主题。
"""

import re
import os as _os
import sys

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor", "pylibs")
if _os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
from pathlib import Path

from pptx import Presentation
from pptx.util import Emu

PLACEHOLDERS = ["undefined", "null", "NaN", "None", "TBD", "TODO", "待补", "待定", "xxx", "XXX"]
IDENTITY = ["主讲人", "汇报人", "作者", "导师", "单位：", "部门", "学院", "大学",
            "研究院", "研究所", "有限公司", "公司"]
META = ["左：", "右：", "中：", "一一对应", "总-分", "如图", "见表", "如图所示",
        "接下来", "下面介绍", "我们来看", "本章", "模块 ", "本页要点"]
VERB_TITLE = ["让", "使得", "保持", "收敛到", "把", "能够", "从而", "即可",
              "实现", "提升", "降低", "增强", "减少", "增大"]
SOFT_TITLE = ["总览", "总体分解", "概述", "综述"]


def text_of(shape):
    if not shape.has_text_frame:
        return ""
    return shape.text_frame.text.strip()


def max_size(shape):
    sizes = [r.font.size.pt for p in shape.text_frame.paragraphs for r in p.runs if r.font.size]
    return max(sizes) if sizes else 0.0


def title_shape(slide, page_h, page_w):
    """取页面左上角字号最大的文本框作为该页标题。"""
    band = page_h * 0.14
    candidates = []
    for shape in slide.shapes:
        if not shape.has_text_frame or not shape.text_frame.text.strip():
            continue
        if shape.top is None or shape.left is None:
            continue
        if Emu(shape.top).inches > band or Emu(shape.left).inches > page_w * 0.6:
            continue
        candidates.append((max_size(shape), shape))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    total_issues, total_soft = 0, 0
    for target in sys.argv[1:]:
        path = Path(target)
        if not path.is_file():
            print(f"跳过（文件不存在）：{target}")
            continue
        issues, soft = [], []
        prs = Presentation(str(path))
        page_h = Emu(prs.slide_height).inches
        page_w = Emu(prs.slide_width).inches
        for index, slide in enumerate(prs.slides, 1):
            texts = [(text_of(sh), sh) for sh in slide.shapes if text_of(sh)]
            for text, _ in texts:
                flat = re.sub(r"\s+", "", text)
                for word in PLACEHOLDERS:
                    if word in flat:
                        issues.append(f"{index} A 占位/工程变量「{word}」：{text[:26]}")
                for word in IDENTITY:
                    if word in flat:
                        issues.append(f"{index} B 人名或单位「{word}」：{text[:26]}")
                for word in META:
                    if word in flat:
                        issues.append(f"{index} C 草稿腔/元描述「{word}」：{text[:26]}")
            try:
                notes = slide.speakerNotes.text_frame.text
            except Exception:  # noqa: BLE001
                notes = ""
            for word in PLACEHOLDERS:
                if word in notes:
                    issues.append(f"{index} A 备注含占位变量「{word}」")
            title = title_shape(slide, page_h, page_w)
            if title is None:
                continue
            size = max_size(title)
            value = re.sub(r"\s+", "", title.text_frame.text.strip())
            if size > 54:                       # 封面、章节页等 display 角色，只查人名单位
                continue
            if len(value) > 22:
                issues.append(f"{index} D 标题超过 22 字（{len(value)} 字）：{value}")
            for word in VERB_TITLE:
                if word in value:
                    issues.append(f"{index} D 标题是动词谓语句（含「{word}」）：{value}")
                    break
            for word in SOFT_TITLE:
                if word in value:
                    soft.append(f"{index} 标题含「{word}」，确认是否在描述文档结构：{value}")
        print(f"== {path.name}：必改 {len(issues)} 项，提示 {len(soft)} 项")
        for item in issues[:40]:
            print("  -", item)
        for item in soft[:10]:
            print("  ·", item)
        total_issues += len(issues)
        total_soft += len(soft)
    print(f"\n文案终检合计：必改 {total_issues} 项，提示 {total_soft} 项")
    return 0 if not total_issues else 1


if __name__ == "__main__":
    sys.exit(main())
