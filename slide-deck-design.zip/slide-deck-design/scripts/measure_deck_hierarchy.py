"""用同一把尺子量任一 PPTX 的"主/辅层级"，用于和范例对照。

输出：主块面积占比、其余块均值、主辅比、描边阶梯、内容覆盖率、字号档位。
范例实测：主块 26–40%、其余块 3–9%（主辅比 4:1–6:1）、主块描边 1.5–3pt、
辅块 0–1pt、主标题 22–24pt、辅文 11–14pt、内容覆盖率 60–90%。

用法：python measure_deck_hierarchy.py <pptx> [封面页,目录页,结束页]
"""

import re
import os as _os
import sys

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor", "pylibs")
if _os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
from pathlib import Path

from pptx import Presentation
from pptx.util import Emu


def measure(path, skip):
    prs = Presentation(str(path))
    page_area = Emu(prs.slide_width).inches * Emu(prs.slide_height).inches
    mains, rests, strokes, covers, sizes = [], [], set(), [], set()
    for index, slide in enumerate(prs.slides, 1):
        if index in skip:
            continue
        blocks = []
        for shape in slide.shapes:
            area = Emu(shape.width).inches * Emu(shape.height).inches / page_area
            if area <= 0.01:
                continue
            stroke = 0.0
            try:
                if shape.line.fill.type == 1:
                    stroke = round(shape.line.width.pt, 2)
                    strokes.add(stroke)
            except Exception:  # noqa: BLE001
                stroke = 0.0
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if run.font.size:
                            sizes.add(round(run.font.size.pt))
            blocks.append((area, stroke))
        if not blocks:
            continue
        blocks.sort(reverse=True)
        mains.append(blocks[0][0])
        rests.append(sum(b[0] for b in blocks[1:]) / max(1, len(blocks) - 1))
        covers.append(sum(b[0] for b in blocks))
    average = lambda seq: sum(seq) / len(seq) if seq else 0.0  # noqa: E731
    print(f"文件：{Path(path).name}　计 {len(mains)} 页")
    print(f"  主块占比 均值 {average(mains)*100:5.1f}%　（范例 26–40%）")
    print(f"  其余块均值      {average(rests)*100:5.1f}%　（范例 3–9%）")
    print(f"  主辅比 1 : {average(rests)/max(1e-6, average(mains)):.2f}　（范例 1:0.15–0.30）")
    print(f"  描边阶梯 {sorted(strokes)} pt　（范例 主 1.5–3 / 辅 0–1）")
    print(f"  内容覆盖率 均值 {average(covers)*100:5.1f}%　（范例 60–90%）")
    print(f"  字号取值 {sorted(sizes, reverse=True)}　（范例全篇 8–13 个取值；页内语义角色应 ≤4）")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    skip = {1, 2, 39}
    if len(sys.argv) > 2:
        skip = {int(item) for item in re.split(r"[,，\s]+", sys.argv[2]) if item.strip()}
    measure(sys.argv[1], skip)
    return 0


if __name__ == "__main__":
    sys.exit(main())
