"""版面机械约束自检：无图页 / 直角矩形 / 白边 / 越界 / 文字溢出 / 最大空置块。

用法：python audit_deck_visual.py <pptx> [封面页,目录页]
默认把第 1、2 页视为封面与目录（可不带图）。
"""

import io
import os
import re
import sys
import zipfile

_VENDOR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "vendor", "pylibs")
if os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
from pathlib import Path

from PIL import Image, ImageFont
from pptx import Presentation
from pptx.util import Emu

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"


def inches(value):
    return Emu(value).inches


def text_height(shape, cjk_font, cjk_bold):
    """估算文本框所需高度（英寸），用于发现文字溢出。"""
    width = inches(shape.width) * 96
    needed = 0.0
    for para in shape.text_frame.paragraphs:
        text = "".join(run.text for run in para.runs)
        if not text:
            continue
        run = para.runs[0]
        size = run.font.size.pt if run.font.size else 18
        bold = bool(run.font.bold)
        path = cjk_bold if bold and Path(cjk_bold).exists() else cjk_font
        try:
            font = ImageFont.truetype(path, max(6, int(round(size * 96 / 72))))
        except Exception:  # noqa: BLE001
            needed += size * 96 / 72 * 1.2
            continue
        lines, current = 1, ""
        for char in text:
            if font.getlength(current + char) <= max(10, width - 4) or not current:
                current += char
            else:
                lines += 1
                current = char
        needed += lines * size * 96 / 72 * (para.line_spacing or 1.2) / 96
    return needed


def empty_band(shape_boxes, page_height):
    """找出页面内最大的无内容纵向空带（英寸）。"""
    occupied = [False] * int(page_height * 20)
    for top, height in shape_boxes:
        start = max(0, int(top * 20))
        end = min(len(occupied), int((top + height) * 20))
        for index in range(start, end):
            occupied[index] = True
    longest = current = 0
    for flag in occupied:
        current = 0 if flag else current + 1
        longest = max(longest, current)
    return longest / 20


def _cjk_fonts():
    """跨平台中文字体候选（相对环境变量解析，不写死绝对路径）。

    找不到任何候选时返回占位路径，文本高度检查自动退化为估算，不中断审计。
    """
    roots = [os.path.join(os.environ.get("WINDIR", ""), "Fonts") if os.environ.get("WINDIR") else "",
             "/usr/share/fonts/truetype", "/usr/share/fonts",
             os.path.expanduser("~/Library/Fonts"), os.path.expanduser("~/.fonts")]
    names = ("msyh.ttc", "msyhbd.ttc", "simhei.ttf", "NotoSansCJK-Regular.ttc", "DejaVuSans.ttf")
    found = []
    for root in roots:
        if not root:
            continue
        for name in names:
            path = os.path.join(root, name)
            if os.path.exists(path) and path not in found:
                found.append(path)
    if not found:
        return "__cjk-font-not-found__", "__cjk-font-not-found__"
    return found[0], found[1] if len(found) > 1 else found[0]


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    deck = Path(sys.argv[1])
    exempt = {1, 2}
    if len(sys.argv) > 2:
        exempt = {int(item) for item in re.split(r"[,，\s]+", sys.argv[2]) if item.strip()}
    fonts = _cjk_fonts()

    prs = Presentation(str(deck))
    page_w, page_h = inches(prs.slide_width), inches(prs.slide_height)
    no_picture, off_slide, overflow, letterbox, blank = [], [], [], [], []

    for index, slide in enumerate(prs.slides, 1):
        shapes = list(slide.shapes)
        pictures = [s for s in shapes if s.shape_type is not None and "PICTURE" in str(s.shape_type)]
        if index not in exempt and not pictures:
            no_picture.append(index)
        for shape in shapes:
            if (shape.top < 0 or shape.left < 0 or shape.top + shape.height > prs.slide_height + 1000
                    or shape.left + shape.width > prs.slide_width + 1000):
                off_slide.append((index, shape.name))
            if "PICTURE" in str(shape.shape_type):
                box = inches(shape.width) / inches(shape.height)
                image = shape.image.size[0] / shape.image.size[1]
                if abs(box - image) > 0.02:
                    letterbox.append((index, shape.name, round(box, 3), round(image, 3)))
            if shape.has_text_frame and shape.text_frame.text.strip():
                if text_height(shape, *fonts) > inches(shape.height) * 1.02:
                    overflow.append((index, shape.name))
        band = empty_band([(inches(s.top), inches(s.height)) for s in shapes], page_h)
        if index not in (1, 2) and band > 1.4:
            blank.append((index, round(band, 2)))

    with zipfile.ZipFile(deck) as archive:
        straight = []
        for name in archive.namelist():
            if re.match(r"ppt/slides/slide\d+\.xml$", name):
                text = archive.read(name).decode("utf-8")
                count = len(re.findall(r'prstGeom prst="rect"', text))
                box = len(re.findall(r"<p:sp>", text))
                if count > box:                     # 除文本框与图片框外的直角形状
                    straight.append((name.split("/")[-1], count - box))

    def report(title, items):
        flag = "OK" if not items else "待修"
        print(f"[{flag}] {title}：{len(items)}")
        for item in items[:12]:
            print(f"        {item}")

    print(f"画布 {page_w:.2f}×{page_h:.2f} in，共 {len(prs.slides)} 页，免除页 {sorted(exempt)}")
    report("无图页（除封面/目录）", no_picture)
    report("直角形状（含图片框，应为 0）", straight)
    report("白边（图框与图长宽比不一致）", letterbox)
    report("越界形状", off_slide)
    report("疑似文字溢出", overflow)
    report("纵向空置带 > 1.4 in", blank)
    return 0


if __name__ == "__main__":
    sys.exit(main())
