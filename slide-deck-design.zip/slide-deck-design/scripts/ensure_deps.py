# -*- coding: utf-8 -*-
"""检查并按需离线补齐技能自带依赖。

技能自带 `vendor/pylibs`（已装好的包，供打包时的 Python 版本直接用），
以及 `vendor/wheels/<平台标签>/` 下的 wheel 包（供其他版本离线安装）。
各审计脚本启动时会自动把 `vendor/pylibs` 追加进 sys.path（本机已有依赖优先）。

用法：python scripts/ensure_deps.py [--install]
  不带 --install：只自检并打印结论；
  带 --install：缺失时用自带 wheel 离线安装到 vendor/pylibs。
"""
import argparse
import glob
import os
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VENDOR = os.path.join(ROOT, "vendor", "pylibs")
WHEELS_ROOT = os.path.join(ROOT, "vendor", "wheels")
REQUIRED = ("pptx", "lxml", "PIL", "xlsxwriter")

sys.path.append(VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的


def missing_modules():
    missing = []
    for name in REQUIRED:
        try:
            __import__(name)
            print("  [OK] %s" % name)
        except Exception as exc:  # noqa: BLE001
            print("  [缺失] %s -> %s" % (name, exc))
            missing.append(name)
    return missing


def wheel_dirs():
    if not os.path.isdir(WHEELS_ROOT):
        return []
    return sorted(path for path in glob.glob(os.path.join(WHEELS_ROOT, "*")) if os.path.isdir(path))


def install_from_wheels(packages):
    dirs = wheel_dirs()
    if not dirs:
        return False
    tag = "py%d%d" % (sys.version_info[0], sys.version_info[1])
    preferred = [path for path in dirs if tag in os.path.basename(path).lower()]
    src = preferred[0] if preferred else dirs[-1]
    cmd = [sys.executable, "-m", "pip", "install", "--no-index",
           "--find-links", src, "--target", VENDOR, "--upgrade"] + list(packages)
    print("\n离线安装：", " ".join(cmd))
    return subprocess.call(cmd) == 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--install", action="store_true", help="缺失时用自带 wheel 离线安装")
    args = parser.parse_args()

    print("技能根目录：", ROOT)
    print("Python：", sys.version.split()[0], sys.executable)
    print("自带依赖目录：", VENDOR, "存在" if os.path.isdir(VENDOR) else "缺失")
    print("自带 wheel 目录：", wheel_dirs() or "无")

    missing = missing_modules()
    if not missing:
        print("\n依赖自检通过，可直接运行 scripts 下的审计脚本。")
        return 0

    if args.install and install_from_wheels(missing):
        print("\n离线安装完成，重新自检：")
        if not missing_modules():
            print("\n依赖自检通过，可直接运行 scripts 下的审计脚本。")
            return 0

    print("\n处理办法（三选一）：")
    print("  1) 离线自带包：`python scripts/ensure_deps.py --install`（用 vendor/wheels 里对应平台的 wheel）")
    print("  2) 自带 plain wheel：`python -m pip install --no-index --find-links vendor/wheels/<平台标签> %s`"
          % " ".join(missing))
    print("  3) 联网安装：`python -m pip install %s`" % " ".join(missing))
    print("说明：vendor/pylibs 里已装好的包与打包时的 Python 版本绑定；")
    print("      版本不一致时按第 1 或第 3 条安装到同一目录即可。")
    return 1


raise SystemExit(main())
