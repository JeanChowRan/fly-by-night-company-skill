"""分析范例的"本体→形状"分布：每页文本块数量、单块段落数、形状类型与几何。"""

import sys
import os as _os

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor", "pylibs")
if _os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
from collections import Counter
from pathlib import Path

from pptx import Presentation
from pptx.util import Emu

# 用命令行指定待测 PPTX；不写任何固定范例路径（避免把个人文件名/单位带进技能）。


def cm(value):
    return round(Emu(value).cm, 2) if value is not None else 0.0


def main():
    targets = sys.argv[1:]
    if not targets:
        print(__doc__)
        print("用法：python audit_deck_blocks.py <deck.pptx> [更多 pptx]")
        return 2
    for label, path in ((Path(item).stem, item) for item in targets):
        if not Path(path).exists():
            print(f"跳过（文件不存在）：{path}")
            continue
        prs = Presentation(path)
        per_page_blocks, per_page_shapes = [], []
        para_counts, one_para, multi_para = Counter(), 0, 0
        shapes_with_text = 0
        widths = []
        for slide in prs.slides:
            blocks = 0
            for shape in slide.shapes:
                shapes_with_text += 1 if shape.has_text_frame and shape.text_frame.text.strip() else 0
                if not shape.has_text_frame:
                    continue
                paras = [p for p in shape.text_frame.paragraphs if "".join(r.text for r in p.runs).strip()]
                if not paras:
                    continue
                blocks += 1
                para_counts[len(paras)] += 1
                if len(paras) == 1:
                    one_para += 1
                else:
                    multi_para += 1
                widths.append(cm(shape.width))
            per_page_blocks.append(blocks)
            per_page_shapes.append(len(slide.shapes))
        per_page_blocks.sort()
        per_page_shapes.sort()
        print(f"\n=== {label} ===")
        print(f"每页文本块数: 中位 {per_page_blocks[len(per_page_blocks)//2]}　最多 {per_page_blocks[-1]}")
        print(f"每页形状总数: 中位 {per_page_shapes[len(per_page_shapes)//2]}　最多 {per_page_shapes[-1]}")
        print(f"单段落文本块 {one_para} 个，多段落文本块 {multi_para} 个")
        print("块内段落数分布:", para_counts.most_common(6))
        if widths:
            widths.sort()
            print(f"文本块宽度(cm): 中位 {widths[len(widths)//2]}　最小 {widths[0]}　最大 {widths[-1]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
