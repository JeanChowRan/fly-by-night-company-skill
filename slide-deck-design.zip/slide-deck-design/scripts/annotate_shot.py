# -*- coding: utf-8 -*-
"""给运行截图加框图标注，输出自带底图的单文件 SVG（离线可用、仅用标准库）。

用法：
    python scripts/annotate_shot.py --base shot.png --spec spec.json --out annotated.svg
    python scripts/annotate_shot.py --base shot.png --spec spec.json --out a.svg \
        --display-width-in 6 --target-pt 14     # 按"放进 PPT 后被缩放"反推字号

规格 JSON（全部坐标以底图像素为单位）：
{
  "notes": [
    {
      "rect": [x, y, w, h],            # 标注框
      "number": "1",                   # 编号徽标（可省略）
      "color": "#22D3EE",              # 默认青色；关键证据用 #F59E0B
      "chip": [x, y],                  # 标签片左上角
      "title": "区块名",
      "detail": "一句话说明"           # 可省略
    }
  ],
  "leaders": [[x1, y1, x2, y2, "#22D3EE"]],   # 可选引线
  "extras":  [ {同 notes 的 chip 字段但无 rect} ]  # 可选：补充说明片
}

字号默认取"实测下限"：标题 34 px、说明 24 px（对应 1920 宽截图放进约 6 in 宽图框的档位，再小就看不见）。
需要让标注与页面正文同档时，用 --target-pt 按公式反推：
    图内 px = 目标放映 pt × 画布宽(px) ÷ (版面显示宽(in) × 72)
"""
import argparse
import base64
import json
import os
import sys

DEFAULT_INK = "#04122E"
DEFAULT_TEXT = "#EAF7FF"
FONT = "Microsoft YaHei, SimSun, sans-serif"


def esc(text):
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def box(rect, color, radius=22, width=7):
    x, y, w, h = rect
    return (
        '<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="%s" '
        'stroke-width="%d" stroke-opacity="0.28"/>' % (x, y, w, h, radius, color, width + 12)
        + '<rect x="%d" y="%d" width="%d" height="%d" rx="%d" fill="none" stroke="%s" '
          'stroke-width="%d" stroke-opacity="0.98"/>' % (x, y, w, h, radius, color, width)
    )


def badge(cx, cy, number, color):
    return (
        '<circle cx="%d" cy="%d" r="40" fill="%s" stroke="%s" stroke-width="6"/>'
        % (cx, cy, color, DEFAULT_INK)
        + '<text x="%d" y="%d" font-family="%s" font-size="42" font-weight="bold" fill="%s" '
          'text-anchor="middle">%s</text>' % (cx, cy + 15, FONT, DEFAULT_INK, esc(number))
    )


def chip(x, y, title, detail, color, title_px, detail_px):
    width = max(int(title_px * 12.6), 430)
    if detail:
        width = max(width, int(len(str(detail)) * detail_px * 1.05) + 60)
    width = max(width, int(len(str(title)) * title_px * 1.05) + 60)
    height = int(title_px + detail_px + 70) if detail else int(title_px + 58)
    parts = [
        '<rect x="%d" y="%d" width="%d" height="%d" rx="18" fill="%s" fill-opacity="0.95" '
        'stroke="%s" stroke-width="5"/>' % (x, y, width, height, DEFAULT_INK, color),
        '<rect x="%d" y="%d" width="14" height="%d" rx="7" fill="%s"/>'
        % (x + 10, y + 14, height - 28, color),
        '<text x="%d" y="%d" font-family="%s" font-size="%d" font-weight="bold" fill="%s">%s</text>'
        % (x + 40, y + int(title_px * 1.5), FONT, title_px, DEFAULT_TEXT, esc(title)),
    ]
    if detail:
        parts.append(
            '<text x="%d" y="%d" font-family="%s" font-size="%d" fill="%s" fill-opacity="0.92">%s</text>'
            % (x + 40, y + int(title_px * 1.5) + int(detail_px * 1.6), FONT, detail_px,
               DEFAULT_TEXT, esc(detail)))
    return "\n".join(parts)


def leader(x1, y1, x2, y2, color):
    return ('<path d="M%d %d L%d %d" fill="none" stroke="%s" stroke-width="6" '
            'stroke-opacity="0.95" stroke-dasharray="18 14" stroke-linecap="round"/>'
            % (x1, y1, x2, y2, color))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True, help="底图（运行截图 PNG/JPG）")
    parser.add_argument("--spec", required=True, help="标注规格 JSON")
    parser.add_argument("--out", required=True, help="输出 SVG")
    parser.add_argument("--display-width-in", type=float, default=6.0,
                        help="素材在版面上的显示宽度（英寸），默认 6")
    parser.add_argument("--target-pt", type=float, default=None,
                        help="目标放映字号（pt）：给了就按公式反推，不给则用实测下限 34/24 px")
    parser.add_argument("--title-px", type=float, default=None, help="直接指定标题字号（px）")
    parser.add_argument("--detail-px", type=float, default=None, help="直接指定说明字号（px）")
    args = parser.parse_args()

    with open(args.base, "rb") as handle:
        raw = handle.read()
    mime = "image/jpeg" if args.base.lower().endswith((".jpg", ".jpeg")) else "image/png"
    encoded = base64.b64encode(raw).decode("ascii")

    width, height = 1920, 1080
    try:
        import struct
        if mime == "image/png":
            width, height = struct.unpack(">II", raw[16:24])
    except Exception:  # noqa: BLE001
        pass

    if args.title_px:
        title_px = int(args.title_px)
    elif args.target_pt:
        title_px = max(34, int(round(args.target_pt * width / (args.display_width_in * 72))))
    else:
        title_px = 34
    detail_px = int(args.detail_px) if args.detail_px else max(24, int(round(title_px * 0.7)))

    spec = json.load(open(args.spec, encoding="utf-8"))
    pieces = []
    for note in spec.get("notes", []):
        color = note.get("color", "#22D3EE")
        rect = note["rect"]
        pieces.append(box(rect, color, int(note.get("radius", 22)), int(note.get("stroke", 7))))
        if note.get("number"):
            pieces.append(badge(rect[0] + int(note.get("badge_offset", 46)),
                                rect[1] + int(note.get("badge_offset", 46)),
                                note["number"], color))
        if note.get("title"):
            chip_at = note.get("chip", [rect[0], rect[1] - 150])
            pieces.append(chip(chip_at[0], chip_at[1], note["title"], note.get("detail"),
                               color, title_px, detail_px))
    for item in spec.get("leaders", []):
        pieces.append(leader(item[0], item[1], item[2], item[3], item[4] if len(item) > 4 else "#22D3EE"))
    for extra in spec.get("extras", []):
        color = extra.get("color", "#22D3EE")
        chip_at = extra.get("chip", [40, 40])
        pieces.append(chip(chip_at[0], chip_at[1], extra.get("title", ""), extra.get("detail"),
                           color, title_px, detail_px))

    svg = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" '
        'font-family="SimSun, Times New Roman, serif">' % (width, height, width, height),
        '<image x="0" y="0" width="%d" height="%d" href="data:%s;base64,%s"/>'
        % (width, height, mime, encoded),
    ]
    svg.extend(pieces)
    svg.append("</svg>")
    with open(args.out, "w", encoding="utf-8") as handle:
        handle.write("\n".join(svg))
    print("已输出 %s（标题 %d px / 说明 %d px，画布 %dx%d）"
          % (args.out, title_px, detail_px, width, height))
    print("提示：把它转成 PNG 再插入 PPT；SVG 自带底图，断网可显示，无外部依赖。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
