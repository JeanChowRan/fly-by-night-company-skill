"""逐页逐行逐框导出：坐标(cm)、字号、字重、颜色、对齐、缩进 + 每行文本。

用法: python dump_lines.py <pptx> <页码,逗号分隔>
"""

import sys
import os as _os

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor", "pylibs")
if _os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
from pathlib import Path

from pptx import Presentation
from pptx.util import Emu


def cm(value):
    return round(Emu(value).cm, 2) if value is not None else 0.0


def main():
    path, pages = sys.argv[1], [int(p) for p in sys.argv[2].split(",")]
    prs = Presentation(path)
    print(f"文件: {Path(path).name}  共 {len(prs.slides)} 页  页面 {cm(prs.slide_width)}×{cm(prs.slide_height)} cm")
    for index in pages:
        slide = list(prs.slides)[index - 1]
        print(f"\n===== 第 {index} 页 =====")
        for shape in slide.shapes:
            kind = str(shape.shape_type).split(" ")[0] if shape.shape_type else "?"
            box = f"({cm(shape.left)},{cm(shape.top)},{cm(shape.width)}×{cm(shape.height)})"
            if not shape.has_text_frame or not shape.text_frame.text.strip():
                print(f"  {kind:<12} {box}")
                continue
            print(f"  {kind:<12} {box}")
            for para in shape.text_frame.paragraphs:
                text = "".join(run.text for run in para.runs).strip()
                if not text:
                    continue
                run = para.runs[0]
                size = round(run.font.size.pt) if run.font.size else 0
                bold = "粗" if run.font.bold else "　"
                try:
                    color = str(run.font.color.rgb) if run.font.color and run.font.color.type is not None else "主题"
                except AttributeError:
                    color = "主题"
                hl = "黄底" if "<a:highlight>" in run._r.xml else "　　"
                align = {"CENTER (2)": "居中", "RIGHT (3)": "右", "JUSTIFY (4)": "两端", "None": "默认"}.get(
                    str(para.alignment), str(para.alignment)
                )
                print(f"      └ {size:>2}pt {bold}{hl} #{color:<8} {align:<4} L{para.level} | {text[:26]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
