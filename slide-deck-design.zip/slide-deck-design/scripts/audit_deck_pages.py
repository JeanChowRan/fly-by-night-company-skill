"""通用拆解：章节结构、页面类型、每页元素/字数/图数、底部总结条、关键词加粗统计。

用法: python analyze_ppt.py <pptx 路径>
"""

import re
import os as _os
import sys

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor", "pylibs")
if _os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
from collections import Counter
from pathlib import Path

from pptx import Presentation
from pptx.util import Emu


def cm(value):
    return round(Emu(value).cm, 2) if value is not None else 0.0


def analyze(path):
    prs = Presentation(str(path))
    slide_h, slide_w = cm(prs.slide_height), cm(prs.slide_width)
    print(f"文件: {Path(path).name}   {len(prs.slides)} 页   {slide_w}×{slide_h} cm")
    kinds = Counter()
    bands, highlight_pages = 0, 0
    body_chars = []

    for index, slide in enumerate(prs.slides, 1):
        shapes = list(slide.shapes)
        pics = [s for s in shapes if s.shape_type is not None and "PICTURE" in str(s.shape_type)]
        tables = [s for s in shapes if getattr(s, "has_table", False) and s.has_table]
        ole = [s for s in shapes if "OLE" in str(s.shape_type)]
        texts = [s.text_frame.text.strip() for s in shapes if s.has_text_frame and s.text_frame.text.strip()]
        chars = sum(len(t) for t in texts)
        title = max(texts, key=len)[:30] if texts else ""

        band, band_text = False, ""
        highlights = reds = blues = 0
        for shape in shapes:
            try:
                if shape.fill.type == 1 and cm(shape.top) > slide_h * 0.82 and cm(shape.width) > slide_w * 0.5:
                    band = True
                    if shape.has_text_frame and shape.text_frame.text.strip():
                        band_text = shape.text_frame.text.strip()
            except Exception:  # noqa: BLE001
                pass
            if shape.has_text_frame:
                if cm(shape.top) > slide_h * 0.82 and shape.text_frame.text.strip():
                    band_text = shape.text_frame.text.strip()
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        xml = run._r.xml
                        if "<a:highlight>" in xml:
                            highlights += 1
                        if run.font.bold and run.font.color is not None and run.font.color.type is not None:
                            try:
                                color = str(run.font.color.rgb)
                            except AttributeError:
                                color = ""  # 主题色（SchemeColor）不计入
                            if color in ("C00000", "FF0000"):
                                reds += 1
                            elif color in ("0070C0", "005CAC", "002060"):
                                blues += 1
        if band:
            bands += 1
        if highlights or reds:
            highlight_pages += 1

        kind = ("封面" if index == 1 else
                "结束" if index == len(prs.slides) else
                "目录/章节" if len(shapes) <= 12 and not pics and not tables else
                "表格页" if tables else
                "图墙" if len(pics) >= 6 else
                "图文页" if pics else "文字页")
        kinds[kind] += 1
        if kind in ("文字页", "图文页", "表格页"):
            body_chars.append(chars)
        print(
            f"{index:>3} [{kind:<4}] 元素{len(shapes):>3} 图{len(pics):>2} 表{len(tables)} OLE{len(ole)} "
            f"字{chars:>4} 黄{highlights:>2} 红{reds:>2} 蓝{blues:>2} "
            f"{'蓝条' if band else '    '} | {title}"
        )
        if band_text and len(band_text) < 40:
            print(f"      ↳ 底部条: {band_text}")

    print(f"\n页面类型分布: {dict(kinds)}")
    if body_chars:
        body_chars.sort()
        print(f"内容页字数: 最少 {body_chars[0]}、中位 {body_chars[len(body_chars)//2]}、最多 {body_chars[-1]}")
    print(f"底部总结条页数: {bands}；含黄/红强调的页数: {highlight_pages}")
    return 0


if __name__ == "__main__":
    sys.exit(analyze(sys.argv[1]))
