"""一键跑完交付前五查 + 主辅层级指标，并按"必改项是否归零"给结论。

用法：
    python audit_deck_all.py deck.pptx [免除页，如 1,2,39]

分工：
    1 文案终检   audit_deck_text.py     必改项必须为 0
    2 机械约束   audit_deck_visual.py   无图页/直角/白边/越界/文字溢出/空置带 必须为 0
    3 版式后校验 audit_deck_layout.py   重叠/压图/跑出卡片/铺不满 必须为 0
    4 背景包含   audit_deck_contain.py  必须为 0
    5 间距       audit_deck_spacing.py  只拦"边距内无内容"这类硬问题，其余为人工确认项
    6 层级指标   measure_deck_hierarchy.py 只打印指标，须人工对照范例区间（超界要写原因）
"""

import re
import os as _os
import sys as _sys

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor", "pylibs")
if _os.path.isdir(_VENDOR) and _VENDOR not in _sys.path:
    _sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run(script, args):
    proc = subprocess.run([sys.executable, "-B", "-X", "utf8", str(HERE / script), *args],
                          capture_output=True, text=True, encoding="utf-8", errors="replace")
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    deck = str(Path(sys.argv[1]).resolve())
    exempt = sys.argv[2] if len(sys.argv) > 2 else "1,2,39"
    hard, soft = [], []

    code, out = run("audit_deck_text.py", [deck])
    print("=" * 68, "\n[1/6] 文案终检\n" + out.rstrip())
    matched = re.findall(r"必改 (\d+) 项", out)
    if matched and int(matched[0]) != 0:
        hard.append(f"文案终检必改 {matched[0]} 项")

    code, out = run("audit_deck_visual.py", [deck, exempt])
    print("=" * 68, "\n[2/6] 版面机械约束\n" + out.rstrip())
    pending = [line for line in out.splitlines() if line.strip().startswith("[待修]")]
    hard += [f"机械约束：{line.strip()}" for line in pending]

    code, out = run("audit_deck_layout.py", [deck])
    print("=" * 68, "\n[3/6] 版式后校验\n" + out.rstrip())
    m = re.search(r"问题 (\d+) 项", out)
    if m and int(m.group(1)) != 0:
        hard.append(f"版式后校验 {m.group(1)} 项")

    code, out = run("audit_deck_contain.py", [deck])
    print("=" * 68, "\n[4/6] 背景包含\n" + out.rstrip())
    m = re.search(r"问题 (\d+) 项", out)
    if m and int(m.group(1)) != 0:
        hard.append(f"背景包含 {m.group(1)} 项")

    code, out = run("audit_deck_spacing.py", [deck])
    print("=" * 68, "\n[5/6] 间距\n" + out.rstrip())
    blocking = [line for line in out.splitlines() if "且无内容" in line]
    confirm = [line for line in out.splitlines() if "确认是否合规" in line]
    hard += [f"间距：{line.strip()}" for line in blocking]
    if confirm:
        soft.append(f"间距有 {len(confirm)} 条“边距内有文字”需人工确认")

    code, out = run("measure_deck_hierarchy.py", [deck, exempt.replace(",", " ")])
    print("=" * 68, "\n[6/6] 主辅层级指标\n" + out.rstrip())

    print("=" * 68)
    if hard:
        print(f"结论：不通过，必改 {len(hard)} 项")
        for item in hard:
            print("  -", item)
    else:
        print("结论：五查全过（文案终检必改 0、机械约束 0、版式 0、包含 0、间距无硬问题）")
    for item in soft:
        print("  ·", item)
    print("提示：层级指标需人工对照范例区间；覆盖率超区间要写明原因（如主图框与图片重叠）。")
    return 1 if hard else 0


if __name__ == "__main__":
    sys.exit(main())
