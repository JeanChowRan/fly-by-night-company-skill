"""背景包含审计：底板/背景形状必须完整包住它承载的元素，并留 ≥ 边距。

判定：形状 A 的中心落在形状 B（有底色、非文本框）内 → A 属于 B 承载 → 要求
A 的包围盒完全落在 B 内，且四边留出 ≥ --margin（英寸，默认 0.06）。

用法：python audit_deck_contain.py deck.pptx [--margin 0.06]
"""

import argparse
import os as _os
import sys

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor", "pylibs")
if _os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
from pathlib import Path

from pptx import Presentation
from pptx.util import Emu


def box(shape):
    return (Emu(shape.left).inches, Emu(shape.top).inches,
            Emu(shape.left + shape.width).inches, Emu(shape.top + shape.height).inches)


def filled(shape):
    try:
        return shape.fill.type is not None and int(shape.fill.type) == 1
    except Exception:  # noqa: BLE001
        return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("deck")
    parser.add_argument("--margin", type=float, default=0.06)
    args = parser.parse_args()
    prs = Presentation(args.deck)
    issues = []
    for index, slide in enumerate(prs.slides, 1):
        shapes = [s for s in slide.shapes if s.width and s.height]
        for outer in shapes:
            if not filled(outer) or getattr(outer, "has_text_frame", False) and outer.text_frame.text.strip():
                continue
            ob = box(outer)
            if (ob[2] - ob[0]) < 2 or (ob[3] - ob[1]) < 1:
                continue
            for inner in shapes:
                if inner is outer:
                    continue
                ib = box(inner)
                cx, cy = (ib[0] + ib[2]) / 2, (ib[1] + ib[3]) / 2
                if not (ob[0] <= cx <= ob[2] and ob[1] <= cy <= ob[3]):
                    continue
                slack = min(ib[0] - ob[0], ob[2] - ib[2], ib[1] - ob[1], ob[3] - ib[3])
                if slack < args.margin - 1e-6:
                    issues.append(
                        f"第 {index} 页：承载元素越出背景或边距不足 "
                        f"(边距 {slack:.3f} in < {args.margin} in) 背景 {tuple(round(v, 2) for v in ob)}"
                        f" ← 元素 {tuple(round(v, 2) for v in ib)}")
    print(f"检查 {len(prs.slides)} 页，背景包含问题 {len(issues)} 项")
    for item in issues[:30]:
        print("  -", item)
    return 0 if not issues else 1


if __name__ == "__main__":
    sys.exit(main())
