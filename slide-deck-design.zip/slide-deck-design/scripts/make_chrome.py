# -*- coding: utf-8 -*-
"""生成封面 / 章节页 / 标题栏的矢量底纹（纯几何、无文字、内联、断网可显示）。

用法：
    python scripts/make_chrome.py --kind cover    --width 1920 --height 1080 --out cover.svg
    python scripts/make_chrome.py --kind chapter  --width 1920 --height 1080 --out chapter.svg
    python scripts/make_chrome.py --kind titlebar --width 1280 --height 74   --out titlebar.svg
仅用标准库；输出 SVG 不含任何外链，可直接渲染成 PNG 后插入 PPT。
"""
import argparse
import os

FONT_DECL = "SimSun, Times New Roman, serif"

NODES = [
    (0.59, 0.17), (0.69, 0.13), (0.78, 0.21), (0.88, 0.15), (0.95, 0.26),
    (0.64, 0.35), (0.74, 0.42), (0.84, 0.38), (0.92, 0.47), (0.70, 0.59),
    (0.81, 0.60), (0.91, 0.65), (0.67, 0.75), (0.79, 0.78),
]
EDGES = [(0, 1), (1, 2), (2, 3), (3, 4), (1, 5), (5, 6), (6, 7), (7, 8), (5, 9),
         (9, 10), (10, 11), (9, 12), (12, 13), (13, 11), (6, 10), (8, 11)]


def svg_open(width, height):
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" '
            'font-family="%s">' % (width, height, width, height, FONT_DECL))


def cover(width, height, primary, accent):
    parts = [
        '<defs>',
        '<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">',
        '<stop offset="0" stop-color="%s"/><stop offset="1" stop-color="#061020"/></linearGradient>' % primary,
        '<radialGradient id="glow" cx="0.5" cy="0.5" r="0.5">',
        '<stop offset="0" stop-color="%s" stop-opacity="0.5"/>' % accent,
        '<stop offset="0.65" stop-color="%s" stop-opacity="0.18"/>' % accent,
        '<stop offset="1" stop-color="%s" stop-opacity="0"/></radialGradient>' % primary,
        '<pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">',
        '<path d="M40 0H0V40" fill="none" stroke="%s" stroke-width="1" opacity="0.16"/></pattern>' % accent,
        '<linearGradient id="rule" x1="0" y1="0" x2="1" y2="0">',
        '<stop offset="0" stop-color="%s" stop-opacity="0.95"/><stop offset="1" stop-color="%s" stop-opacity="0"/>'
        % (accent, accent),
        '</linearGradient>',
        '</defs>',
        '<rect width="%d" height="%d" fill="url(#bg)"/>' % (width, height),
        '<rect width="%d" height="%d" fill="url(#grid)"/>' % (width, height),
        '<ellipse cx="%.0f" cy="%.0f" rx="%.0f" ry="%.0f" fill="url(#glow)"/>'
        % (width * 0.62, height * 0.30, width * 0.22, height * 0.28),
    ]
    lines = []
    for a, b in EDGES:
        lines.append('M%.0f %.0f L%.0f %.0f' % (NODES[a][0] * width, NODES[a][1] * height,
                                                NODES[b][0] * width, NODES[b][1] * height))
    parts.append('<g stroke="%s" stroke-width="1.2" opacity="0.45" fill="none"><path d="%s"/></g>'
                 % (accent, " ".join(lines)))
    parts.append('<g fill="%s" opacity="0.7">' % accent)
    for fx, fy in NODES:
        parts.append('<circle cx="%.0f" cy="%.0f" r="5"/>' % (fx * width, fy * height))
    parts.append('</g>')
    parts.append('<rect x="0" y="%d" width="%d" height="1" fill="%s" opacity="0.35"/>'
                 % (height - 54, width, accent))
    parts.append('<rect x="0" y="%d" width="%.0f" height="2" fill="url(#rule)"/>'
                 % (height - 54, width * 0.44))
    for i, frac in enumerate((0.0, 0.04, 0.10, 0.94)):
        parts.append('<rect x="%.0f" y="%d" width="%.0f" height="3" fill="%s" opacity="0.5"/>'
                     % (frac * width, height - 44, max(8.0, width * (0.03 if i == 0 else 0.012)), accent))
    return parts


def chapter(width, height, primary, accent):
    panel = int(width * 0.26)
    parts = [
        '<defs>',
        '<linearGradient id="panel" x1="0" y1="0" x2="1" y2="1">',
        '<stop offset="0" stop-color="%s"/><stop offset="1" stop-color="#071528"/></linearGradient>' % primary,
        '<linearGradient id="edge" x1="0" y1="0" x2="0" y2="1">',
        '<stop offset="0" stop-color="%s" stop-opacity="0.95"/><stop offset="1" stop-color="%s" stop-opacity="0.5"/>'
        % (accent, accent),
        '</linearGradient>',
        '<pattern id="grid" width="36" height="36" patternUnits="userSpaceOnUse">',
        '<path d="M36 0H0V36" fill="none" stroke="%s" stroke-width="1" opacity="0.07"/></pattern>' % accent,
        '<pattern id="hatch" width="14" height="14" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">',
        '<path d="M0 0V14" fill="none" stroke="%s" stroke-width="1.4" opacity="0.10"/></pattern>' % accent,
        '</defs>',
        '<rect width="%d" height="%d" fill="#FFFFFF"/>' % (width, height),
        '<rect x="%d" y="0" width="%d" height="%d" fill="url(#grid)"/>' % (panel, width - panel, height),
        '<rect x="0" y="0" width="%d" height="%d" fill="url(#panel)"/>' % (panel, height),
        '<rect x="0" y="%.0f" width="%d" height="%.0f" fill="url(#hatch)"/>' % (height * 0.60, panel, height * 0.40),
    ]
    traces = [(0.10, 0.13, 0.45, 0.21, 0.70, 0.21),
              (0.10, 0.33, 0.32, 0.42, 0.70, 0.42),
              (0.84, 0.13, 0.84, 0.28, 0.70, 0.28),
              (0.84, 0.44, 0.84, 0.60, 0.62, 0.60),
              (0.10, 0.84, 0.40, 0.77, 0.70, 0.77),
              (0.70, 0.89, 0.18, 0.96)]
    parts.append('<g stroke="%s" stroke-width="1.1" opacity="0.32" fill="none">' % accent)
    for seg in traces:
        pts = " ".join(("M" if i == 0 else "L") + "%.0f %.0f" % (seg[i] * panel, seg[i + 1] * height)
                       for i in range(0, len(seg), 2))
        parts.append('<path d="%s"/>' % pts)
    parts.append('</g>')
    parts.append('<rect x="%d" y="0" width="4" height="%d" fill="url(#edge)"/>' % (panel - 4, height))
    parts.append('<rect x="%d" y="0" width="%d" height="1" fill="#D8E1EE"/>' % (panel, width - panel))
    parts.append('<rect x="%d" y="%d" width="%d" height="1" fill="#D8E1EE"/>' % (panel, height - 1, width - panel))
    return parts


def titlebar(width, height, primary, accent):
    parts = [
        '<defs>',
        '<linearGradient id="bar" x1="0" y1="0" x2="1" y2="0">',
        '<stop offset="0" stop-color="#EEF4FB"/><stop offset="1" stop-color="#FFFFFF"/></linearGradient>',
        '<linearGradient id="top" x1="0" y1="0" x2="1" y2="0">',
        '<stop offset="0" stop-color="%s"/><stop offset="0.35" stop-color="%s"/>' % (primary, accent),
        '<stop offset="1" stop-color="%s" stop-opacity="0"/></linearGradient>' % accent,
        '</defs>',
        '<rect width="%d" height="%d" fill="url(#bar)"/>' % (width, height),
        '<rect x="0" y="0" width="%d" height="3" fill="url(#top)"/>' % width,
        '<rect x="18" y="14" width="4" height="%d" rx="2" fill="%s"/>' % (max(20, height - 28), accent),
        '<rect x="0" y="%d" width="%d" height="2" fill="#D8E1EE"/>' % (height - 2, width),
    ]
    for i, x in enumerate((30, 44, 54)):
        parts.append('<rect x="%d" y="%d" width="%d" height="3" fill="%s" opacity="0.5"/>'
                     % (x, height - 28, max(3, 10 - i * 3), accent))
    return parts


KINDS = {"cover": cover, "chapter": chapter, "titlebar": titlebar}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--kind", required=True, choices=sorted(KINDS))
    parser.add_argument("--width", type=int, required=True)
    parser.add_argument("--height", type=int, required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--primary", default="#0B1F3A", help="结构主色（深色）")
    parser.add_argument("--accent", default="#4FA3E3", help="强调色")
    args = parser.parse_args()

    parts = [svg_open(args.width, args.height)]
    parts.extend(KINDS[args.kind](args.width, args.height, args.primary, args.accent))
    parts.append("</svg>")
    directory = os.path.dirname(os.path.abspath(args.out))
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as handle:
        handle.write("\n".join(parts))
    print("已输出 %s（%s %dx%d）" % (args.out, args.kind, args.width, args.height))
    print("提示：底纹里没有文字，文字由 PPT 文本框负责；转 PNG（2–3 倍密度）后插入，放在正文图层之下。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
