"""版式后校验：文本互相重叠、文本压图、文本跑出所属卡片、内容区铺满率。

用法：python audit_deck_layout.py <pptx> [内容区上边界,下边界]
判定：
  1. 任意两个文本框相交 >8%（以较小框面积计）→ 文字重叠；
  2. 文本框与图片（主图）相交 >5% → 文字压图；
  3. 文本框中心落在某卡片内、但文本框越出该卡片 >0.06in → 跑出卡片；
  4. 内容区（默认 0.80–6.40 in）内"卡片+图片+顶部信息条"并集面积占比 <80% → 铺不满。
"""

import sys
import os as _os

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor", "pylibs")
if _os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
from pathlib import Path

from pptx import Presentation
from pptx.util import Emu


def rect(shape):
    left, top = Emu(shape.left).inches, Emu(shape.top).inches
    return [left, top, left + Emu(shape.width).inches, top + Emu(shape.height).inches]


def overlap(a, b):
    w = min(a[2], b[2]) - max(a[0], b[0])
    h = min(a[3], b[3]) - max(a[1], b[1])
    return max(0.0, w) * max(0.0, h)


def area(a):
    return max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])


def contains(outer, inner, tol=0.06):
    return (inner[0] >= outer[0] - tol and inner[1] >= outer[1] - tol
            and inner[2] <= outer[2] + tol and inner[3] <= outer[3] + tol)

def is_backdrop(shape):
    """通栏且贴顶的图片是底纹/标题栏装饰层，不是正文主图。

    R4 误报修正（记录在案）：底纹与页眉装饰图本就与页面文字叠放，
    按几何判定排除，避免把"背景层"误判为"文字压图"。
    """
    left = Emu(shape.left).inches
    top = Emu(shape.top).inches
    width = Emu(shape.width).inches
    return left <= 0.05 and top <= 0.05 and width >= 12.5


def union_area(rects, band):
    if not rects:
        return 0.0
    step = 0.05
    rows = int(round((band[1] - band[0]) / step))
    cols = int(round((band[3] - band[2]) / step))
    hit = 0
    for row in range(rows):
        y = band[0] + row * step
        for col in range(cols):
            x = band[2] + col * step
            if any(r[0] <= x <= r[2] and r[1] <= y <= r[3] for r in rects):
                hit += 1
    return hit * step * step


def main():
    deck = Path(sys.argv[1])
    band = (0.80, 6.40)
    if len(sys.argv) > 2:
        parts = [float(v) for v in sys.argv[2].split(",")]
        band = (parts[0], parts[1])
    prs = Presentation(str(deck))
    issues = []
    structural = {1, 2, 3, 8, 14, 21, 27, 33, 38, 39}
    for index, slide in enumerate(prs.slides, 1):
        boxes, texts, pics, cards, strip = [], [], [], [], []
        for shape in slide.shapes:
            kind = str(shape.shape_type)
            if shape.has_text_frame and shape.text_frame.text.strip():
                sizes = [r.font.size.pt for p in shape.text_frame.paragraphs for r in p.runs if r.font.size]
                if sizes and max(sizes) > 90:            # 章节编号水印，不参与重叠判定
                    continue
                boxes.append((shape.name, rect(shape), shape.text_frame.text.strip()[:18]))
            if "PICTURE" in kind and Emu(shape.width).inches > 3:
                # 底纹/标题栏类装饰图不参与"文字压图"判定：它们本就是文字所在的背景层
                if is_backdrop(shape):
                    continue
                pics.append(rect(shape))
            elif shape.has_table:
                cards.append(rect(shape))
            elif "AUTO_SHAPE" in kind:
                r = rect(shape)
                if Emu(shape.height).inches >= 0.3 and area(r) > 1.0:
                    cards.append(r)
                    if Emu(shape.top).inches < band[0] + 0.3:
                        strip.append(r)
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                inter = overlap(boxes[i][1], boxes[j][1])
                small = min(area(boxes[i][1]), area(boxes[j][1]))
                if inter > 0.08 * small:
                    issues.append(f"  {index} 文字重叠：{boxes[i][2]} × {boxes[j][2]} "
                                  f"({inter / max(1e-6, small) * 100:.0f}%)")
        for name, r, text in boxes:
            for pic in pics:
                if overlap(r, pic) > 0.05 * area(r):
                    issues.append(f"  {index} 文字压图：{text}")
                    break
            holder = None
            for card in cards:
                if contains(card, r, 0.0):
                    holder = card
                    break
            if holder and not contains(holder, r, 0.06):
                issues.append(f"  {index} 跑出卡片：{text}")
        if index not in structural:
            content = pics + cards
            ratio = union_area(content, (band[0], band[1], 0.35, 13.0)) / max(1e-6, (band[1] - band[0]) * 12.65)
            if ratio < 0.80:
                issues.append(f"  {index} 内容区铺不满：{ratio * 100:.0f}%")
    print(f"检查 {len(prs.slides)} 页，问题 {len(issues)} 项")
    for item in issues[:30]:
        print(item)
    return 0 if not issues else 1


if __name__ == "__main__":
    sys.exit(main())
