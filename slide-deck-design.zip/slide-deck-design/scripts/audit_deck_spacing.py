"""间距后校验（PPT 版，与 svg-infographic/scripts/check_svg_spacing.py 同口径）。

规则：
  A. 同级相邻本体之间的空隙 ≤ 0.75 × 该本体自身的宽（横向）/高（纵向）；
     两块之间存在"带文字的连线"时阈值放宽到 1.5 ×。
  B. 自底向上逐层：底层本体并集在各上层容器内的上/下/左/右边距，
     不得超过 0.75 × 对应方向的底层本体尺寸（高或宽）。
     - 边距内有文字 → 判"内容边距"，提示确认是否合规；
     - 边距内无文字且该容器需与同层对齐（无法改尺寸）→
       必须填【素材图片（优先无背景，有背景则边缘虚化）/ 关键词说明文本 / 纹饰】；
     - 否则 → 缩小该容器。

用法：python audit_deck_spacing.py <pptx> [--ratio 0.75] [--labeled 1.5]
"""

import argparse
import os as _os
import sys

_VENDOR = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "vendor", "pylibs")
if _os.path.isdir(_VENDOR) and _VENDOR not in sys.path:
    sys.path.append(_VENDOR)   # 追加而非前置：本机已有依赖时优先用本机的
from pathlib import Path

from pptx import Presentation
from pptx.util import Emu


def rect(shape):
    left, top = Emu(shape.left).inches, Emu(shape.top).inches
    return [left, top, left + Emu(shape.width).inches, top + Emu(shape.height).inches]


def area(b):
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def inner(a, b):
    w = min(a[2], b[2]) - max(a[0], b[0])
    h = min(a[3], b[3]) - max(a[1], b[1])
    return max(0.0, w) * max(0.0, h)


def contains(outer, item, tol=0.01):
    return (item[0] >= outer[0] - tol and item[1] >= outer[1] - tol
            and item[2] <= outer[2] + tol and item[3] <= outer[3] + tol)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("deck")
    parser.add_argument("--ratio", type=float, default=0.75)
    parser.add_argument("--labeled", type=float, default=1.5)
    parser.add_argument("--band", default="0.80,6.40")
    args = parser.parse_args()
    band = [float(v) for v in args.band.split(",")]
    prs = Presentation(args.deck)
    issues = []
    for index, slide in enumerate(prs.slides, 1):
        boxes, texts, connectors = [], [], []
        for shape in slide.shapes:
            kind = str(shape.shape_type)
            if shape.has_text_frame and shape.text_frame.text.strip():
                sizes = [r.font.size.pt for p in shape.text_frame.paragraphs for r in p.runs if r.font.size]
                if sizes and max(sizes) > 90:
                    continue
                texts.append((shape.text_frame.text.strip()[:14], rect(shape)))
            if "CONNECTOR" in kind or "LINE" in kind:
                connectors.append(rect(shape))
            elif shape.has_table or ("AUTO_SHAPE" in kind and Emu(shape.height).inches > 0.4 and area(rect(shape)) > 2.0):
                boxes.append((shape.name, rect(shape)))
        # A. 最近邻空隙（只取每个方向上的最近一块，避免把远距离块当邻居）
        nearest = {}
        for name_a, a in boxes:
            for name_b, b in boxes:
                if b is a:
                    continue
                v_ov = min(a[3], b[3]) - max(a[1], b[1])
                h_ov = min(a[2], b[2]) - max(a[0], b[0])
                if v_ov > 0.5 * min(a[3] - a[1], b[3] - b[1]) and b[0] >= a[2] - 0.01:
                    gap = b[0] - a[2]
                    key = (name_a, "横")
                    if key not in nearest or gap < nearest[key][0]:
                        nearest[key] = (gap, name_b, a[2] - a[0])
                if h_ov > 0.5 * min(a[2] - a[0], b[2] - b[0]) and b[1] >= a[3] - 0.01:
                    gap = b[1] - a[3]
                    key = (name_a, "纵")
                    if key not in nearest or gap < nearest[key][0]:
                        nearest[key] = (gap, name_b, a[3] - a[1])
        for (name_a, direction), (gap, name_b, ref) in nearest.items():
            limit = args.ratio * ref
            if gap > limit:
                issues.append(f"{index} 最近邻{direction}向空隙 {gap:.2f} in > {limit:.2f} in（{name_a}→{name_b}）")
        seen = set()
        for name_a, a in boxes:
            if name_a in seen:
                continue
            seen.add(name_a)
            # B. 容器边距（自底向上）
            for name_o, outer in boxes:
                kids = [b for _, b in boxes if b is not outer and contains(outer, b)]
                if not kids:
                    continue
                left = min(b[0] for b in kids) - outer[0]
                right = outer[2] - max(b[2] for b in kids)
                top = min(b[1] for b in kids) - outer[1]
                bottom = outer[3] - max(b[3] for b in kids)
                ref_w = min(b[2] - b[0] for b in kids)
                ref_h = min(b[3] - b[1] for b in kids)
                for side, margin, ref in (("左", left, ref_w), ("右", right, ref_w),
                                          ("上", top, ref_h), ("下", bottom, ref_h)):
                    if margin <= args.ratio * ref:
                        continue
                    strip = {"左": [outer[0], outer[1], outer[0] + margin, outer[3]],
                             "右": [outer[2] - margin, outer[1], outer[2], outer[3]],
                             "上": [outer[0], outer[1], outer[2], outer[1] + margin],
                             "下": [outer[0], outer[3] - margin, outer[2], outer[3]]}[side]
                    has_text = any(inner(strip, t[1]) > 0 for t in texts)
                    if has_text:
                        issues.append(f"{index} {side}边距 {margin:.2f} in > {args.ratio * ref:.2f} in，"
                                      f"边距内有文字（确认是否合规）")
                    else:
                        issues.append(f"{index} {side}边距 {margin:.2f} in > {args.ratio * ref:.2f} in 且无内容 → "
                                      f"填素材图片/关键词/纹饰，或缩小容器（{name_o}）")
    print(f"检查 {len(prs.slides)} 页，间距问题 {len(issues)} 项")
    for item in issues[:30]:
        print("  -", item)
    return 0 if not issues else 1


if __name__ == "__main__":
    sys.exit(main())
